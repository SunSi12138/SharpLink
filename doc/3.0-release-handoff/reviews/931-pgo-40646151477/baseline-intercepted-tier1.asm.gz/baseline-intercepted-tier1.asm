; SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1+<GetAsyncEnumerator>d__8[int]:MoveNext():this
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 152559
; 22 inlinees with PGO data; 68 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x130]
       xor      ebx, ebx
       mov      qword ptr [rbp-0xF8], rbx
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0xF0], xmm8
       mov      rbx, -192
       vmovdqa  xmmword ptr [rbp+rbx-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rbx-0x10], xmm8
       vmovdqa  xmmword ptr [rbx+rbp], xmm8
       add      rbx, 48
       jne      SHORT  -5 instr
       mov      gword ptr [rbp-0x100], rdi
       mov      rdx, rdi
 
G_M000_IG02:                ;; offset=0x0056
       mov      ecx, dword ptr [rdx+0x30]
       mov      dword ptr [rbp-0x1C], ecx
       mov      r15, gword ptr [rdx+0x08]
 
G_M000_IG03:                ;; offset=0x0060
       mov      ecx, dword ptr [rbp-0x1C]
       add      ecx, 4
       cmp      ecx, 8
       ja       G_M000_IG94
 
G_M000_IG04:                ;; offset=0x006F
       mov      ecx, ecx
       lea      rdi, [reloc @RWD00]
       mov      edi, dword ptr [rdi+4*rcx]
       lea      rsi, G_M000_IG02
       add      rdi, rsi
       jmp      rdi
 
G_M000_IG05:                ;; offset=0x0087
       mov      edi, dword ptr [rbp-0x1C]
       add      edi, 4
       cmp      edi, 8
       ja       G_M000_IG63
 
G_M000_IG06:                ;; offset=0x0096
       mov      edi, edi
       lea      rax, [reloc @RWD36]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG07:                ;; offset=0x00AE
       cmp      dword ptr [rbp-0x1C], -4
       jne      G_M000_IG17
 
G_M000_IG08:                ;; offset=0x00B8
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
       cmp      byte  ptr [rdx+0x3C], 0
       jne      G_M000_IG69
 
G_M000_IG09:                ;; offset=0x00D0
       cmp      gword ptr [r15+0x10], 0
       jne      G_M000_IG22
       lea      rbx, bword ptr [r15+0x38]
       mov      r14, gword ptr [r15+0x08]
       test     r14, r14
       je       G_M000_IG23
       cmp      byte  ptr [rbx+0x19], 0
       jne      G_M000_IG24
 
G_M000_IG10:                ;; offset=0x00F6
       mov      rdx, gword ptr [rbp-0x100]
       mov      rdi, gword ptr [rdx+0x18]
       mov      rax, 0x7FBD00F69ED8
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG28
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      qword ptr [rbp-0xE0], rdx
 
G_M000_IG11:                ;; offset=0x0128
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x0135
       cmp      byte  ptr [r15+0x51], 0
       jne      G_M000_IG35
       xor      esi, esi
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x34], esi
       mov      rsi, gword ptr [rbp-0x70]
       movzx    rdi, byte  ptr [rbp-0x66]
       movsx    rax, word  ptr [rbp-0x68]
       mov      gword ptr [rbp-0x80], rsi
       mov      word  ptr [rbp-0x78], ax
       mov      byte  ptr [rbp-0x76], dil
       mov      byte  ptr [rbp-0x75], 0
       mov      rbx, gword ptr [rbp-0x80]
       test     rbx, rbx
       jne      G_M000_IG29
 
G_M000_IG13:                ;; offset=0x0177
       mov      r14, gword ptr [rbp-0x80]
       test     r14, r14
       jne      G_M000_IG32
       movzx    r14, byte  ptr [rbp-0x76]
 
G_M000_IG14:                ;; offset=0x0189
       test     r14d, r14d
       je       G_M000_IG61
 
G_M000_IG15:                ;; offset=0x0192
       mov      rdx, gword ptr [rbp-0x100]
       mov      rdi, gword ptr [rdx+0x18]
       mov      r11, 0x7FBD00F69ED8
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG62
       mov      ebx, dword ptr [rdi+0xE4]
 
G_M000_IG16:                ;; offset=0x01B6
       movsx    rsi, byte  ptr [r15+0x1C]
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x34], ebx
       mov      dword ptr [rbp-0x1C], -4
       mov      dword ptr [rdx+0x30], -4
       jmp      G_M000_IG116
 
G_M000_IG17:                ;; offset=0x01D8
       mov      eax, dword ptr [rbp-0x1C]
       dec      eax
       cmp      eax, 2
       ja       G_M000_IG09
 
G_M000_IG18:                ;; offset=0x01E6
       mov      esi, eax
       lea      rdi, [reloc @RWD72]
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rax, G_M000_IG02
       add      rdi, rax
       jmp      rdi
 
G_M000_IG19:                ;; offset=0x01FE
       mov      rdx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rdx+0x90]
 
G_M000_IG20:                ;; offset=0x020C
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG21:                ;; offset=0x0215
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
       jmp      G_M000_IG13
 
G_M000_IG22:                ;; offset=0x0231
       lea      rdi, bword ptr [r15+0x38]
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rdi+0x10]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rsi, qword ptr [rdi+0x20]
       mov      qword ptr [rsp+0x20], rsi
       mov      rdi, gword ptr [r15+0x10]
       mov      rsi, gword ptr [r15+0x08]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Client.SharpLinkClient+ClientLogicalCallState:TryEnterProgress(SharpLink.Abstractions.RpcDeadline,System.TimeProvider):bool:this]
       test     eax, eax
       jne      G_M000_IG10
       jmp      SHORT G_M000_IG27
 
G_M000_IG23:                ;; offset=0x026C
       mov      edi, 0x2077
       mov      rsi, 0x7FBCFF34D180
       call     [CORINFO_HELP_STRCNS]
       mov      rdi, rax
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG24:                ;; offset=0x028B
       cmp      byte  ptr [rbx+0x18], 0
       jne      SHORT G_M000_IG25
       mov      rdi, rbx
       call     [SharpLink.Abstractions.RpcDeadline:get_Timestamp():long:this]
       mov      rbx, rax
       mov      rdi, r14
       mov      rax, qword ptr [r14]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x38]System.TimeProvider:GetTimestamp():long:this
       cmp      rbx, rax
       setle    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02B5
       mov      rdi, r14
       mov      rax, qword ptr [r14]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x38]System.TimeProvider:GetTimestamp():long:this
       sub      rax, qword ptr [rbx]
       cmp      rax, qword ptr [rbx+0x20]
       setae    bl
       movzx    rbx, bl
 
G_M000_IG26:                ;; offset=0x02CF
       test     ebx, ebx
       je       G_M000_IG10
 
G_M000_IG27:                ;; offset=0x02D7
       call     [SharpLink.Client.SharpLinkClient:CreateDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG28:                ;; offset=0x02E6
       mov      r11, 0x7FBCFE262080
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this
       mov      gword ptr [rbp-0xE8], rax
       mov      qword ptr [rbp-0xE0], rdx
       jmp      G_M000_IG11
 
G_M000_IG29:                ;; offset=0x0306
       mov      rsi, rbx
       mov      rdi, 0x7FBD009418B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG30
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x032E
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x78]
       mov      r11, 0x7FBCFE2620A8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG31:                ;; offset=0x034D
       test     r14d, r14d
       jne      G_M000_IG13
       mov      dword ptr [rbp-0x1C], 1
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x30], 1
       lea      rdi, bword ptr [rdx+0x90]
       lea      rsi, bword ptr [rbp-0x80]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x60], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x60]
       mov      rdi, 0x7FBD00FAB568
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x80]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG108
 
G_M000_IG32:                ;; offset=0x03AB
       mov      rsi, r14
       mov      rdi, 0x7FBD009418B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       SHORT G_M000_IG34
       mov      edi, dword ptr [rbx+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG33
       mov      rdi, rbx
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG33:                ;; offset=0x03E1
       movzx    r14, byte  ptr [rbx+0x38]
       jmp      G_M000_IG14
 
G_M000_IG34:                ;; offset=0x03EB
       mov      rdi, r14
       movsx    rsi, word  ptr [rbp-0x78]
       mov      r11, 0x7FBCFE2620B0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r14d, eax
       jmp      G_M000_IG14
 
G_M000_IG35:                ;; offset=0x0408
       mov      rbx, gword ptr [rbp-0x70]
       test     rbx, rbx
       je       SHORT G_M000_IG38
       mov      rsi, rbx
       mov      rdi, 0x7FBD009418B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG36
       mov      esi, dword ptr [rax+0x34]
       and      esi, 0x1600000
       cmp      esi, 0x1000000
       sete     sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0441
       movsx    rsi, word  ptr [rbp-0x68]
       mov      rdi, rbx
       mov      r11, 0x7FBCFE2620B8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       cmp      eax, 1
       sete     sil
       movzx    rsi, sil
 
G_M000_IG37:                ;; offset=0x0461
       test     esi, esi
       je       SHORT G_M000_IG43
 
G_M000_IG38:                ;; offset=0x0465
       mov      rbx, gword ptr [rbp-0x70]
       test     rbx, rbx
       jne      SHORT G_M000_IG39
       movzx    r14, byte  ptr [rbp-0x66]
       jmp      SHORT G_M000_IG42
 
G_M000_IG39:                ;; offset=0x0475
       mov      rsi, rbx
       mov      rdi, 0x7FBD009418B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG41
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG40
       mov      rdi, r14
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG40:                ;; offset=0x04AC
       movzx    r14, byte  ptr [r14+0x38]
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04B3
       movsx    rsi, word  ptr [rbp-0x68]
       mov      rdi, rbx
       mov      r11, 0x7FBCFE2620C0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r14d, eax
 
G_M000_IG42:                ;; offset=0x04CB
       mov      rdi, r15
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ThrowIfDeadlineExpired():this]
       jmp      G_M000_IG14
 
G_M000_IG43:                ;; offset=0x04D9
       lea      rdi, [rbp-0x70]
       call     [System.Threading.Tasks.ValueTask`1[bool]:AsTask():System.Threading.Tasks.Task`1[bool]:this]
       mov      rdx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rdx+0x28]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      edi, edi
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x34], edi
       mov      r14, gword ptr [rdx+0x28]
       vmovdqu  ymm0, ymmword ptr [r15+0x38]
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       mov      rdi, qword ptr [r15+0x58]
       mov      qword ptr [rbp-0xB8], rdi
       mov      rbx, gword ptr [r15+0x08]
       mov      rdi, gword ptr [rdx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_Token():System.Threading.CancellationToken:this]
       mov      rdx, rax
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rdi, qword ptr [rbp-0xB8]
       mov      qword ptr [rsp+0x20], rdi
       mov      rdi, r14
       mov      rsi, rbx
       call     [SharpLink.Abstractions.SharpLinkTimer:WaitAsync(System.Threading.Tasks.Task,SharpLink.Abstractions.RpcDeadline,System.TimeProvider,System.Threading.CancellationToken):System.Threading.Tasks.ValueTask`1[bool]]
       mov      gword ptr [rbp-0x90], rax
       mov      qword ptr [rbp-0x88], rdx
       mov      rsi, gword ptr [rbp-0x90]
       movzx    rdi, byte  ptr [rbp-0x86]
       movsx    rax, word  ptr [rbp-0x88]
       mov      gword ptr [rbp-0x80], rsi
       mov      word  ptr [rbp-0x78], ax
       mov      byte  ptr [rbp-0x76], dil
       mov      byte  ptr [rbp-0x75], 0
       mov      rbx, gword ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG50
       mov      rsi, rbx
       mov      rdi, 0x7FBD009418B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG45
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
 
G_M000_IG44:                ;; offset=0x05C9
       movzx    r14, r14b
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x05CF
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x78]
       mov      r11, 0x7FBCFE2620C8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG46:                ;; offset=0x05EE
       test     r14d, r14d
       jne      G_M000_IG50
       mov      dword ptr [rbp-0x1C], 2
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x30], 2
       lea      rdi, bword ptr [rdx+0x90]
       lea      rsi, bword ptr [rbp-0x80]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x60], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x60]
       mov      rdi, 0x7FBD00FAB568
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x80]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG109
 
G_M000_IG47:                ;; offset=0x064C
       mov      rdx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rdx+0x90]
 
G_M000_IG48:                ;; offset=0x065A
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG49:                ;; offset=0x0663
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG50:                ;; offset=0x067A
       mov      rbx, gword ptr [rbp-0x80]
       test     rbx, rbx
       jne      SHORT G_M000_IG51
       movzx    r14, byte  ptr [rbp-0x76]
       jmp      SHORT G_M000_IG54
 
G_M000_IG51:                ;; offset=0x068A
       mov      rsi, rbx
       mov      rdi, 0x7FBD009418B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG53
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG52
       mov      rdi, r14
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG52:                ;; offset=0x06C1
       movzx    r14, byte  ptr [r14+0x38]
       jmp      SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x06C8
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x78]
       mov      r11, 0x7FBCFE2620D0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r14d, eax
 
G_M000_IG54:                ;; offset=0x06E0
       test     r14d, r14d
       jne      SHORT G_M000_IG56
       mov      rdi, gword ptr [r15+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG55
       call     [SharpLink.Client.SharpLinkClient+ClientLogicalCallState:TryClaimDeadline():bool:this]
 
G_M000_IG55:                ;; offset=0x06F4
       mov      rdx, gword ptr [rbp-0x100]
       mov      byte  ptr [rdx+0x3D], 1
       mov      rdi, gword ptr [rdx+0x10]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:TryCancelLifetime(System.Threading.CancellationTokenSource)]
       mov      rdx, gword ptr [rbp-0x100]
       mov      rdi, gword ptr [rdx+0x28]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ObserveAbandonedMoveNextAsync(System.Threading.Tasks.Task`1[bool]):System.Threading.Tasks.Task]
       call     [SharpLink.Client.SharpLinkClient:CreateDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG56:                ;; offset=0x0729
       xor      edi, edi
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x34], edi
       mov      rdi, gword ptr [rdx+0x28]
       xor      esi, esi
       cmp      dword ptr [rdi], edi
       call     [System.Threading.Tasks.Task`1[bool]:ConfigureAwait(bool):System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1[bool]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      qword ptr [rbp-0x98], rdx
       test     byte  ptr [rbp-0x98], 4
       jne      SHORT G_M000_IG57
       mov      rdi, gword ptr [rbp-0xA0]
       test     dword ptr [rdi+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      G_M000_IG60
 
G_M000_IG57:                ;; offset=0x0778
       mov      dword ptr [rbp-0x1C], 3
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x30], 3
       lea      rdi, bword ptr [rdx+0xA0]
       mov      rsi, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x98]
       mov      rbx, gword ptr [rbp-0x100]
       mov      dword ptr [rbx+0xA8], edx
       mov      gword ptr [rbp-0x60], rbx
       lea      rdx, bword ptr [rbx+0x40]
       lea      rsi, [rbp-0x60]
       mov      rdi, 0x7FBD00FAB568
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG110
 
G_M000_IG58:                ;; offset=0x07E4
       mov      rdx, gword ptr [rbp-0x100]
       vmovdqu  xmm0, xmmword ptr [rdx+0xA0]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG59:                ;; offset=0x07FB
       xor      esi, esi
       mov      qword ptr [rdx+0xA0], rsi
       mov      qword ptr [rdx+0xA8], rsi
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG60:                ;; offset=0x0819
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]:GetResult():bool:this]
       mov      r14d, eax
       xor      rdi, rdi
       mov      rdx, gword ptr [rbp-0x100]
       mov      gword ptr [rdx+0x28], rdi
       jmp      G_M000_IG14
 
G_M000_IG61:                ;; offset=0x083B
       mov      rdx, gword ptr [rbp-0x100]
       mov      byte  ptr [rdx+0x3C], 1
       jmp      G_M000_IG69
 
G_M000_IG62:                ;; offset=0x084B
       mov      r11, 0x7FBCFE262088
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      ebx, eax
       jmp      G_M000_IG16
 
G_M000_IG63:                ;; offset=0x085F
       mov      rdi, r15
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ThrowIfDeadlineExpired():this]
       mov      rdx, gword ptr [rbp-0x100]
       mov      rsi, gword ptr [rdx+0x10]
       cmp      byte  ptr [rsi+0x24], 0
       je       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0879
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG65:                ;; offset=0x0885
       mov      rdi, 0x7FBD00F69ED8
       cmp      qword ptr [rbx], rdi
       jne      SHORT G_M000_IG66
       mov      rdi, rbx
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this]
       jmp      SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x089F
       mov      rdi, rbx
       mov      r11, 0x7FBCFE262078
       call     [r11]System.Collections.Generic.IAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this
 
G_M000_IG67:                ;; offset=0x08AF
       mov      rdx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rdx+0x18]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x100]
       mov      byte  ptr [rdx+0x3D], 0
       xor      rdi, rdi
       mov      gword ptr [rdx+0x20], rdi
 
G_M000_IG68:                ;; offset=0x08D3
       mov      dword ptr [rdx+0x38], edi
       jmp      G_M000_IG07
 
G_M000_IG69:                ;; offset=0x08DB
       mov      rbx, gword ptr [rbp-0x100]
       mov      rdi, gword ptr [rbx+0x10]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:TryCancelLifetime(System.Threading.CancellationTokenSource)]
       mov      rdx, rbx
 
G_M000_IG70:                ;; offset=0x08EF
       cmp      dword ptr [rbp-0x1C], 4
       je       G_M000_IG80
       mov      rdi, gword ptr [rdx+0x18]
       mov      rax, 0x7FBD00F69ED8
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG71
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:DisposeAsync():System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0xF8], rax
       mov      qword ptr [rbp-0xF0], rdx
       jmp      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x0922
       mov      r11, 0x7FBCFE262070
       call     [r11]System.IAsyncDisposable:DisposeAsync():System.Threading.Tasks.ValueTask:this
       mov      gword ptr [rbp-0xF8], rax
       mov      qword ptr [rbp-0xF0], rdx
 
G_M000_IG72:                ;; offset=0x093D
       mov      rbx, gword ptr [rbp-0xF8]
       movsx    r15, word  ptr [rbp-0xF0]
       mov      r14, gword ptr [rbp-0x100]
       cmp      byte  ptr [r14+0x3D], 0
       je       SHORT G_M000_IG76
 
G_M000_IG73:                ;; offset=0x095A
       test     rbx, rbx
       je       SHORT G_M000_IG76
       mov      rsi, rbx
       mov      rdi, 0x7FBCFF346E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG74
       mov      rdi, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x0981
       mov      rdi, rbx
       mov      esi, r15d
       mov      r11, 0x7FBCFE2620D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG75:                ;; offset=0x099D
       test     eax, eax
       jne      SHORT G_M000_IG76
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, qword ptr [rbp-0xF0]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ObserveAbandonedDisposeAsync(System.Threading.Tasks.ValueTask):System.Threading.Tasks.Task]
       jmp      G_M000_IG89
 
G_M000_IG76:                ;; offset=0x09BA
       xor      esi, esi
       mov      dword ptr [r14+0x34], esi
       mov      gword ptr [rbp-0xB0], rbx
       mov      word  ptr [rbp-0xA8], r15w
       mov      byte  ptr [rbp-0xA6], 0
       mov      rbx, gword ptr [rbp-0xB0]
       test     rbx, rbx
       je       G_M000_IG82
 
G_M000_IG77:                ;; offset=0x09E6
       mov      rsi, rbx
       mov      rdi, 0x7FBCFF346E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG78
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x0A0E
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0xA8]
       mov      r11, 0x7FBCFE2620E0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG79:                ;; offset=0x0A30
       test     r15d, r15d
       jne      G_M000_IG82
       mov      dword ptr [rbp-0x1C], 4
       mov      dword ptr [r14+0x30], 4
       lea      rdi, bword ptr [r14+0xB0]
       lea      rsi, bword ptr [rbp-0xB0]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x60], r14
       lea      rdx, bword ptr [r14+0x40]
       lea      rsi, [rbp-0x60]
       mov      rdi, 0x7FBD00FAB568
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0xB0]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG111
 
G_M000_IG80:                ;; offset=0x0A8E
       vmovdqu  xmm0, xmmword ptr [rdx+0xB0]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
 
G_M000_IG81:                ;; offset=0x0A9E
       xor      esi, esi
       mov      qword ptr [rdx+0xB0], rsi
       mov      qword ptr [rdx+0xB8], rsi
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
       mov      r14, rdx
 
G_M000_IG82:                ;; offset=0x0ABF
       mov      rbx, gword ptr [rbp-0xB0]
       test     rbx, rbx
       je       SHORT G_M000_IG89
 
G_M000_IG83:                ;; offset=0x0ACB
       mov      rsi, rbx
       mov      rdi, 0x7FBCFF346E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG86
 
G_M000_IG84:                ;; offset=0x0AE2
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG89
 
G_M000_IG85:                ;; offset=0x0AF3
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG89
 
G_M000_IG86:                ;; offset=0x0B00
       mov      rdi, 0x7FBD00BBF178
       cmp      qword ptr [rbx], rdi
       jne      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0B0F
       movsx    rsi, word  ptr [rbp-0xA8]
       mov      rdi, rbx
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       jmp      SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x0B22
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0xA8]
       mov      r11, 0x7FBCFE2620E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       nop      
 
G_M000_IG89:                ;; offset=0x0B3B
       mov      r14, gword ptr [rbp-0x100]
       mov      rbx, gword ptr [r14+0x20]
       test     rbx, rbx
       je       SHORT G_M000_IG92
 
G_M000_IG90:                ;; offset=0x0B4B
       mov      rsi, rbx
       mov      rdi, 0x7FBCFF2805D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG91
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG91:                ;; offset=0x0B6B
       mov      rdi, rax
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Capture(System.Exception):System.Runtime.ExceptionServices.ExceptionDispatchInfo]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Throw():this]
       int3     
 
G_M000_IG92:                ;; offset=0x0B80
       cmp      byte  ptr [r14+0x3C], 0
       jne      G_M000_IG107
 
G_M000_IG93:                ;; offset=0x0B8B
       xor      rsi, rsi
       mov      gword ptr [r14+0x20], rsi
       mov      r14, gword ptr [rbp-0x100]
       jmp      G_M000_IG107
 
G_M000_IG94:                ;; offset=0x0B9D
       cmp      byte  ptr [rdx+0x3C], 0
       jne      G_M000_IG119
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
       lea      rcx, bword ptr [r15+0x18]
       mov      edi, 1
       xchg     dword ptr [rcx], edi
       test     edi, edi
       je       SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0BC4
       mov      rdi, 0x7FBCFF447150
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0x10465
       mov      rsi, 0x7FBCFFC24600
       call     [CORINFO_HELP_STRCNS]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG96:                ;; offset=0x0C00
       xor      ecx, ecx
       mov      dword ptr [rdx+0x34], ecx
       lea      rax, bword ptr [r15+0x20]
       lea      rdi, [rsp]
       mov      rsi, rax
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x10], rcx
       lea      rsi, [rbp-0x58]
       mov      rdi, r15
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:AwaitInvocationWithinDeadlineAsync(System.Threading.Tasks.ValueTask`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]):System.Threading.Tasks.ValueTask`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:this]
       mov      rsi, gword ptr [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x48]
       movsx    rax, word  ptr [rbp-0x50]
       mov      gword ptr [rbp-0x40], rsi
       mov      word  ptr [rbp-0x38], ax
       mov      byte  ptr [rbp-0x36], 0
       mov      gword ptr [rbp-0x30], rdi
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       je       G_M000_IG102
 
G_M000_IG97:                ;; offset=0x0C60
       mov      rsi, rbx
       mov      rdi, 0x7FBD00F8AF60
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG98
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x0C88
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x38]
       mov      r11, 0x7FBCFE262098
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG99:                ;; offset=0x0CA7
       test     r14d, r14d
       jne      G_M000_IG102
       xor      edi, edi
       mov      rbx, gword ptr [rbp-0x100]
       mov      dword ptr [rbx+0x30], edi
       lea      rdi, bword ptr [rbx+0x78]
       lea      rsi, bword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       call     CORINFO_HELP_ASSIGN_BYREF
       mov      gword ptr [rbp-0x60], rbx
       lea      rdx, bword ptr [rbx+0x40]
       lea      rsi, [rbp-0x60]
       mov      rdi, 0x7FBD00FAB568
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[SharpLink.Abstractions.SharpLinkClientInvocationResult]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG118
 
G_M000_IG100:                ;; offset=0x0CFE
       vmovdqu  xmm0, xmmword ptr [rdx+0x78]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
       mov      rcx, qword ptr [rdx+0x88]
       mov      qword ptr [rbp-0x30], rcx
 
G_M000_IG101:                ;; offset=0x0D13
       xor      ecx, ecx
       mov      qword ptr [rdx+0x78], rcx
       mov      qword ptr [rdx+0x80], rcx
       mov      qword ptr [rdx+0x88], rcx
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG102:                ;; offset=0x0D35
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       jne      SHORT G_M000_IG103
       mov      r14, gword ptr [rbp-0x30]
       jmp      SHORT G_M000_IG106
 
G_M000_IG103:                ;; offset=0x0D44
       mov      rsi, rbx
       mov      rdi, 0x7FBD00F8AF60
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG105
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG104
       mov      rdi, r14
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG104:                ;; offset=0x0D7B
       mov      r14, gword ptr [r14+0x38]
       jmp      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x0D81
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x38]
       mov      r11, 0x7FBCFE2620A0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:GetResult(short):SharpLink.Abstractions.SharpLinkClientInvocationResult:this
       mov      r14, rax
 
G_M000_IG106:                ;; offset=0x0D99
       mov      gword ptr [rbp-0x28], r14
       lea      rdi, [rbp-0x28]
       mov      rsi, 0x7FBD00FA0EA0
       call     [SharpLink.Abstractions.SharpLinkClientInvocationResult:GetValue[System.__Canon]():System.__Canon:this]
       mov      rbx, rax
       mov      rdi, gword ptr [r15+0x60]
       mov      rdx, gword ptr [rbp-0x100]
       mov      rsi, gword ptr [rdx+0x70]
       call     [System.Threading.CancellationTokenSource:CreateLinkedTokenSource(System.Threading.CancellationToken,System.Threading.CancellationToken):System.Threading.CancellationTokenSource]
       mov      rdx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rdx+0x10]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x100]
       jmp      G_M000_IG05
 
G_M000_IG107:                ;; offset=0x0DE8
       call     G_M000_IG139
       jmp      SHORT G_M000_IG112
 
G_M000_IG108:                ;; offset=0x0DEF
       call     G_M000_IG139
       jmp      SHORT G_M000_IG118
 
G_M000_IG109:                ;; offset=0x0DF6
       call     G_M000_IG139
       jmp      SHORT G_M000_IG118
 
G_M000_IG110:                ;; offset=0x0DFD
       call     G_M000_IG139
       jmp      SHORT G_M000_IG118
 
G_M000_IG111:                ;; offset=0x0E04
       call     G_M000_IG139
       jmp      SHORT G_M000_IG118
 
G_M000_IG112:                ;; offset=0x0E0B
       mov      rbx, gword ptr [rbp-0x100]
       cmp      byte  ptr [rbx+0x3C], 0
       jne      SHORT G_M000_IG119
 
G_M000_IG113:                ;; offset=0x0E18
       xor      rdi, rdi
       mov      gword ptr [rbx+0x10], rdi
 
G_M000_IG114:                ;; offset=0x0E1E
       mov      gword ptr [rbx+0x18], rdi
 
G_M000_IG115:                ;; offset=0x0E22
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG116:                ;; offset=0x0E28
       lea      rbx, bword ptr [rdx+0x48]
       mov      byte  ptr [rbx+0x22], 1
       cmp      byte  ptr [rbx+0x23], 0
       jne      G_M000_IG124
       mov      byte  ptr [rbx+0x23], 1
       mov      r15, gword ptr [rbx]
       test     r15, r15
       jne      SHORT G_M000_IG117
       mov      rsi, 0x7FB515801DB0
       mov      rsi, gword ptr [rsi]
       mov      rdi, rbx
       xor      rdx, rdx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      r15, rax
 
G_M000_IG117:                ;; offset=0x0E60
       test     r15, r15
       jne      SHORT G_M000_IG125
 
G_M000_IG118:                ;; offset=0x0E65
       vzeroupper 
       add      rsp, 280
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG119:                ;; offset=0x0E76
       mov      rdx, gword ptr [rbp-0x100]
       mov      dword ptr [rdx+0x30], -2
       xor      rdi, rdi
       mov      gword ptr [rdx+0x10], rdi
 
G_M000_IG120:                ;; offset=0x0E8A
       mov      gword ptr [rdx+0x18], rdi
 
G_M000_IG121:                ;; offset=0x0E8E
       mov      gword ptr [rdx+0x20], rdi
 
G_M000_IG122:                ;; offset=0x0E92
       mov      gword ptr [rdx+0x28], rdi
 
G_M000_IG123:                ;; offset=0x0E96
       mov      dword ptr [rdx+0x34], edi
       lea      rdi, bword ptr [rdx+0x40]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       mov      rbx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rbx+0x48]
       mov      byte  ptr [rdi+0x22], 0
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SignalCompletion():this]
       jmp      SHORT G_M000_IG118
 
G_M000_IG124:                ;; offset=0x0EBA
       call     [System.ThrowHelper:ThrowInvalidOperationException()]
       int3     
 
G_M000_IG125:                ;; offset=0x0EC1
       mov      r14, gword ptr [rbx+0x10]
       test     r14, r14
       jne      SHORT G_M000_IG127
       cmp      byte  ptr [rbx+0x24], 0
       je       SHORT G_M000_IG126
       mov      rdx, gword ptr [rbx+0x08]
       mov      rsi, r15
       mov      rdi, 0x7FBD00D30C38
       mov      ecx, 1
       call     [System.Threading.ThreadPool:UnsafeQueueUserWorkItem[System.__Canon](System.Action`1[System.__Canon],System.__Canon,bool):bool]
       jmp      G_M000_IG118
 
G_M000_IG126:                ;; offset=0x0EF1
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [r15+0x08]
       call     [r15+0x18]System.Action`1[System.__Canon]:Invoke(System.__Canon):this
       jmp      G_M000_IG118
 
G_M000_IG127:                ;; offset=0x0F02
       mov      rsi, r14
       mov      rdi, 0x7FBCFF34A7C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG128
       mov      rsi, r14
       mov      rdi, 0x7FBD00D30CE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0F30
       movzx    rcx, byte  ptr [rbx+0x24]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:InvokeContinuationWithContext(System.Object,System.Action`1[System.Object],System.Object,bool)]
       jmp      G_M000_IG118
 
G_M000_IG129:                ;; offset=0x0F49
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:ScheduleCapturedContext(System.Object,System.Action`1[System.Object],System.Object)]
       jmp      G_M000_IG118
 
G_M000_IG130:                ;; offset=0x0F5E
       sub      rsp, 40
 
G_M000_IG131:                ;; offset=0x0F62
       mov      rsi, rdi
       mov      rbx, gword ptr [rbp-0x100]
       lea      rdi, bword ptr [rbx+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rax, G_M000_IG69
 
G_M000_IG132:                ;; offset=0x0F7C
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG133:                ;; offset=0x0F84
       sub      rsp, 40
 
G_M000_IG134:                ;; offset=0x0F88
       mov      r14, gword ptr [rbp-0x100]
       cmp      byte  ptr [r14+0x3D], 0
       setne    al
       movzx    rax, al
 
G_M000_IG135:                ;; offset=0x0F9A
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG136:                ;; offset=0x0FA2
       sub      rsp, 40
 
G_M000_IG137:                ;; offset=0x0FA6
       lea      rax, G_M000_IG89
 
G_M000_IG138:                ;; offset=0x0FAD
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG139:                ;; offset=0x0FB5
       sub      rsp, 40
 
G_M000_IG140:                ;; offset=0x0FB9
       cmp      dword ptr [rbp-0x1C], -1
       jne      SHORT G_M000_IG143
 
G_M000_IG141:                ;; offset=0x0FBF
       mov      rbx, gword ptr [rbp-0x100]
       mov      r15, gword ptr [rbx+0x10]
       test     r15, r15
       je       SHORT G_M000_IG143
       mov      rdi, 0x7FBD00BC5810
       cmp      qword ptr [r15], rdi
       jne      SHORT G_M000_IG142
       mov      rdi, r15
       mov      esi, 1
       call     [System.Threading.CancellationTokenSource+Linked1CancellationTokenSource:Dispose(bool):this]
       mov      rdi, r15
       call     [System.GC:SuppressFinalize(System.Object)]
       jmp      SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x0FF7
       mov      rdi, r15
       mov      r11, 0x7FBCFE262090
       call     [r11]System.IDisposable:Dispose():this
       nop      
 
G_M000_IG143:                ;; offset=0x1008
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG144:                ;; offset=0x1010
       sub      rsp, 40
 
G_M000_IG145:                ;; offset=0x1014
       mov      rbx, rdi
       mov      r15, gword ptr [rbp-0x100]
       mov      dword ptr [r15+0x30], -2
       xor      rdi, rdi
       mov      gword ptr [r15+0x10], rdi
 
G_M000_IG146:                ;; offset=0x102C
       mov      gword ptr [r15+0x18], rdi
 
G_M000_IG147:                ;; offset=0x1030
       mov      gword ptr [r15+0x20], rdi
 
G_M000_IG148:                ;; offset=0x1034
       mov      gword ptr [r15+0x28], rdi
 
G_M000_IG149:                ;; offset=0x1038
       mov      dword ptr [r15+0x34], edi
       lea      rdi, bword ptr [r15+0x40]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x48]
       mov      rsi, rbx
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SetException(System.Exception):this]
       lea      rax, G_M000_IG118
 
G_M000_IG150:                ;; offset=0x105A
       vzeroupper 
       add      rsp, 40
       ret      
 
RWD00  	dd	00000031h ; case G_M000_IG05
       	dd	00000B47h ; case G_M000_IG94
       	dd	00000B47h ; case G_M000_IG94
       	dd	00000B47h ; case G_M000_IG94
       	dd	00000CA8h ; case G_M000_IG100
       	dd	00000031h ; case G_M000_IG05
       	dd	00000031h ; case G_M000_IG05
       	dd	00000031h ; case G_M000_IG05
       	dd	00000031h ; case G_M000_IG05
RWD36  	dd	00000058h ; case G_M000_IG07
       	dd	00000809h ; case G_M000_IG63
       	dd	00000809h ; case G_M000_IG63
       	dd	00000809h ; case G_M000_IG63
       	dd	00000809h ; case G_M000_IG63
       	dd	00000058h ; case G_M000_IG07
       	dd	00000058h ; case G_M000_IG07
       	dd	00000058h ; case G_M000_IG07
       	dd	00000899h ; case G_M000_IG70
RWD72  	dd	000001A8h ; case G_M000_IG19
       	dd	000005F6h ; case G_M000_IG47
       	dd	0000078Eh ; case G_M000_IG58

; Total bytes 4194
