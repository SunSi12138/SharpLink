using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using SharpLink.Client;
var assembly = typeof(SharpClientBuilder).Assembly;
var outer = assembly.GetType("SharpLink.Client.SharpLinkClient")!;
var wrapper = outer.GetNestedType("InterceptedAsyncEnumerable`1", BindingFlags.NonPublic)!.MakeGenericType(typeof(int));
var entry = wrapper.GetMethod("GetAsyncEnumerator")!;
var machine = entry.GetCustomAttribute<AsyncIteratorStateMachineAttribute>()!.StateMachineType;
if (machine.ContainsGenericParameters) machine = machine.MakeGenericType(typeof(int));
var method = machine.GetMethod("MoveNext", BindingFlags.NonPublic | BindingFlags.Instance)!;
var body = method.GetMethodBody()!;
Console.WriteLine(JsonSerializer.Serialize(new {
    runtime = RuntimeInformation.FrameworkDescription, architecture = RuntimeInformation.ProcessArchitecture.ToString(),
    source = new { assembly.Location, assembly.ManifestModule.ModuleVersionId, informationalVersion = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()!.InformationalVersion },
    method = method.ToString(), body.InitLocals, body.MaxStackSize,
    locals = body.LocalVariables.Select(l => new {l.LocalIndex, type=l.LocalType.ToString(), l.IsPinned}),
    clauses = body.ExceptionHandlingClauses.Select(c => new {flags=c.Flags.ToString(), c.TryOffset, c.TryLength, c.HandlerOffset, c.HandlerLength})
}, new JsonSerializerOptions {WriteIndented=true}));
