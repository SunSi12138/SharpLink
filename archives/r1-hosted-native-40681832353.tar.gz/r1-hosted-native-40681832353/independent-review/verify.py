import pathlib,json,hashlib,re,zipfile,argparse
parser=argparse.ArgumentParser();parser.add_argument('artifact_directory',type=pathlib.Path);args=parser.parse_args()
R=args.artifact_directory;r=R/'extracted/native';out=pathlib.Path(__file__).parent
J=lambda p:json.loads(p.read_text())
assert hashlib.sha256((R/'official-artifact.zip').read_bytes()).hexdigest()=='c619069c6f79ca4332425e3a3e89acd86fbab8ea72d025d884077646869a76ed'
with zipfile.ZipFile(R/'official-artifact.zip') as z:
 for f in z.namelist():
  if not f.endswith('/'):assert z.read(f)==(R/'extracted'/f).read_bytes(),f
m=J(r/'prepared/prepared-manifest.json');g=J(r/'preflight/gate.json');plan=J(r/'plan.json');result={}
assert plan['timedProcesses']==0 and plan['operationsPerProcess']==4352 and plan['fixedPausesAfterOperations']==[1024,2048,3072,4096] and plan['pauseMilliseconds']==250
assert [x for x in m['baselineBinaryHashes'] if m['baselineBinaryHashes'][x]!=m['candidateBinaryHashes'][x]]==['SharpLink.Client.dll']
assert m['baselineBinaryHashes']==m['referenceManifest']['candidateBinaryHashes']
for arm in ['baseline','candidate']:
 s=J(r/f'preflight/{arm}.json');h=J(r/f'preflight/{arm}.host.json');expected=m[arm+'BinaryHashes'];rows=[]
 assert s['operations']==4352 and s['kind']=='non-timed-preflight' and s['profile']=='default-pgo'
 assert s['runtimeVersion']=='10.0.13' and s['processorCount']==2 and s['tieredCompilation']==s['tieredPgo']=='default'
 assert s['readyConnections']==1 and s['interceptorObserved'] and s['binaryHashes']==expected
 assert h['exitCode']==0 and h['status']=='success' and h['command'][-4:]==['0',f'/home/runner/work/_temp/r1-hosted/native/preflight/{arm}.json','preflight','default-pgo']
 assert set(p.name for p in (r/'prepared'/arm).glob('*.dll'))==set(expected)
 for f,v in expected.items():assert hashlib.sha256((r/'prepared'/arm/f).read_bytes()).hexdigest()==v
 for a in s['loadedAssemblies']:
  assert a['location']==f"/home/runner/work/_temp/r1-hosted/native/prepared/{arm}/{a['name']}.dll"
  if a['name'].startswith('SharpLink.'):
   assert a['productVersion'].split('+')[-1]==m['productRevisions'][arm][a['name']]
 text=(r/f'preflight/{arm}-jit.txt').read_text();matches=list(re.finditer(r'; Assembly listing for method (.*?) \(([^\n]+)\)\n(.*?); Total bytes of code (\d+)',text,re.S))
 for a in g['arms'][arm]['native']:
  mt=next(x for x in matches if text.count('\n',0,x.start())+1==a['listingLine']);name,tier,body,size=mt.groups()
  assert name==a['method'] and tier==a['tier'] and int(size)==a['bytes']
  if a['acceptedOptimizedTier']:
   assert tier in ['Tier1','Tier1-OSR'] and int(size)>0
   rows.append({'target':a['target'],'bytes':int(size),'mainStackSubtract':re.findall(r'sub\s+rsp,\s*(\S+)',body)[0],'sourceListingLine':a['listingLine']})
   (out/f"{arm}-{a['target']}.asm").write_text('; '+name+' ('+tier+')\n'+body+'; Total bytes '+size+'\n')
 assert {x['target'] for x in rows}=={'dynamic-iterator','intercepted-iterator','runtime-stream-pump','server-stream-bridge'}
 result[arm]=rows
(out/'independent-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
