; SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]:MoveNext():this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 4096
; 49 inlinees with PGO data; 127 single block inlinees; 10 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 616
       lea      rbp, [rsp+0x290]
       xor      eax, eax
       mov      qword ptr [rbp-0x238], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x230], xmm8
       vmovdqa  xmmword ptr [rbp-0x220], xmm8
       mov      rax, -480
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT  -5 instr
       mov      bword ptr [rbp-0x1E8], rdi
       mov      rdx, rdi
 
G_M000_IG02:                ;; offset=0x0063
       mov      edi, dword ptr [rdx+0x58]
       mov      dword ptr [rbp-0x2C], edi
       mov      rbx, gword ptr [rdx+0x10]
 
G_M000_IG03:                ;; offset=0x006D
       cmp      dword ptr [rbp-0x2C], 5
       jbe      G_M000_IG47
 
G_M000_IG04:                ;; offset=0x0077
       cmp      dword ptr [rbp-0x2C], 6
       je       G_M000_IG194
 
G_M000_IG05:                ;; offset=0x0081
       cmp      gword ptr [rdx], 0
       je       G_M000_IG225
       cmp      gword ptr [rdx+0x08], 0
       je       G_M000_IG226
       mov      rdi, 0x7F75A5801F58
       mov      r15, gword ptr [rdi]
       mov      rdi, 0x7F7E094A1948
       mov      rax, 0x7F7E09CD0820
       call     rax
       cmp      dword ptr [rax], 2
       jle      G_M000_IG227
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x10]
       test     rax, rax
       je       G_M000_IG227
 
G_M000_IG06:                ;; offset=0x00D3
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       jne      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00DC
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
 
G_M000_IG08:                ;; offset=0x00E2
       mov      rdi, gword ptr [rax+0x08]
       test     rdi, rdi
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00EB
       mov      rdi, gword ptr [rdi+0x08]
       lea      rdx, [rbp-0x168]
       mov      rsi, r15
       mov      r11, 0x7F7D89E73280
       call     [r11]System.Threading.IAsyncLocalValueMap:TryGetValue(System.Threading.IAsyncLocal,byref):bool:this
       mov      rsi, gword ptr [rbp-0x168]
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x010F
       xor      rsi, rsi
 
G_M000_IG11:                ;; offset=0x0111
       xor      rdi, rdi
       mov      gword ptr [rbp-0x168], rdi
       mov      r15, rsi
       test     r15, r15
       je       SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x0122
       mov      rdi, 0x7F7D8CB19CE0
       cmp      qword ptr [r15], rdi
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0131
       call     CORINFO_HELP_CHKCASTCLASS_SPECIAL
       mov      r15, rax
 
G_M000_IG14:                ;; offset=0x0139
       test     r15, r15
       je       G_M000_IG31
 
G_M000_IG15:                ;; offset=0x0142
       vmovdqu  ymm0, ymmword ptr [r15+0x28]
       vmovdqu  ymmword ptr [rbp-0x140], ymm0
       mov      rdi, qword ptr [r15+0x48]
       mov      qword ptr [rbp-0x120], rdi
 
G_M000_IG16:                ;; offset=0x015B
       mov      rdx, bword ptr [rbp-0x1E8]
       vmovdqu  ymm0, ymmword ptr [rbp-0x140]
       vmovdqu  ymmword ptr [rdx+0x78], ymm0
       mov      rdi, qword ptr [rbp-0x120]
       mov      qword ptr [rdx+0x98], rdi
       test     r15, r15
       je       G_M000_IG32
 
G_M000_IG17:                ;; offset=0x0186
       mov      rsi, gword ptr [r15+0x08]
 
G_M000_IG18:                ;; offset=0x018A
       lea      rdi, bword ptr [rdx+0x18]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      r15, gword ptr [rdx+0x70]
       test     r15, r15
       je       G_M000_IG228
       mov      rdi, 0x7F7D8C7D5810
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdi, 0x7F75A58018F0
       mov      r13, gword ptr [rdi]
       cmp      dword ptr [r15+0x20], 0
       jne      G_M000_IG231
       cmp      byte  ptr [r15+0x24], 0
       jne      G_M000_IG232
       mov      rdi, gword ptr [r15+0x18]
       mov      gword ptr [rbp-0x220], rdi
       cmp      gword ptr [rbp-0x220], 0
       je       G_M000_IG33
 
G_M000_IG19:                ;; offset=0x01F5
       xor      r12, r12
       xor      eax, eax
       mov      qword ptr [rbp-0x170], rax
       mov      rdi, gword ptr [rbp-0x220]
       cmp      gword ptr [rdi+0x18], 0
       je       G_M000_IG26
 
G_M000_IG20:                ;; offset=0x0213
       mov      rdi, gword ptr [rbp-0x220]
       add      rdi, 52
       mov      ecx, 1
       xchg     byte  ptr [rdi], cl
       movzx    rcx, cl
       test     ecx, ecx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x022C
       call     [System.Threading.CancellationTokenSource+Registrations:<EnterLock>g__Contention|13_0(byref)]
 
G_M000_IG22:                ;; offset=0x0232
       mov      rdi, gword ptr [rbp-0x220]
       mov      r12, gword ptr [rdi+0x18]
       test     r12, r12
       je       G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0246
       mov      rsi, gword ptr [r12+0x18]
       mov      rdi, gword ptr [rbp-0x220]
       lea      rdi, bword ptr [rdi+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbp-0x220]
       mov      rax, qword ptr [rdi+0x20]
       lea      rdi, [rax+0x01]
       mov      rsi, gword ptr [rbp-0x220]
       mov      qword ptr [rsi+0x20], rdi
       mov      rcx, rax
       mov      qword ptr [rbp-0x170], rcx
       mov      qword ptr [r12+0x40], rcx
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x28]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      rdi, rdi
       mov      gword ptr [r12+0x30], rdi
 
G_M000_IG24:                ;; offset=0x02A5
       mov      gword ptr [r12+0x38], rdi
       mov      rdi, gword ptr [rbp-0x220]
       mov      rax, gword ptr [rdi+0x10]
       mov      gword ptr [rbp-0x248], rax
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbp-0x220]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x248]
       test     rsi, rsi
       jne      G_M000_IG34
 
G_M000_IG25:                ;; offset=0x02EC
       mov      rdi, gword ptr [rbp-0x220]
       mov      byte  ptr [rdi+0x34], 0
 
G_M000_IG26:                ;; offset=0x02F7
       test     r12, r12
       mov      rax, qword ptr [rbp-0x170]
       je       G_M000_IG35
 
G_M000_IG27:                ;; offset=0x0307
       cmp      dword ptr [r15+0x20], 0
       jne      G_M000_IG230
 
G_M000_IG28:                ;; offset=0x0312
       mov      r15, rax
 
G_M000_IG29:                ;; offset=0x0315
       lea      rdi, bword ptr [r14+0x28]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x30], r15
 
G_M000_IG30:                ;; offset=0x0325
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rdi, bword ptr [rdx+0x20]
       mov      rsi, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG39
 
G_M000_IG31:                ;; offset=0x033D
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x140], ymm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
       jmp      G_M000_IG16
 
G_M000_IG32:                ;; offset=0x0356
       xor      rsi, rsi
       jmp      G_M000_IG18
 
G_M000_IG33:                ;; offset=0x035D
       mov      rdi, 0x7F7D8C7CA418
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdi, r12
       mov      rsi, r15
       call     [System.Threading.CancellationTokenSource+Registrations:.ctor(System.Threading.CancellationTokenSource):this]
       lea      rdi, bword ptr [r15+0x18]
       test     rdi, rdi
       je       G_M000_IG229
       mov      rsi, r12
       xor      rdx, rdx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       test     rax, rax
       cmove    rax, r12
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG19
 
G_M000_IG34:                ;; offset=0x03A5
       lea      rdi, bword ptr [rsi+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG25
 
G_M000_IG35:                ;; offset=0x03B6
       mov      rdi, 0x7F7D8C7CA568
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, gword ptr [rbp-0x220]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x28]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      rdi, rdi
       mov      gword ptr [r12+0x30], rdi
 
G_M000_IG36:                ;; offset=0x03FA
       mov      gword ptr [r12+0x38], rdi
       mov      rdi, gword ptr [rbp-0x220]
       call     [System.Threading.CancellationTokenSource+Registrations:EnterLock():this]
       mov      rdi, gword ptr [rbp-0x220]
       mov      rax, qword ptr [rdi+0x20]
       lea      rdi, [rax+0x01]
       mov      rsi, gword ptr [rbp-0x220]
       mov      qword ptr [rsi+0x20], rdi
       mov      qword ptr [rbp-0x170], rax
       mov      qword ptr [r12+0x40], rax
       mov      rdi, gword ptr [rbp-0x220]
       mov      rcx, gword ptr [rdi+0x10]
       mov      gword ptr [rbp-0x250], rcx
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, rcx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x250]
       test     rsi, rsi
       jne      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x045D
       mov      rdi, gword ptr [rbp-0x220]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbp-0x220]
       mov      byte  ptr [rdi+0x34], 0
       mov      rax, qword ptr [rbp-0x170]
       jmp      G_M000_IG27
 
G_M000_IG38:                ;; offset=0x0487
       lea      rdi, bword ptr [rsi+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG37
 
G_M000_IG39:                ;; offset=0x0495
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      r15, gword ptr [rdx]
       mov      r14, gword ptr [rdx+0x20]
       cmp      byte  ptr [r14+0x24], 0
       jne      G_M000_IG42
       mov      rdi, 0x7F7D8CBBD4A0
       cmp      qword ptr [r15], rdi
       jne      G_M000_IG44
       mov      rdi, gword ptr [r15+0x08]
       mov      rsi, qword ptr [r15+0x18]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Server.ServerGeneratedBridge:EnsureUserCodeEntry(long):this]
       mov      r13, gword ptr [r15+0x08]
       mov      r12, qword ptr [r15+0x18]
       mov      rdi, gword ptr [r15+0x10]
       mov      rsi, 0x7F7D8CBBC468
       cmp      qword ptr [rdi], rsi
       jne      SHORT G_M000_IG43
       mov      rsi, r14
       call     [PhysicalTcp.ScalarStreamService+<DownloadAsync>d__0:System.Collections.Generic.IAsyncEnumerable<System.Int32>.GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this]
       mov      r15, rax
 
G_M000_IG40:                ;; offset=0x04F8
       mov      rdi, 0x7F7D8CBC0298
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x18], r12
       lea      rdi, bword ptr [r14+0x10]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG41:                ;; offset=0x0526
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rdi, bword ptr [rdx+0x28]
       mov      rsi, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG45
 
G_M000_IG42:                ;; offset=0x053B
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG43:                ;; offset=0x0547
       mov      rsi, r14
       mov      r11, 0x7F7D89E73288
       call     [r11]System.Collections.Generic.IAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this
       mov      r15, rax
       jmp      SHORT G_M000_IG40
 
G_M000_IG44:                ;; offset=0x055C
       mov      rdi, r15
       mov      rsi, r14
       mov      r11, 0x7F7D89E73278
       call     [r11]System.Collections.Generic.IAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this
       mov      r14, rax
       jmp      SHORT G_M000_IG41
 
G_M000_IG45:                ;; offset=0x0574
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 0
       xor      rdi, rdi
       mov      gword ptr [rdx+0x30], rdi
 
G_M000_IG46:                ;; offset=0x0585
       mov      dword ptr [rdx+0x5C], edi
       mov      rdx, bword ptr [rbp-0x1E8]
 
G_M000_IG47:                ;; offset=0x058F
       cmp      dword ptr [rbp-0x2C], 5
       jbe      SHORT G_M000_IG53
 
G_M000_IG48:                ;; offset=0x0595
       mov      rsi, gword ptr [rdx+0x08]
       mov      rax, rsi
       test     rax, rax
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x05A1
       mov      rdi, 0x7F7D8C6CEC30
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG103
       xor      rax, rax
 
G_M000_IG50:                ;; offset=0x05B6
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rdi, bword ptr [rdx+0x38]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x1E8]
       cmp      gword ptr [rdx+0x38], 0
       je       G_M000_IG83
 
G_M000_IG51:                ;; offset=0x05DB
       mov      rdi, gword ptr [rdx+0x38]
       mov      r11, 0x7F7D89E73270
       call     [r11]SharpLink.Abstractions.IRpcSizedCodec`1[int]:get_CanExactSize():bool:this
       test     eax, eax
       jne      G_M000_IG83
 
G_M000_IG52:                ;; offset=0x05F4
       xor      rsi, rsi
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      gword ptr [rdx+0x38], rsi
       jmp      G_M000_IG83
 
G_M000_IG53:                ;; offset=0x0606
       mov      esi, dword ptr [rbp-0x2C]
       lea      rdi, [reloc @RWD00]
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rax, G_M000_IG02
       add      rdi, rax
       jmp      rdi
 
G_M000_IG54:                ;; offset=0x061F
       cmp      gword ptr [rdx+0x18], 0
       je       G_M000_IG81
 
G_M000_IG55:                ;; offset=0x062A
       mov      r15, gword ptr [rbp-0x50]
       test     r15, r15
       je       G_M000_IG81
       jmp      G_M000_IG156
 
G_M000_IG56:                ;; offset=0x063C
       movsx    rsi, word  ptr [rbp-0x88]
       mov      rdi, r15
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       jmp      G_M000_IG83
 
G_M000_IG57:                ;; offset=0x0652
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       G_M000_IG83
       jmp      G_M000_IG165
 
G_M000_IG58:                ;; offset=0x066C
       mov      rdi, r15
       call     [PhysicalTcp.ScalarStreamService+<DownloadAsync>d__0:MoveNext():this]
       nop      
 
G_M000_IG59:                ;; offset=0x0676
       mov      rdi, gword ptr [rbp-0x238]
       cmp      rdi, gword ptr [r14+0x10]
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x0683
       lea      rdi, bword ptr [r14+0x10]
       mov      rsi, gword ptr [rbp-0x238]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG61:                ;; offset=0x0693
       mov      r13, gword ptr [r14+0x08]
       cmp      gword ptr [rbp-0x230], r13
       je       SHORT G_M000_IG65
 
G_M000_IG62:                ;; offset=0x06A0
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, gword ptr [rbp-0x230]
       call     CORINFO_HELP_ASSIGN_REF
       test     r13, r13
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x06B5
       cmp      gword ptr [r13+0x10], 0
       jne      G_M000_IG94
 
G_M000_IG64:                ;; offset=0x06C0
       cmp      gword ptr [rbp-0x230], 0
       jne      G_M000_IG93
 
G_M000_IG65:                ;; offset=0x06CE
       xor      rdi, rdi
       mov      gword ptr [rbp-0x228], rdi
 
G_M000_IG66:                ;; offset=0x06D7
       mov      gword ptr [rbp-0x230], rdi
 
G_M000_IG67:                ;; offset=0x06DE
       mov      gword ptr [rbp-0x238], rdi
       movsx    r14, word  ptr [r15+0x58]
       lea      r13, bword ptr [r15+0x38]
       movsx    rdi, word  ptr [r13+0x20]
       cmp      r14d, edi
       jne      G_M000_IG106
       cmp      gword ptr [r13], 0
       je       G_M000_IG96
 
G_M000_IG68:                ;; offset=0x0707
       cmp      byte  ptr [r13+0x23], 0
       je       G_M000_IG96
       cmp      gword ptr [r13+0x18], 0
       jne      G_M000_IG107
       lea      rdi, bword ptr [r15+0x38]
       movsx    rax, word  ptr [rdi+0x20]
       cmp      r14d, eax
       jne      G_M000_IG95
 
G_M000_IG69:                ;; offset=0x072F
       movzx    rax, byte  ptr [rdi+0x22]
       xor      r12, r12
       xor      r14d, r14d
       mov      ecx, 1
 
G_M000_IG70:                ;; offset=0x073E
       mov      gword ptr [rbp-0x40], r12
       mov      word  ptr [rbp-0x38], r14w
       mov      byte  ptr [rbp-0x36], al
       mov      byte  ptr [rbp-0x35], cl
       mov      rdx, bword ptr [rbp-0x1E8]
       cmp      byte  ptr [rdx+0x91], 0
       jne      G_M000_IG97
 
G_M000_IG71:                ;; offset=0x0761
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rbp-0x40]
       movzx    rdi, byte  ptr [rbp-0x36]
       movsx    rax, word  ptr [rbp-0x38]
       mov      gword ptr [rbp-0x60], rsi
       mov      word  ptr [rbp-0x58], ax
       mov      byte  ptr [rbp-0x56], dil
       mov      byte  ptr [rbp-0x55], 0
       mov      r15, gword ptr [rbp-0x60]
       test     r15, r15
       jne      G_M000_IG118
 
G_M000_IG72:                ;; offset=0x0793
       mov      r15, gword ptr [rbp-0x60]
       test     r15, r15
       jne      G_M000_IG125
       movzx    r14, byte  ptr [rbp-0x56]
 
G_M000_IG73:                ;; offset=0x07A5
       test     r14d, r14d
       je       G_M000_IG101
 
G_M000_IG74:                ;; offset=0x07AE
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x28]
       mov      r11, 0x7F7D8CBC0298
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG152
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x7F7D8CBBC468
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG151
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG75:                ;; offset=0x07E7
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      r15, qword ptr [rdx+0x50]
       movzx    r13, word  ptr [rdx+0x60]
       mov      r12, gword ptr [rdx+0x08]
       mov      rax, gword ptr [rdx+0x38]
       mov      gword ptr [rbp-0x210], rax
       vmovdqu  ymm0, ymmword ptr [rdx+0x78]
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       mov      rcx, qword ptr [rdx+0x98]
       mov      qword ptr [rbp-0xA8], rcx
       mov      r8, gword ptr [rdx+0x18]
       mov      gword ptr [rbp-0x218], r8
       mov      r9, gword ptr [rdx+0x20]
       mov      gword ptr [rbp-0x240], r9
       cmp      byte  ptr [r9+0x24], 0
       jne      G_M000_IG153
       mov      dword ptr [rbp-0x198], r14d
       xor      ecx, ecx
       mov      dword ptr [rbp-0x1A0], ecx
 
G_M000_IG76:                ;; offset=0x0851
       mov      gword ptr [rbp-0x1A8], rcx
       test     rax, rax
       jne      G_M000_IG154
 
G_M000_IG77:                ;; offset=0x0861
       mov      ecx, dword ptr [rbp-0x198]
       test     r12, r12
       je       G_M000_IG155
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rdi, qword ptr [rbp-0xA8]
       mov      qword ptr [rsp+0x20], rdi
       mov      r8, gword ptr [rbp-0x218]
       mov      gword ptr [rsp+0x28], r8
       mov      rdi, rbx
       mov      rsi, r15
       mov      edx, r13d
       mov      r8, r12
       mov      r9, gword ptr [rbp-0x240]
       call     [SharpLink.Runtime.RpcSession:SerializeUnsizedStreamChunk[int](long,ushort,int,SharpLink.Abstractions.IRpcCodec`1[int],System.Threading.CancellationToken,SharpLink.Abstractions.RpcDeadline,System.TimeProvider):System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0x190], rax
       mov      qword ptr [rbp-0x188], rdx
 
G_M000_IG78:                ;; offset=0x08CA
       xor      rsi, rsi
       mov      gword ptr [rbp-0x1A8], rsi
 
G_M000_IG79:                ;; offset=0x08D3
       vmovdqu  xmm0, xmmword ptr [rbp-0x190]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG80:                ;; offset=0x08E0
       mov      rdx, bword ptr [rbp-0x1E8]
       cmp      byte  ptr [rdx+0x91], 0
       jne      G_M000_IG54
 
G_M000_IG81:                ;; offset=0x08F4
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rbp-0x50]
       movsx    rdi, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x90], rsi
       mov      word  ptr [rbp-0x88], di
       mov      byte  ptr [rbp-0x86], 0
       mov      r15, gword ptr [rbp-0x90]
       test     r15, r15
       jne      G_M000_IG159
 
G_M000_IG82:                ;; offset=0x0929
       mov      r15, gword ptr [rbp-0x90]
       test     r15, r15
       jne      G_M000_IG90
 
G_M000_IG83:                ;; offset=0x0939
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      r15, gword ptr [rdx+0x28]
       mov      rdi, 0x7F7D8CBC0298
       cmp      qword ptr [r15], rdi
       jne      G_M000_IG109
       mov      rdi, gword ptr [r15+0x08]
       mov      rsi, qword ptr [r15+0x18]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Server.ServerGeneratedBridge:EnsureUserCodeEntry(long):this]
       mov      r15, gword ptr [r15+0x10]
       mov      rdi, 0x7F7D8CBBC468
       cmp      qword ptr [r15], rdi
       jne      G_M000_IG108
       cmp      dword ptr [r15+0x10], -2
       je       G_M000_IG104
       lea      rdi, bword ptr [r15+0x38]
       inc      word  ptr [rdi+0x20]
       xor      rax, rax
       mov      gword ptr [rdi], rax
 
G_M000_IG84:                ;; offset=0x0996
       mov      gword ptr [rdi+0x08], rax
 
G_M000_IG85:                ;; offset=0x099A
       mov      gword ptr [rdi+0x10], rax
 
G_M000_IG86:                ;; offset=0x099E
       mov      gword ptr [rdi+0x18], rax
       mov      word  ptr [rdi+0x22], 0
       mov      rdi, 0x7F7E094A1948
       mov      rax, 0x7F7E09CD0820
       call     rax
       cmp      dword ptr [rax], 2
       jle      G_M000_IG105
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x10]
       test     rax, rax
       je       G_M000_IG105
 
G_M000_IG87:                ;; offset=0x09D8
       mov      r14, gword ptr [rax+0x10]
       test     r14, r14
       jne      SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x09E1
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
       mov      r14, rax
 
G_M000_IG89:                ;; offset=0x09EA
       mov      gword ptr [rbp-0x228], r14
       mov      rdi, gword ptr [r14+0x08]
       mov      gword ptr [rbp-0x230], rdi
       mov      rdi, gword ptr [r14+0x10]
       mov      gword ptr [rbp-0x238], rdi
       jmp      G_M000_IG58
 
G_M000_IG90:                ;; offset=0x0A0C
       mov      rsi, r15
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG57
 
G_M000_IG91:                ;; offset=0x0A27
       mov      rdi, 0x7F7D8C7CF178
       cmp      qword ptr [r15], rdi
       je       G_M000_IG56
 
G_M000_IG92:                ;; offset=0x0A3A
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x88]
       mov      r11, 0x7F7D89E732E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG83
 
G_M000_IG93:                ;; offset=0x0A57
       mov      rdi, gword ptr [rbp-0x230]
       cmp      gword ptr [rdi+0x10], 0
       je       G_M000_IG65
 
G_M000_IG94:                ;; offset=0x0A69
       mov      rdi, r13
       mov      rsi, gword ptr [rbp-0x230]
       call     [System.Threading.ExecutionContext:OnValuesChanged(System.Threading.ExecutionContext,System.Threading.ExecutionContext)]
       jmp      G_M000_IG65
 
G_M000_IG95:                ;; offset=0x0A7E
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:ThrowForFailedGetResult():this]
       int3     
 
G_M000_IG96:                ;; offset=0x0A85
       mov      r12, r15
       xor      eax, eax
       mov      ecx, 1
       jmp      G_M000_IG70
 
G_M000_IG97:                ;; offset=0x0A94
       cmp      gword ptr [rdx+0x18], 0
       je       G_M000_IG71
 
G_M000_IG98:                ;; offset=0x0A9F
       mov      r15, gword ptr [rbp-0x40]
       test     r15, r15
       je       G_M000_IG71
       jmp      G_M000_IG110
 
G_M000_IG99:                ;; offset=0x0AB1
       mov      rdi, gword ptr [rbp-0x80]
       mov      esi, dword ptr [rdi+0x34]
       and      esi, 0x11000000
       cmp      esi, 0x1000000
       jne      G_M000_IG150
 
G_M000_IG100:                ;; offset=0x0ACA
       mov      rdi, gword ptr [rbp-0x80]
       movzx    r14, byte  ptr [rdi+0x38]
       xor      rdi, rdi
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      gword ptr [rdx+0x40], rdi
       jmp      G_M000_IG73
 
G_M000_IG101:                ;; offset=0x0AE5
       mov      rdx, bword ptr [rbp-0x1E8]
       vmovdqu  ymm0, ymmword ptr [rdx+0x78]
       vmovdqu  ymmword ptr [rbp-0x1D0], ymm0
       mov      rdi, qword ptr [rdx+0x98]
       mov      qword ptr [rbp-0x1B0], rdi
       mov      rsi, gword ptr [rdx+0x18]
       test     rsi, rsi
       jne      G_M000_IG192
 
G_M000_IG102:                ;; offset=0x0B14
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rsi, bword ptr [rdx+0x78]
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rsi+0x10]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rcx, qword ptr [rsi+0x20]
       mov      qword ptr [rsp+0x20], rcx
       movzx    rdx, word  ptr [rdx+0x60]
       mov      rdi, bword ptr [rbp-0x1E8]
       mov      rsi, qword ptr [rdi+0x50]
       mov      rcx, gword ptr [rdi+0x18]
       mov      rdi, rbx
       call     [SharpLink.Runtime.RpcSession:SendGeneratedStreamComplete(long,ushort,SharpLink.Abstractions.RpcDeadline,System.TimeProvider):this]
       xor      rax, rax
       mov      rdi, bword ptr [rbp-0x1E8]
       mov      gword ptr [rdi+0x38], rax
       jmp      G_M000_IG193
 
G_M000_IG103:                ;; offset=0x0B6A
       mov      rdi, 0x7F7D8CBBE6D0
       call     CORINFO_HELP_ISINSTANCEOFINTERFACE
       jmp      G_M000_IG50
 
G_M000_IG104:                ;; offset=0x0B7E
       xor      r12, r12
       xor      r14d, r14d
       xor      eax, eax
       xor      ecx, ecx
       jmp      G_M000_IG70
 
G_M000_IG105:                ;; offset=0x0B8D
       mov      edi, 2
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG87
 
G_M000_IG106:                ;; offset=0x0B9C
       call     [System.ThrowHelper:ThrowInvalidOperationException()]
       int3     
 
G_M000_IG107:                ;; offset=0x0BA3
       mov      rax, gword ptr [r13+0x18]
       mov      rax, gword ptr [rax+0x08]
       jmp      G_M000_IG96
 
G_M000_IG108:                ;; offset=0x0BB0
       mov      rdi, r15
       mov      r11, 0x7F7D89E73290
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this
       mov      gword ptr [rbp-0x180], rax
       mov      qword ptr [rbp-0x178], rdx
       mov      r12, gword ptr [rbp-0x180]
       movsx    r14, word  ptr [rbp-0x178]
       movzx    rax, byte  ptr [rbp-0x176]
       movzx    rcx, byte  ptr [rbp-0x175]
       jmp      G_M000_IG70
 
G_M000_IG109:                ;; offset=0x0BF0
       mov      rdi, r15
       mov      r11, 0x7F7D89E73258
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this
       mov      gword ptr [rbp-0x150], rax
       mov      qword ptr [rbp-0x148], rdx
       mov      r12, gword ptr [rbp-0x150]
       movsx    r14, word  ptr [rbp-0x148]
       movzx    rax, byte  ptr [rbp-0x146]
       movzx    rcx, byte  ptr [rbp-0x145]
       jmp      G_M000_IG70
 
G_M000_IG110:                ;; offset=0x0C30
       mov      r14, r15
       mov      rsi, 0x7F7D8CB9F788
       cmp      qword ptr [r14], rsi
       je       SHORT G_M000_IG112
 
G_M000_IG111:                ;; offset=0x0C42
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       jmp      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0C59
       xor      r14, r14
 
G_M000_IG113:                ;; offset=0x0C5C
       test     r14, r14
       je       SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0C61
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x1600000
       cmp      edi, 0x1000000
       jne      G_M000_IG128
       jmp      G_M000_IG71
 
G_M000_IG115:                ;; offset=0x0C7C
       mov      rdi, 0x7F7D8CB9F788
       cmp      qword ptr [r15], rdi
       jne      SHORT G_M000_IG116
       movsx    rsi, word  ptr [rbp-0x38]
       lea      rdi, bword ptr [r15+0x48]
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:GetStatus(short):int:this]
       jmp      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0C9C
       movsx    rsi, word  ptr [rbp-0x38]
       mov      rdi, r15
       mov      r11, 0x7F7D89E732A0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
 
G_M000_IG117:                ;; offset=0x0CB1
       cmp      eax, 1
       jne      G_M000_IG128
       jmp      G_M000_IG71
 
G_M000_IG118:                ;; offset=0x0CBF
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG119
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x0CE7
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x58]
       mov      r11, 0x7F7D89E732A8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG120:                ;; offset=0x0D06
       test     r14d, r14d
       jne      G_M000_IG72
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG121:                ;; offset=0x0D14
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0x58], edi
       lea      rdi, bword ptr [rdx+0xA0]
       lea      rsi, bword ptr [rbp-0x60]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x60]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG122:                ;; offset=0x0D4F
       lea      rdi, bword ptr [rdx+0xA0]
 
G_M000_IG123:                ;; offset=0x0D56
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG124:                ;; offset=0x0D5F
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x58], -1
       jmp      G_M000_IG72
 
G_M000_IG125:                ;; offset=0x0D7B
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG127
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG126
       mov      rdi, r14
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG126:                ;; offset=0x0DB2
       movzx    r14, byte  ptr [r14+0x38]
       jmp      G_M000_IG73
 
G_M000_IG127:                ;; offset=0x0DBC
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x58]
       mov      r11, 0x7F7D89E732B0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r14d, eax
       jmp      G_M000_IG73
 
G_M000_IG128:                ;; offset=0x0DD9
       lea      rdi, [rbp-0x40]
       call     [System.Threading.Tasks.ValueTask`1[bool]:AsTask():System.Threading.Tasks.Task`1[bool]:this]
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rdi, bword ptr [rdx+0x40]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x1E8]
 
G_M000_IG129:                ;; offset=0x0DFD
       cmp      dword ptr [rbp-0x2C], 1
       je       G_M000_IG136
 
G_M000_IG130:                ;; offset=0x0E07
       mov      rdi, gword ptr [rdx+0x40]
       vmovdqu  ymm0, ymmword ptr [rdx+0x78]
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       mov      rsi, qword ptr [rdx+0x98]
       mov      qword ptr [rbp-0xF8], rsi
       mov      rsi, gword ptr [rdx+0x18]
       mov      rax, gword ptr [rdx+0x20]
       cmp      byte  ptr [rax+0x24], 0
       je       SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x0E34
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG132:                ;; offset=0x0E40
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rbp-0x108]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rcx, qword ptr [rbp-0xF8]
       mov      qword ptr [rsp+0x20], rcx
       mov      rdx, rax
       call     [SharpLink.Abstractions.SharpLinkTimer:WaitAsync(System.Threading.Tasks.Task,SharpLink.Abstractions.RpcDeadline,System.TimeProvider,System.Threading.CancellationToken):System.Threading.Tasks.ValueTask`1[bool]]
       mov      gword ptr [rbp-0x70], rax
       mov      qword ptr [rbp-0x68], rdx
       mov      rsi, gword ptr [rbp-0x70]
       movzx    rdi, byte  ptr [rbp-0x66]
       movsx    rax, word  ptr [rbp-0x68]
       mov      gword ptr [rbp-0x60], rsi
       mov      word  ptr [rbp-0x58], ax
       mov      byte  ptr [rbp-0x56], dil
       mov      byte  ptr [rbp-0x55], 0
       mov      r15, gword ptr [rbp-0x60]
       test     r15, r15
       je       G_M000_IG139
 
G_M000_IG133:                ;; offset=0x0EA3
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG134
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x0ECB
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x58]
       mov      r11, 0x7F7D89E732B8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG135:                ;; offset=0x0EEA
       test     r14d, r14d
       jne      SHORT G_M000_IG139
       mov      dword ptr [rbp-0x2C], 1
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0x58], 1
       lea      rdi, bword ptr [rdx+0xA0]
       lea      rsi, bword ptr [rbp-0x60]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x60]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG136:                ;; offset=0x0F35
       lea      rdi, bword ptr [rdx+0xA0]
 
G_M000_IG137:                ;; offset=0x0F3C
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG138:                ;; offset=0x0F45
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x58], -1
 
G_M000_IG139:                ;; offset=0x0F5C
       mov      r15, gword ptr [rbp-0x60]
       test     r15, r15
       jne      SHORT G_M000_IG140
       movzx    r14, byte  ptr [rbp-0x56]
       jmp      SHORT G_M000_IG143
 
G_M000_IG140:                ;; offset=0x0F6C
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG142
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG141
       mov      rdi, r14
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG141:                ;; offset=0x0FA3
       movzx    r14, byte  ptr [r14+0x38]
       jmp      SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x0FAA
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x58]
       mov      r11, 0x7F7D89E732C0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r14d, eax
 
G_M000_IG143:                ;; offset=0x0FC2
       test     r14d, r14d
       jne      SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x0FC7
       call     [SharpLink.Runtime.RpcSession:CreateGeneratedStreamDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rbx, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 1
       mov      rsi, gword ptr [rdx+0x20]
       mov      rdi, rbx
       xor      rdx, rdx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateOwnerCore(System.Exception,System.Threading.CancellationTokenSource,System.Exception):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r15, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x40]
       mov      rsi, gword ptr [rdx+0x28]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, r15
       call     [SharpLink.Runtime.RpcSession:CompleteAbandonedGeneratedStreamAsync[int](System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r15
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG145:                ;; offset=0x1020
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x40]
       cmp      byte  ptr [rdi], dil
       mov      gword ptr [rbp-0x80], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x78], edi
       test     byte  ptr [rbp-0x78], 4
       jne      SHORT G_M000_IG146
       mov      rdi, gword ptr [rbp-0x80]
       test     dword ptr [rdi+0x34], 0x1600000
       jne      G_M000_IG99
 
G_M000_IG146:                ;; offset=0x104E
       mov      dword ptr [rbp-0x2C], 2
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0x58], 2
       lea      rdi, bword ptr [rdx+0xB0]
       mov      rsi, gword ptr [rbp-0x80]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [rbp-0x78]
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0xB8], esi
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x80]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG147:                ;; offset=0x10A2
       lea      rsi, bword ptr [rdx+0xB0]
 
G_M000_IG148:                ;; offset=0x10A9
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
 
G_M000_IG149:                ;; offset=0x10B2
       xor      edi, edi
       mov      qword ptr [rsi], rdi
       mov      qword ptr [rsi+0x08], rdi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x58], -1
       jmp      G_M000_IG99
 
G_M000_IG150:                ;; offset=0x10CE
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG100
 
G_M000_IG151:                ;; offset=0x10DB
       mov      r11, 0x7F7D89E732C8
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      r14d, eax
       jmp      G_M000_IG75
 
G_M000_IG152:                ;; offset=0x10F0
       mov      r11, 0x7F7D89E73268
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      r14d, eax
       jmp      G_M000_IG75
 
G_M000_IG153:                ;; offset=0x1105
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG154:                ;; offset=0x1111
       lea      rdx, [rbp-0x1A0]
       lea      rcx, [rbp-0x1A8]
       lea      rsi, [rbp-0x198]
       mov      rdi, rax
       mov      r11, 0x7F7D89E732D0
       call     [r11]SharpLink.Abstractions.IRpcSizedCodec`1[int]:TryGetEncodedSize(byref,byref,byref):bool:this
       test     eax, eax
       je       G_M000_IG77
       mov      rdi, gword ptr [rbp-0x1A8]
       mov      gword ptr [rsp], rdi
       mov      r14, gword ptr [rbp-0x240]
       mov      gword ptr [rsp+0x08], r14
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rsp+0x20], xmm0
       mov      rdi, qword ptr [rbp-0xA8]
       mov      qword ptr [rsp+0x30], rdi
       mov      r14, gword ptr [rbp-0x218]
       mov      gword ptr [rsp+0x38], r14
       mov      rdi, rbx
       mov      rsi, r15
       mov      edx, r13d
       mov      ecx, dword ptr [rbp-0x198]
       mov      r8, gword ptr [rbp-0x210]
       mov      r9d, dword ptr [rbp-0x1A0]
       call     [SharpLink.Runtime.RpcSession:SendStreamChunkKnownSizeAsync[int](long,ushort,int,SharpLink.Abstractions.IRpcSizedCodec`1[int],int,SharpLink.Abstractions.IRpcSizedCodecSnapshot,System.Threading.CancellationToken,SharpLink.Abstractions.RpcDeadline,System.TimeProvider):System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0x190], rax
       mov      qword ptr [rbp-0x188], rdx
       jmp      G_M000_IG78
 
G_M000_IG155:                ;; offset=0x11BF
       mov      edi, 0x270C
       mov      rsi, 0x7F7D8AF5C6A8
       call     [CORINFO_HELP_STRCNS]
       mov      rdi, rax
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG156:                ;; offset=0x11DE
       mov      rsi, r15
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG157
       mov      rdi, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG158
 
G_M000_IG157:                ;; offset=0x1200
       movsx    rsi, word  ptr [rbp-0x48]
       mov      rdi, r15
       mov      r11, 0x7F7D89E732D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG158:                ;; offset=0x121E
       test     eax, eax
       je       G_M000_IG166
       jmp      G_M000_IG81
 
G_M000_IG159:                ;; offset=0x122B
       mov      rsi, r15
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG160
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x1253
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x88]
       mov      r11, 0x7F7D89E732E0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG161:                ;; offset=0x1275
       test     r14d, r14d
       mov      rdx, bword ptr [rbp-0x1E8]
       jne      G_M000_IG82
       mov      dword ptr [rbp-0x2C], 3
       mov      dword ptr [rdx+0x58], 3
       lea      rdi, bword ptr [rdx+0xC0]
       lea      rsi, bword ptr [rbp-0x90]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x90]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG162:                ;; offset=0x12CA
       lea      rdi, bword ptr [rdx+0xC0]
 
G_M000_IG163:                ;; offset=0x12D1
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG164:                ;; offset=0x12DD
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x58], -1
       jmp      G_M000_IG82
 
G_M000_IG165:                ;; offset=0x12F9
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG83
 
G_M000_IG166:                ;; offset=0x1309
       lea      rdi, [rbp-0x50]
       call     [System.Threading.Tasks.ValueTask:AsTask():System.Threading.Tasks.Task:this]
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rdi, bword ptr [rdx+0x48]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x1E8]
 
G_M000_IG167:                ;; offset=0x132D
       cmp      dword ptr [rbp-0x2C], 4
       je       G_M000_IG174
 
G_M000_IG168:                ;; offset=0x1337
       mov      rdi, gword ptr [rdx+0x48]
       vmovdqu  ymm0, ymmword ptr [rdx+0x78]
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       mov      rsi, qword ptr [rdx+0x98]
       mov      qword ptr [rbp-0xD0], rsi
       mov      rsi, gword ptr [rdx+0x18]
       mov      rax, gword ptr [rdx+0x20]
       cmp      byte  ptr [rax+0x24], 0
       je       SHORT G_M000_IG170
 
G_M000_IG169:                ;; offset=0x1364
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG170:                ;; offset=0x1370
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rcx, qword ptr [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rcx
       mov      rdx, rax
       call     [SharpLink.Abstractions.SharpLinkTimer:WaitAsync(System.Threading.Tasks.Task,SharpLink.Abstractions.RpcDeadline,System.TimeProvider,System.Threading.CancellationToken):System.Threading.Tasks.ValueTask`1[bool]]
       mov      gword ptr [rbp-0x70], rax
       mov      qword ptr [rbp-0x68], rdx
       mov      rsi, gword ptr [rbp-0x70]
       movzx    rdi, byte  ptr [rbp-0x66]
       movsx    rax, word  ptr [rbp-0x68]
       mov      gword ptr [rbp-0x60], rsi
       mov      word  ptr [rbp-0x58], ax
       mov      byte  ptr [rbp-0x56], dil
       mov      byte  ptr [rbp-0x55], 0
       mov      r15, gword ptr [rbp-0x60]
       test     r15, r15
       je       G_M000_IG177
 
G_M000_IG171:                ;; offset=0x13D3
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG172
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG173
 
G_M000_IG172:                ;; offset=0x13FB
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x58]
       mov      r11, 0x7F7D89E732F0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG173:                ;; offset=0x141A
       test     r14d, r14d
       jne      SHORT G_M000_IG177
       mov      dword ptr [rbp-0x2C], 4
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0x58], 4
       lea      rdi, bword ptr [rdx+0xA0]
       lea      rsi, bword ptr [rbp-0x60]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x60]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG174:                ;; offset=0x1465
       lea      rdi, bword ptr [rdx+0xA0]
 
G_M000_IG175:                ;; offset=0x146C
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG176:                ;; offset=0x1475
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x58], -1
 
G_M000_IG177:                ;; offset=0x148C
       mov      r15, gword ptr [rbp-0x60]
       test     r15, r15
       jne      SHORT G_M000_IG178
       movzx    r14, byte  ptr [rbp-0x56]
       jmp      SHORT G_M000_IG181
 
G_M000_IG178:                ;; offset=0x149C
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG180
       mov      edi, dword ptr [r14+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG179
       mov      rdi, r14
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG179:                ;; offset=0x14D3
       movzx    r14, byte  ptr [r14+0x38]
       jmp      SHORT G_M000_IG181
 
G_M000_IG180:                ;; offset=0x14DA
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x58]
       mov      r11, 0x7F7D89E732F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r14d, eax
 
G_M000_IG181:                ;; offset=0x14F2
       test     r14d, r14d
       jne      SHORT G_M000_IG183
 
G_M000_IG182:                ;; offset=0x14F7
       call     [SharpLink.Runtime.RpcSession:CreateGeneratedStreamDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rbx, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 1
       mov      rsi, gword ptr [rdx+0x20]
       mov      rdi, rbx
       xor      rdx, rdx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateOwnerCore(System.Exception,System.Threading.CancellationTokenSource,System.Exception):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r15, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x48]
       mov      rsi, gword ptr [rdx+0x28]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, r15
       call     [SharpLink.Runtime.RpcSession:CompleteAbandonedGeneratedStreamAsync[int](System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r15
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG183:                ;; offset=0x1550
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x48]
       cmp      byte  ptr [rdi], dil
       mov      gword ptr [rbp-0xA0], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x98], edi
       test     byte  ptr [rbp-0x98], 4
       jne      SHORT G_M000_IG185
 
G_M000_IG184:                ;; offset=0x1576
       mov      rdi, gword ptr [rbp-0xA0]
       test     dword ptr [rdi+0x34], 0x1600000
       jne      G_M000_IG189
 
G_M000_IG185:                ;; offset=0x158A
       mov      dword ptr [rbp-0x2C], 5
       mov      dword ptr [rdx+0x58], 5
       lea      rdi, bword ptr [rdx+0xD0]
       mov      rsi, gword ptr [rbp-0xA0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0xD8], esi
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredTaskAwaitable+ConfiguredTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG186:                ;; offset=0x15E0
       lea      rsi, bword ptr [rdx+0xD0]
 
G_M000_IG187:                ;; offset=0x15E7
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG188:                ;; offset=0x15F3
       xor      edi, edi
       mov      qword ptr [rsi], rdi
       mov      qword ptr [rsi+0x08], rdi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x58], -1
 
G_M000_IG189:                ;; offset=0x160A
       mov      rdi, gword ptr [rbp-0xA0]
       mov      esi, dword ptr [rbp-0x98]
       mov      eax, dword ptr [rdi+0x34]
       and      eax, 0x11000000
       cmp      eax, 0x1000000
       je       SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x1626
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       mov      rdx, bword ptr [rbp-0x1E8]
 
G_M000_IG191:                ;; offset=0x1633
       xor      rax, rax
       mov      gword ptr [rdx+0x48], rax
       jmp      G_M000_IG83
 
G_M000_IG192:                ;; offset=0x163E
       lea      rdi, [rbp-0x1D0]
       call     [SharpLink.Abstractions.RpcDeadline:IsExpired(System.TimeProvider):bool:this]
       test     eax, eax
       je       G_M000_IG102
       call     [SharpLink.Runtime.RpcSession:CreateGeneratedStreamDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG193:                ;; offset=0x1662
       mov      rdx, bword ptr [rbp-0x1E8]
       cmp      byte  ptr [rdx+0x63], 0
       jne      G_M000_IG220
 
G_M000_IG194:                ;; offset=0x1673
       cmp      dword ptr [rbp-0x2C], 6
       je       G_M000_IG201
 
G_M000_IG195:                ;; offset=0x167D
       mov      rdi, gword ptr [rdx+0x20]
       call     [SharpLink.Runtime.RpcSession:TryCancelGeneratedLifetime(System.Threading.CancellationTokenSource)]
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x28]
       mov      rax, 0x7F7D8CBC0298
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG205
       mov      rdi, gword ptr [rdi+0x10]
       mov      rax, 0x7F7D8CBBC468
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG204
       call     [PhysicalTcp.ScalarStreamService+<DownloadAsync>d__0:System.IAsyncDisposable.DisposeAsync():System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
 
G_M000_IG196:                ;; offset=0x16D0
       vmovdqu  xmm0, xmmword ptr [rbp-0x1E0]
       vmovdqu  xmmword ptr [rbp-0x160], xmm0
 
G_M000_IG197:                ;; offset=0x16E0
       mov      rsi, gword ptr [rbp-0x160]
       movsx    rdi, word  ptr [rbp-0x158]
       mov      gword ptr [rbp-0x90], rsi
       mov      word  ptr [rbp-0x88], di
       mov      byte  ptr [rbp-0x86], 0
       mov      rbx, gword ptr [rbp-0x90]
       test     rbx, rbx
       jne      G_M000_IG206
 
G_M000_IG198:                ;; offset=0x1714
       mov      rbx, gword ptr [rbp-0x90]
       test     rbx, rbx
       je       G_M000_IG213
 
G_M000_IG199:                ;; offset=0x1724
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG209
 
G_M000_IG200:                ;; offset=0x173F
       mov      rdi, 0x7F7D8C7CF178
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG212
       jmp      G_M000_IG211
 
G_M000_IG201:                ;; offset=0x1757
       lea      rdi, bword ptr [rdx+0xC0]
 
G_M000_IG202:                ;; offset=0x175E
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG203:                ;; offset=0x176A
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rdx+0x58], -1
       jmp      SHORT G_M000_IG198
 
G_M000_IG204:                ;; offset=0x177C
       mov      r11, 0x7F7D89E73300
       call     [r11]System.IAsyncDisposable:DisposeAsync():System.Threading.Tasks.ValueTask:this
       mov      gword ptr [rbp-0x1E0], rax
       mov      qword ptr [rbp-0x1D8], rdx
       jmp      G_M000_IG196
 
G_M000_IG205:                ;; offset=0x179C
       mov      r11, 0x7F7D89E73260
       call     [r11]System.IAsyncDisposable:DisposeAsync():System.Threading.Tasks.ValueTask:this
       mov      gword ptr [rbp-0x160], rax
       mov      qword ptr [rbp-0x158], rdx
       jmp      G_M000_IG197
 
G_M000_IG206:                ;; offset=0x17BC
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG207
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG208
 
G_M000_IG207:                ;; offset=0x17E4
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x88]
       mov      r11, 0x7F7D89E73308
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG208:                ;; offset=0x1806
       test     r15d, r15d
       jne      G_M000_IG198
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0x58], 6
       lea      rdi, bword ptr [rdx+0xC0]
       lea      rsi, bword ptr [rbp-0x90]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       lea      rsi, bword ptr [rdx+0x68]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x90]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG238
 
G_M000_IG209:                ;; offset=0x1854
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG213
 
G_M000_IG210:                ;; offset=0x1865
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG213
 
G_M000_IG211:                ;; offset=0x1872
       movsx    rsi, word  ptr [rbp-0x88]
       mov      rdi, rbx
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       jmp      SHORT G_M000_IG213
 
G_M000_IG212:                ;; offset=0x1885
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x88]
       mov      r11, 0x7F7D89E73310
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       nop      
 
G_M000_IG213:                ;; offset=0x189E
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rbx, gword ptr [rdx+0x20]
       mov      rdi, 0x7F7D8C7D5810
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG224
 
G_M000_IG214:                ;; offset=0x18BC
       cmp      byte  ptr [rbx+0x24], 0
       jne      SHORT G_M000_IG219
       lea      r15, bword ptr [rbx+0x28]
       mov      r14, gword ptr [r15]
       test     r14, r14
       je       SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x18CE
       mov      rdi, gword ptr [r14+0x08]
       mov      rsi, qword ptr [r15+0x08]
       mov      rdx, r14
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource+Registrations:Unregister(long,System.Threading.CancellationTokenSource+CallbackNode):bool:this]
       test     eax, eax
       je       G_M000_IG223
 
G_M000_IG216:                ;; offset=0x18E9
       cmp      byte  ptr [rbx+0x24], 0
       jne      SHORT G_M000_IG219
       mov      rdi, gword ptr [rbx+0x08]
       test     rdi, rdi
       jne      G_M000_IG233
 
G_M000_IG217:                ;; offset=0x18FC
       xor      rdi, rdi
       mov      gword ptr [rbx+0x18], rdi
       cmp      gword ptr [rbx+0x10], 0
       jne      G_M000_IG234
 
G_M000_IG218:                ;; offset=0x190D
       mov      byte  ptr [rbx+0x24], 1
 
G_M000_IG219:                ;; offset=0x1911
       mov      rdi, rbx
       call     [System.GC:SuppressFinalize(System.Object)]
 
G_M000_IG220:                ;; offset=0x191A
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rbx, gword ptr [rdx+0x30]
       test     rbx, rbx
       jne      SHORT G_M000_IG222
 
G_M000_IG221:                ;; offset=0x192A
       xor      rdi, rdi
       mov      gword ptr [rdx+0x30], rdi
       jmp      G_M000_IG236
 
G_M000_IG222:                ;; offset=0x1935
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AE905D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG235
       mov      rdi, rax
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Capture(System.Exception):System.Runtime.ExceptionServices.ExceptionDispatchInfo]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Throw():this]
       int3     
 
G_M000_IG223:                ;; offset=0x1965
       mov      rdi, qword ptr [r15+0x08]
       mov      rsi, r14
       call     [System.Threading.CancellationTokenRegistration:<Dispose>g__WaitForCallbackIfNecessary|3_0(long,System.Threading.CancellationTokenSource+CallbackNode)]
       jmp      G_M000_IG216
 
G_M000_IG224:                ;; offset=0x1977
       mov      rdi, rbx
       mov      esi, 1
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Threading.CancellationTokenSource:Dispose(bool):this
       jmp      SHORT G_M000_IG219
 
G_M000_IG225:                ;; offset=0x198B
       mov      edi, 0xBDEF
       mov      rsi, 0x7F7D8AF5C6A8
       call     [CORINFO_HELP_STRCNS]
       mov      rdi, rax
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG226:                ;; offset=0x19AA
       mov      edi, 0x270C
       mov      rsi, 0x7F7D8AF5C6A8
       call     [CORINFO_HELP_STRCNS]
       mov      rdi, rax
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG227:                ;; offset=0x19C9
       mov      edi, 2
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG06
 
G_M000_IG228:                ;; offset=0x19D8
       mov      rdi, 0x7F7D8B9A9198
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       jmp      G_M000_IG30
 
G_M000_IG229:                ;; offset=0x19EF
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG230:                ;; offset=0x19F6
       mov      rdi, gword ptr [rbp-0x220]
       mov      qword ptr [rbp-0x170], rax
       mov      rsi, rax
       mov      rdx, r12
       call     [System.Threading.CancellationTokenSource+Registrations:Unregister(long,System.Threading.CancellationTokenSource+CallbackNode):bool:this]
       test     eax, eax
       mov      rax, qword ptr [rbp-0x170]
       je       G_M000_IG28
 
G_M000_IG231:                ;; offset=0x1A1F
       mov      rdi, r13
       mov      rsi, r14
       mov      rdx, r15
       call     [System.Threading.CancellationTokenSource:Invoke(System.Delegate,System.Object,System.Threading.CancellationTokenSource)]
 
G_M000_IG232:                ;; offset=0x1A2E
       xor      r12, r12
       xor      r15d, r15d
       jmp      G_M000_IG29
 
G_M000_IG233:                ;; offset=0x1A39
       xor      r11, r11
       mov      gword ptr [rbx+0x08], r11
       mov      r11, 0x7F7D89E73318
       call     [r11]System.IDisposable:Dispose():this
       jmp      G_M000_IG217
 
G_M000_IG234:                ;; offset=0x1A52
       lea      rdi, bword ptr [rbx+0x10]
       xor      rsi, rsi
       mov      r15, rsi
       xchg     gword ptr [rdi], r15
       test     r15, r15
       je       G_M000_IG218
       cmp      dword ptr [rbx+0x20], 1
       je       G_M000_IG218
       mov      rdi, r15
       mov      esi, 1
       call     [System.Threading.WaitHandle:Dispose(bool):this]
       mov      rdi, r15
       call     [System.GC:SuppressFinalize(System.Object)]
       jmp      G_M000_IG218
 
G_M000_IG235:                ;; offset=0x1A8D
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG236:                ;; offset=0x1A96
       mov      dword ptr [rdx+0x58], -2
       lea      rdi, bword ptr [rdx+0x68]
       cmp      gword ptr [rdi], 0
       jne      SHORT G_M000_IG240
 
G_M000_IG237:                ;; offset=0x1AA7
       mov      rsi, 0x7F75A5801810
       mov      rsi, gword ptr [rsi]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG238:                ;; offset=0x1AB9
       nop      
 
G_M000_IG239:                ;; offset=0x1ABA
       vzeroupper 
       add      rsp, 616
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG240:                ;; offset=0x1ACF
       mov      rdi, gword ptr [rdi]
       xor      esi, esi
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:SetExistingTaskResult(System.Threading.Tasks.Task`1[System.Threading.Tasks.VoidTaskResult],System.Threading.Tasks.VoidTaskResult)]
       jmp      SHORT G_M000_IG238
 
G_M000_IG241:                ;; offset=0x1ADC
       sub      rsp, 72
 
G_M000_IG242:                ;; offset=0x1AE0
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rdx+0x20]
       mov      edx, 1
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:TransferLifetime(System.Exception,System.Threading.CancellationTokenSource,bool):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG244
 
G_M000_IG243:                ;; offset=0x1AFB
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG244:                ;; offset=0x1B04
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x20]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG245:                ;; offset=0x1B1D
       sub      rsp, 72
 
G_M000_IG246:                ;; offset=0x1B21
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C1528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG248
 
G_M000_IG247:                ;; offset=0x1B38
       xor      eax, eax
       jmp      SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x1B3C
       mov      gword ptr [rbp-0x1F0], rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x20]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG249:                ;; offset=0x1B5E
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG250:                ;; offset=0x1B66
       sub      rsp, 72
 
G_M000_IG251:                ;; offset=0x1B6A
       mov      rdi, gword ptr [rbp-0x1F0]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      rbx, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 1
       mov      rdx, gword ptr [rdx+0x20]
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x1F0]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r15, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x40]
       mov      rsi, gword ptr [rdx+0x28]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, r15
       call     [SharpLink.Runtime.RpcSession:CompleteAbandonedGeneratedStreamAsync[int](System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r15
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG252:                ;; offset=0x1BCF
       sub      rsp, 72
 
G_M000_IG253:                ;; offset=0x1BD3
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C1528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG255
 
G_M000_IG254:                ;; offset=0x1BEA
       xor      eax, eax
       jmp      SHORT G_M000_IG256
 
G_M000_IG255:                ;; offset=0x1BEE
       mov      gword ptr [rbp-0x1F8], rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x20]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG256:                ;; offset=0x1C10
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG257:                ;; offset=0x1C18
       sub      rsp, 72
 
G_M000_IG258:                ;; offset=0x1C1C
       mov      rdi, gword ptr [rbp-0x1F8]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      rbx, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 1
       mov      rdx, gword ptr [rdx+0x20]
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x1F8]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r15, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x48]
       mov      rsi, gword ptr [rdx+0x28]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, r15
       call     [SharpLink.Runtime.RpcSession:CompleteAbandonedGeneratedStreamAsync[int](System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r15
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG259:                ;; offset=0x1C81
       sub      rsp, 72
 
G_M000_IG260:                ;; offset=0x1C85
       mov      rdi, gword ptr [rbp-0x238]
       mov      rsi, gword ptr [rbp-0x228]
       cmp      rdi, gword ptr [rsi+0x10]
       je       SHORT G_M000_IG262
 
G_M000_IG261:                ;; offset=0x1C99
       mov      rdi, gword ptr [rbp-0x228]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, gword ptr [rbp-0x238]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG262:                ;; offset=0x1CB0
       mov      rdi, gword ptr [rbp-0x228]
       mov      r13, gword ptr [rdi+0x08]
       cmp      gword ptr [rbp-0x230], r13
       je       SHORT G_M000_IG268
 
G_M000_IG263:                ;; offset=0x1CC4
       mov      rdi, gword ptr [rbp-0x228]
       lea      rdi, bword ptr [rdi+0x08]
       mov      rsi, gword ptr [rbp-0x230]
       call     CORINFO_HELP_ASSIGN_REF
       test     r13, r13
       je       SHORT G_M000_IG265
 
G_M000_IG264:                ;; offset=0x1CE0
       cmp      gword ptr [r13+0x10], 0
       jne      SHORT G_M000_IG267
 
G_M000_IG265:                ;; offset=0x1CE7
       cmp      gword ptr [rbp-0x230], 0
       je       SHORT G_M000_IG268
 
G_M000_IG266:                ;; offset=0x1CF1
       mov      rdi, gword ptr [rbp-0x230]
       cmp      gword ptr [rdi+0x10], 0
       je       SHORT G_M000_IG268
 
G_M000_IG267:                ;; offset=0x1CFF
       mov      rdi, r13
       mov      rsi, gword ptr [rbp-0x230]
       call     [System.Threading.ExecutionContext:OnValuesChanged(System.Threading.ExecutionContext,System.Threading.ExecutionContext)]
 
G_M000_IG268:                ;; offset=0x1D0F
       nop      
 
G_M000_IG269:                ;; offset=0x1D10
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG270:                ;; offset=0x1D18
       sub      rsp, 72
 
G_M000_IG271:                ;; offset=0x1D1C
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C0880
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG273
 
G_M000_IG272:                ;; offset=0x1D36
       xor      eax, eax
       jmp      SHORT G_M000_IG281
 
G_M000_IG273:                ;; offset=0x1D3A
       mov      gword ptr [rbp-0x200], rsi
       mov      rdx, bword ptr [rbp-0x1E8]
       cmp      byte  ptr [rdx+0x63], 0
       jne      SHORT G_M000_IG279
 
G_M000_IG274:                ;; offset=0x1D4E
       mov      rdi, gword ptr [rbp-0x200]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Abstractions.SharpLinkException:get_Code():int:this]
       cmp      eax, 13
       jne      SHORT G_M000_IG279
 
G_M000_IG275:                ;; offset=0x1D62
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rdx+0x18]
       test     rsi, rsi
       je       SHORT G_M000_IG277
 
G_M000_IG276:                ;; offset=0x1D72
       lea      rdi, bword ptr [rdx+0x78]
       call     [SharpLink.Abstractions.RpcDeadline:IsExpired(System.TimeProvider):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x1D80
       mov      rdi, gword ptr [rbp-0x200]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG280
 
G_M000_IG278:                ;; offset=0x1D98
       mov      ebx, 1
       jmp      SHORT G_M000_IG280
 
G_M000_IG279:                ;; offset=0x1D9F
       xor      ebx, ebx
 
G_M000_IG280:                ;; offset=0x1DA1
       test     ebx, ebx
       setne    al
       movzx    rax, al
 
G_M000_IG281:                ;; offset=0x1DA9
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG282:                ;; offset=0x1DB1
       sub      rsp, 72
 
G_M000_IG283:                ;; offset=0x1DB5
       mov      rdi, gword ptr [rbp-0x200]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Abstractions.SharpLinkException:get_Code():int:this]
       mov      ebx, eax
       mov      rdi, gword ptr [rbp-0x200]
       call     [SharpLink.Abstractions.SharpLinkException:get_DetailCode():ushort:this]
       mov      r15d, eax
       mov      rdi, 0x7F7D8C7C0880
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdi, gword ptr [rbp-0x200]
       mov      rax, qword ptr [rdi]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]System.Exception:get_Message():System.String:this
       mov      rcx, rax
       mov      esi, ebx
       mov      edx, r15d
       mov      rdi, r14
       mov      r8, gword ptr [rbp-0x200]
       call     [SharpLink.Abstractions.SharpLinkException:.ctor(int,ushort,System.String,System.Exception):this]
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 1
       mov      rdx, gword ptr [rdx+0x20]
       mov      rdi, r14
       mov      rsi, gword ptr [rbp-0x200]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      rbx, rax
       mov      rdi, gword ptr [rbp-0x200]
       call     [System.Threading.Tasks.Task:FromException(System.Exception):System.Threading.Tasks.Task]
       mov      rdi, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rdx+0x28]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, rbx
       call     [SharpLink.Runtime.RpcSession:CompleteAbandonedGeneratedStreamAsync[int](System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r14
 
G_M000_IG284:                ;; offset=0x1E6C
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG285:                ;; offset=0x1E72
       sub      rsp, 72
 
G_M000_IG286:                ;; offset=0x1E76
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C1528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdx, rax
       test     rdx, rdx
       jne      SHORT G_M000_IG288
 
G_M000_IG287:                ;; offset=0x1E90
       xor      eax, eax
       jmp      SHORT G_M000_IG294
 
G_M000_IG288:                ;; offset=0x1E94
       mov      gword ptr [rbp-0x208], rdx
       mov      rdx, bword ptr [rbp-0x1E8]
       cmp      byte  ptr [rdx+0x63], 0
       jne      SHORT G_M000_IG292
 
G_M000_IG289:                ;; offset=0x1EA8
       mov      rdi, gword ptr [rdx+0x20]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG291
 
G_M000_IG290:                ;; offset=0x1EB8
       mov      rdi, gword ptr [rbp-0x208]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       setne    al
       movzx    rax, al
       mov      rdx, bword ptr [rbp-0x1E8]
       jmp      SHORT G_M000_IG293
 
G_M000_IG291:                ;; offset=0x1ED7
       mov      eax, 1
       mov      rdx, bword ptr [rbp-0x1E8]
       jmp      SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0x1EE5
       xor      eax, eax
 
G_M000_IG293:                ;; offset=0x1EE7
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG294:                ;; offset=0x1EEF
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG295:                ;; offset=0x1EF7
       sub      rsp, 72
 
G_M000_IG296:                ;; offset=0x1EFB
       mov      rdi, gword ptr [rbp-0x208]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      rbx, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      byte  ptr [rdx+0x63], 1
       mov      rdx, gword ptr [rdx+0x20]
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x208]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r15, rax
       mov      rdi, gword ptr [rbp-0x208]
       call     [System.Threading.Tasks.Task:FromException(System.Exception):System.Threading.Tasks.Task]
       mov      rdi, rax
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rdx+0x28]
       mov      rdx, gword ptr [rdx+0x20]
       mov      rcx, r15
       call     [SharpLink.Runtime.RpcSession:CompleteAbandonedGeneratedStreamAsync[int](System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r15
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG297:                ;; offset=0x1F6C
       sub      rsp, 72
 
G_M000_IG298:                ;; offset=0x1F70
       mov      rsi, rdi
       mov      rdx, bword ptr [rbp-0x1E8]
       lea      rdi, bword ptr [rdx+0x30]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rax, G_M000_IG193
 
G_M000_IG299:                ;; offset=0x1F8A
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG300:                ;; offset=0x1F92
       sub      rsp, 72
 
G_M000_IG301:                ;; offset=0x1F96
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rsi, gword ptr [rdx+0x20]
       mov      edx, 1
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:TransferLifetime(System.Exception,System.Threading.CancellationTokenSource,bool):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG303
 
G_M000_IG302:                ;; offset=0x1FB1
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG303:                ;; offset=0x1FBA
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      rdi, gword ptr [rdx+0x20]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG304:                ;; offset=0x1FD3
       sub      rsp, 72
 
G_M000_IG305:                ;; offset=0x1FD7
       mov      rsi, rdi
       mov      rdx, bword ptr [rbp-0x1E8]
       mov      dword ptr [rdx+0x58], -2
       lea      rdi, bword ptr [rdx+0x68]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder:SetException(System.Exception):this]
       lea      rax, G_M000_IG238
 
G_M000_IG306:                ;; offset=0x1FF9
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00000CECh ; case G_M000_IG122
       	dd	00000D9Ah ; case G_M000_IG129
       	dd	0000103Fh ; case G_M000_IG147
       	dd	00001267h ; case G_M000_IG162
       	dd	000012CAh ; case G_M000_IG167
       	dd	0000157Dh ; case G_M000_IG186

; Total bytes 8193
