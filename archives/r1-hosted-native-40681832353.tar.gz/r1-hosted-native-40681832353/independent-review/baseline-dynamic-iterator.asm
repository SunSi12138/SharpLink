; SharpLink.Client.SharpLinkModuleRpcChannel+<InvokeServerStreamingDeferred>d__13`2[PhysicalTcp.__IScalarStream_SharpLinkRequest_ACC1F20B0513B621,int]:MoveNext():this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 210880
; 11 inlinees with PGO data; 32 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0xE0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu  ymmword ptr [rbp-0x60], ymm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      gword ptr [rbp-0x70], rdi
       mov      rdx, rdi
 
G_M000_IG02:                ;; offset=0x0031
       mov      edi, dword ptr [rdx+0x58]
       mov      dword ptr [rbp-0x1C], edi
       mov      rbx, gword ptr [rdx+0x10]
 
G_M000_IG03:                ;; offset=0x003B
       mov      edi, dword ptr [rbp-0x1C]
       add      edi, 4
       cmp      edi, 5
       ja       G_M000_IG55
 
G_M000_IG04:                ;; offset=0x004A
       mov      eax, 49
       bt       eax, edi
       jae      G_M000_IG55
 
G_M000_IG05:                ;; offset=0x0058
       cmp      dword ptr [rbp-0x1C], -4
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x005E
       cmp      dword ptr [rbp-0x1C], 0
       jne      G_M000_IG48
 
G_M000_IG07:                ;; offset=0x0068
       cmp      dword ptr [rbp-0x1C], -4
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x006E
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x58], -1
       cmp      byte  ptr [rdx+0x68], 0
       jne      G_M000_IG30
 
G_M000_IG09:                ;; offset=0x0086
       cmp      dword ptr [rbp-0x1C], 0
       je       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x008C
       xor      edi, edi
       mov      dword ptr [rdx+0x5C], edi
       mov      rdi, gword ptr [rdx+0x48]
       mov      rax, 0x7FC133D7E5E8
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG16
       call     [SharpLink.Client.SharpLinkClient+LogicalInvocationAsyncEnumerable`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      gword ptr [rbp-0x58], rax
       mov      qword ptr [rbp-0x50], rdx
 
G_M000_IG11:                ;; offset=0x00B2
       mov      rsi, gword ptr [rbp-0x58]
       movsx    rdi, word  ptr [rbp-0x50]
       movzx    rax, byte  ptr [rbp-0x4E]
       mov      gword ptr [rbp-0x30], rsi
       mov      word  ptr [rbp-0x28], di
       mov      byte  ptr [rbp-0x26], al
       mov      byte  ptr [rbp-0x25], 0
       mov      rbx, gword ptr [rbp-0x30]
       test     rbx, rbx
       jne      SHORT G_M000_IG17
 
G_M000_IG12:                ;; offset=0x00D7
       mov      rbx, gword ptr [rbp-0x30]
       test     rbx, rbx
       jne      G_M000_IG21
       movzx    r15, byte  ptr [rbp-0x26]
       jmp      G_M000_IG24
 
G_M000_IG13:                ;; offset=0x00EE
       lea      rdi, bword ptr [rdx+0x1C8]
 
G_M000_IG14:                ;; offset=0x00F5
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x30], xmm0
 
G_M000_IG15:                ;; offset=0x00FE
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x58], -1
       jmp      SHORT G_M000_IG12
 
G_M000_IG16:                ;; offset=0x0117
       mov      r11, 0x7FC1310522F8
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this
       mov      gword ptr [rbp-0x58], rax
       mov      qword ptr [rbp-0x50], rdx
       jmp      SHORT G_M000_IG11
 
G_M000_IG17:                ;; offset=0x012E
       mov      rsi, rbx
       mov      rdi, 0x7FC1337318B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG18
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0156
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x28]
       mov      r11, 0x7FC131052310
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG19:                ;; offset=0x0175
       test     r15d, r15d
       jne      G_M000_IG12
       xor      edi, edi
       mov      dword ptr [rbp-0x1C], edi
 
G_M000_IG20:                ;; offset=0x0183
       mov      r15, gword ptr [rbp-0x70]
       mov      dword ptr [r15+0x58], edi
       lea      rdi, bword ptr [r15+0x1C8]
       lea      rsi, bword ptr [rbp-0x30]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x38], r15
       lea      rdx, bword ptr [r15+0x70]
       lea      rsi, [rbp-0x38]
       mov      rdi, 0x7FC133D9B758
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x30]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG59
 
G_M000_IG21:                ;; offset=0x01CB
       mov      rsi, rbx
       mov      rdi, 0x7FC1337318B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG23
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG22
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG22:                ;; offset=0x0202
       movzx    r15, byte  ptr [r15+0x38]
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0209
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x28]
       mov      r11, 0x7FC131052318
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
 
G_M000_IG24:                ;; offset=0x0221
       test     r15d, r15d
       je       G_M000_IG30
 
G_M000_IG25:                ;; offset=0x022A
       mov      rdx, gword ptr [rbp-0x70]
       mov      rdi, gword ptr [rdx+0x48]
       mov      r11, 0x7FC133D7E5E8
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG29
       mov      rdi, gword ptr [rdi+0x18]
       test     rdi, rdi
       je       SHORT G_M000_IG27
       mov      r11, 0x7FC133D7F978
       cmp      qword ptr [rdi], r11
       jne      SHORT G_M000_IG28
       mov      ebx, dword ptr [rdi+0x34]
 
G_M000_IG26:                ;; offset=0x0260
       mov      rdx, gword ptr [rbp-0x70]
       mov      dword ptr [rdx+0x5C], ebx
       mov      dword ptr [rbp-0x1C], -4
       mov      dword ptr [rdx+0x58], -4
       jmp      G_M000_IG60
 
G_M000_IG27:                ;; offset=0x027A
       mov      rdi, 0x7FC132237150
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0xD8E8
       mov      rsi, 0x7FC132A14600
       call     [CORINFO_HELP_STRCNS]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG28:                ;; offset=0x02B6
       mov      r11, 0x7FC131052320
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      ebx, eax
       jmp      SHORT G_M000_IG26
 
G_M000_IG29:                ;; offset=0x02C7
       mov      r11, 0x7FC1310522F0
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      ebx, eax
       jmp      SHORT G_M000_IG26
 
G_M000_IG30:                ;; offset=0x02D8
       nop      
 
G_M000_IG31:                ;; offset=0x02D9
       cmp      dword ptr [rbp-0x1C], 1
       je       G_M000_IG38
       xor      edi, edi
       mov      r15, gword ptr [rbp-0x70]
       mov      dword ptr [r15+0x5C], edi
       mov      rdi, gword ptr [r15+0x48]
       mov      rax, 0x7FC133D7E5E8
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG34
       call     [SharpLink.Client.SharpLinkClient+LogicalInvocationAsyncEnumerable`1[int]:DisposeAsync():System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
 
G_M000_IG32:                ;; offset=0x030E
       mov      rsi, gword ptr [rbp-0x68]
       movsx    rdi, word  ptr [rbp-0x60]
       mov      gword ptr [rbp-0x48], rsi
       mov      word  ptr [rbp-0x40], di
       mov      byte  ptr [rbp-0x3E], 0
       mov      rbx, gword ptr [rbp-0x48]
       test     rbx, rbx
       jne      SHORT G_M000_IG35
 
G_M000_IG33:                ;; offset=0x032C
       mov      rbx, gword ptr [rbp-0x48]
       test     rbx, rbx
       je       G_M000_IG46
       jmp      G_M000_IG40
 
G_M000_IG34:                ;; offset=0x033E
       mov      r11, 0x7FC131052300
       call     [r11]System.IAsyncDisposable:DisposeAsync():System.Threading.Tasks.ValueTask:this
       mov      gword ptr [rbp-0x68], rax
       mov      qword ptr [rbp-0x60], rdx
       jmp      SHORT G_M000_IG32
 
G_M000_IG35:                ;; offset=0x0355
       mov      rsi, rbx
       mov      rdi, 0x7FC132136E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG36
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x037D
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x40]
       mov      r11, 0x7FC131052328
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG37:                ;; offset=0x039C
       test     r14d, r14d
       jne      SHORT G_M000_IG33
       mov      dword ptr [rbp-0x1C], 1
       mov      dword ptr [r15+0x58], 1
       lea      rdi, bword ptr [r15+0x1D8]
       lea      rsi, bword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x38], r15
       lea      rdx, bword ptr [r15+0x70]
       lea      rsi, [rbp-0x38]
       mov      rdi, 0x7FC133D9B758
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x48]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG58
 
G_M000_IG38:                ;; offset=0x03F0
       mov      r15, gword ptr [rbp-0x70]
       vmovdqu  xmm0, xmmword ptr [r15+0x1D8]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG39:                ;; offset=0x0402
       xor      esi, esi
       mov      qword ptr [r15+0x1D8], rsi
       mov      qword ptr [r15+0x1E0], rsi
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [r15+0x58], -1
       jmp      G_M000_IG33
 
G_M000_IG40:                ;; offset=0x0426
       mov      rsi, rbx
       mov      rdi, 0x7FC132136E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x043D
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG46
 
G_M000_IG42:                ;; offset=0x044E
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG46
 
G_M000_IG43:                ;; offset=0x045B
       mov      rdi, 0x7FC1339AF178
       cmp      qword ptr [rbx], rdi
       jne      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x046A
       movsx    rsi, word  ptr [rbp-0x40]
       mov      rdi, rbx
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       jmp      SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x047A
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x40]
       mov      r11, 0x7FC131052330
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       nop      
 
G_M000_IG46:                ;; offset=0x0490
       mov      rbx, gword ptr [r15+0x50]
       test     rbx, rbx
       jne      G_M000_IG52
       cmp      byte  ptr [r15+0x68], 0
       jne      G_M000_IG54
       xor      rsi, rsi
       mov      gword ptr [r15+0x50], rsi
 
G_M000_IG47:                ;; offset=0x04AE
       mov      gword ptr [r15+0x48], rsi
       jmp      G_M000_IG54
 
G_M000_IG48:                ;; offset=0x04B7
       cmp      dword ptr [rbp-0x1C], 1
       je       G_M000_IG30
       lea      r15, bword ptr [rdx+0xA0]
       mov      rdi, r15
       call     [SharpLink.Client.SharpLinkClient:EnsureLogicalCallProgress(byref)]
       mov      rdx, gword ptr [rbp-0x70]
       lea      rcx, bword ptr [rdx+0x150]
       vmovdqu  xmm0, xmmword ptr [rcx]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rcx+0x10]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       lea      rdi, [rsp+0x20]
       mov      rsi, r15
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x30], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x38], rcx
       add      rsi, 8
       add      rdi, 8
       mov      ecx, 6
       rep movsq 
       mov      rdx, gword ptr [rdx+0x18]
       mov      r15, gword ptr [rbp-0x70]
       mov      rcx, gword ptr [r15+0x28]
       mov      r8, gword ptr [r15+0x38]
       mov      rdi, gword ptr [rbx+0x08]
       mov      r9, gword ptr [r15+0x1C0]
       lea      rsi, bword ptr [r15+0x190]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Client.SharpLinkClient:InvokeServerStreamingResolved[PhysicalTcp.__IScalarStream_SharpLinkRequest_ACC1F20B0513B621,int](SharpLink.Abstractions.RpcMethodDescriptor,byref,SharpLink.Abstractions.IRpcCodec`1[PhysicalTcp.__IScalarStream_SharpLinkRequest_ACC1F20B0513B621],SharpLink.Abstractions.IRpcCodec`1[int],SharpLink.Client.SharpLinkClient+ClientInterceptorGeneration,SharpLink.Client.SharpLinkClient+ResolvedCallControl,System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerable`1[int]:this]
       mov      rsi, gword ptr [r15+0x198]
       mov      rdi, 0x7FC133D7E5E8
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG49
       mov      rdi, rax
       call     [SharpLink.Client.SharpLinkClient+LogicalInvocationAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this]
       jmp      SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x058B
       mov      rdi, rax
       mov      r11, 0x7FC131052308
       call     [r11]System.Collections.Generic.IAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this
 
G_M000_IG50:                ;; offset=0x059B
       lea      rdi, bword ptr [r15+0x48]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      rdi, rdi
       mov      gword ptr [r15+0x50], rdi
 
G_M000_IG51:                ;; offset=0x05AD
       mov      dword ptr [r15+0x64], edi
       mov      rdx, r15
       jmp      G_M000_IG07
 
G_M000_IG52:                ;; offset=0x05B9
       mov      rsi, rbx
       mov      rdi, 0x7FC1320705D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG53
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG53:                ;; offset=0x05D9
       mov      rdi, rax
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Capture(System.Exception):System.Runtime.ExceptionServices.ExceptionDispatchInfo]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Throw():this]
       int3     
 
G_M000_IG54:                ;; offset=0x05EE
       call     G_M000_IG86
       jmp      G_M000_IG63
 
G_M000_IG55:                ;; offset=0x05F8
       cmp      byte  ptr [rdx+0x68], 0
       jne      G_M000_IG63
       mov      dword ptr [rbp-0x1C], -1
       mov      dword ptr [rdx+0x58], -1
       lea      r15, bword ptr [rdx+0xA0]
       mov      rdi, r15
       call     [SharpLink.Client.SharpLinkClient:EnsureLogicalCallProgress(byref)]
       mov      rdi, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbp-0x70]
       add      rdx, 424
       mov      esi, 1
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkDynamicModule:TryAcquire(bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0640
       mov      rdi, r15
       call     [SharpLink.Client.SharpLinkClient:EnsureLogicalCallProgress(byref)]
       call     [SharpLink.Client.SharpLinkModuleRpcChannel:Draining():SharpLink.Abstractions.SharpLinkException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG57:                ;; offset=0x0658
       mov      rdx, gword ptr [rbp-0x70]
       lea      r15, bword ptr [rdx+0x1B8]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rsi, gword ptr [rsi+0x48]
       mov      rdi, gword ptr [rdx+0x140]
       call     [SharpLink.Client.SharpLinkModuleRpcChannel:Combine(System.Threading.CancellationToken,System.Threading.CancellationToken):SharpLink.Client.SharpLinkModuleRpcChannel+CombinedCancellation]
       mov      r14, rdx
       mov      rdi, r15
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r15+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x70]
       jmp      G_M000_IG05
 
G_M000_IG58:                ;; offset=0x069B
       call     G_M000_IG86
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x06A2
       call     G_M000_IG86
       jmp      SHORT G_M000_IG62
 
G_M000_IG60:                ;; offset=0x06A9
       lea      rbx, bword ptr [rdx+0x78]
       mov      byte  ptr [rbx+0x22], 1
       cmp      byte  ptr [rbx+0x23], 0
       jne      G_M000_IG69
       mov      byte  ptr [rbx+0x23], 1
       mov      r15, gword ptr [rbx]
       test     r15, r15
       jne      SHORT G_M000_IG61
       mov      rsi, 0x7FB94D801DB8
       mov      rsi, gword ptr [rsi]
       mov      rdi, rbx
       xor      rdx, rdx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      r15, rax
 
G_M000_IG61:                ;; offset=0x06E1
       test     r15, r15
       jne      G_M000_IG70
 
G_M000_IG62:                ;; offset=0x06EA
       add      rsp, 200
       pop      rbx
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG63:                ;; offset=0x06F8
       mov      r15, gword ptr [rbp-0x70]
       mov      dword ptr [r15+0x58], -2
       xor      edi, edi
       mov      qword ptr [r15+0x1A8], rdi
       mov      qword ptr [r15+0x1B0], rdi
 
G_M000_IG64:                ;; offset=0x0714
       mov      qword ptr [r15+0x1B8], rdi
       mov      qword ptr [r15+0x1C0], rdi
 
G_M000_IG65:                ;; offset=0x0722
       mov      gword ptr [r15+0x48], rdi
 
G_M000_IG66:                ;; offset=0x0726
       mov      gword ptr [r15+0x50], rdi
       cmp      gword ptr [r15+0x08], 0
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x0731
       mov      rbx, gword ptr [r15+0x08]
       mov      rdi, rbx
       mov      esi, 1
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Threading.CancellationTokenSource:Dispose(bool):this
       mov      rdi, rbx
       call     [System.GC:SuppressFinalize(System.Object)]
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG68:                ;; offset=0x0756
       xor      edi, edi
       mov      dword ptr [r15+0x5C], edi
       lea      rdi, bword ptr [r15+0x70]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x78]
       mov      byte  ptr [rdi+0x22], 0
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SignalCompletion():this]
       jmp      G_M000_IG62
 
G_M000_IG69:                ;; offset=0x0779
       call     [System.ThrowHelper:ThrowInvalidOperationException()]
       int3     
 
G_M000_IG70:                ;; offset=0x0780
       mov      r14, gword ptr [rbx+0x10]
       test     r14, r14
       jne      SHORT G_M000_IG72
       cmp      byte  ptr [rbx+0x24], 0
       je       SHORT G_M000_IG71
       mov      rdx, gword ptr [rbx+0x08]
       mov      rsi, r15
       mov      rdi, 0x7FC133B20C38
       mov      ecx, 1
       call     [System.Threading.ThreadPool:UnsafeQueueUserWorkItem[System.__Canon](System.Action`1[System.__Canon],System.__Canon,bool):bool]
       jmp      G_M000_IG62
 
G_M000_IG71:                ;; offset=0x07B0
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [r15+0x08]
       call     [r15+0x18]System.Action`1[System.__Canon]:Invoke(System.__Canon):this
       jmp      G_M000_IG62
 
G_M000_IG72:                ;; offset=0x07C1
       mov      rsi, r14
       mov      rdi, 0x7FC13213A7C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG73
       mov      rsi, r14
       mov      rdi, 0x7FC133B20CE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07EF
       movzx    rcx, byte  ptr [rbx+0x24]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:InvokeContinuationWithContext(System.Object,System.Action`1[System.Object],System.Object,bool)]
       jmp      G_M000_IG62
 
G_M000_IG74:                ;; offset=0x0808
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:ScheduleCapturedContext(System.Object,System.Action`1[System.Object],System.Object)]
       jmp      G_M000_IG62
 
G_M000_IG75:                ;; offset=0x081D
       sub      rsp, 120
 
G_M000_IG76:                ;; offset=0x0821
       mov      r15, gword ptr [rbp-0x70]
       lea      rsi, bword ptr [r15+0x1A8]
       lea      rdx, bword ptr [r15+0x1B8]
       xor      rcx, rcx
       call     [SharpLink.Client.SharpLinkModuleRpcChannel:TransferAbandonedOwnership(System.Exception,byref,byref,SharpLink.Client.SharpLinkClientStreamModuleLeaseOwner):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x0840
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG78:                ;; offset=0x0849
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG79:                ;; offset=0x084F
       sub      rsp, 120
 
G_M000_IG80:                ;; offset=0x0853
       mov      rsi, rdi
       mov      r15, gword ptr [rbp-0x70]
       lea      rdi, bword ptr [r15+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rax, G_M000_IG30
 
G_M000_IG81:                ;; offset=0x086A
       add      rsp, 120
       ret      
 
G_M000_IG82:                ;; offset=0x086F
       sub      rsp, 120
 
G_M000_IG83:                ;; offset=0x0873
       mov      r15, gword ptr [rbp-0x70]
       lea      rsi, bword ptr [r15+0x1A8]
       lea      rdx, bword ptr [r15+0x1B8]
       xor      rcx, rcx
       call     [SharpLink.Client.SharpLinkModuleRpcChannel:TransferAbandonedOwnership(System.Exception,byref,byref,SharpLink.Client.SharpLinkClientStreamModuleLeaseOwner):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x0892
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG85:                ;; offset=0x089B
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG86:                ;; offset=0x08A1
       sub      rsp, 120
 
G_M000_IG87:                ;; offset=0x08A5
       cmp      dword ptr [rbp-0x1C], -1
       jne      SHORT G_M000_IG90
 
G_M000_IG88:                ;; offset=0x08AB
       mov      r15, gword ptr [rbp-0x70]
       lea      rdi, bword ptr [r15+0x1A8]
       call     [SharpLink.Runtime.SharpLinkDynamicModuleLease:Dispose():this]
       mov      rbx, gword ptr [r15+0x1B8]
       test     rbx, rbx
       je       SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x08C8
       mov      rdi, rbx
       mov      esi, 1
       mov      rax, qword ptr [rbx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Threading.CancellationTokenSource:Dispose(bool):this
       mov      rdi, rbx
       call     [System.GC:SuppressFinalize(System.Object)]
       nop      
 
G_M000_IG90:                ;; offset=0x08E4
       add      rsp, 120
       ret      
 
G_M000_IG91:                ;; offset=0x08E9
       sub      rsp, 120
 
G_M000_IG92:                ;; offset=0x08ED
       mov      rbx, rdi
       mov      r15, gword ptr [rbp-0x70]
       mov      dword ptr [r15+0x58], -2
       xor      edi, edi
       mov      qword ptr [r15+0x1A8], rdi
       mov      qword ptr [r15+0x1B0], rdi
 
G_M000_IG93:                ;; offset=0x090C
       mov      qword ptr [r15+0x1B8], rdi
       mov      qword ptr [r15+0x1C0], rdi
 
G_M000_IG94:                ;; offset=0x091A
       mov      gword ptr [r15+0x48], rdi
 
G_M000_IG95:                ;; offset=0x091E
       mov      gword ptr [r15+0x50], rdi
       mov      rdi, gword ptr [r15+0x08]
       test     rdi, rdi
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x092B
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG97:                ;; offset=0x0939
       xor      edi, edi
       mov      dword ptr [r15+0x5C], edi
       lea      rdi, bword ptr [r15+0x70]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x78]
       mov      rsi, rbx
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SetException(System.Exception):this]
       lea      rax, G_M000_IG62
 
G_M000_IG98:                ;; offset=0x095D
       add      rsp, 120
       ret      
 
; Total bytes 2402
