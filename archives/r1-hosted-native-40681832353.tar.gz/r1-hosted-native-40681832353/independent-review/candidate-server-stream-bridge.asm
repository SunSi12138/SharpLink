; SharpLink.Server.ServerGeneratedBridge+<PumpOutboundStreamAsync>d__7`1[int]:MoveNext():this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2474
; 11 inlinees with PGO data; 42 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 328
       lea      rbp, [rsp+0x170]
       xor      eax, eax
       mov      qword ptr [rbp-0x148], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x140], xmm8
       vmovdqa  xmmword ptr [rbp-0x130], xmm8
       mov      rax, -240
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT  -5 instr
       mov      bword ptr [rbp-0x158], rdi
       mov      rdx, rdi
 
G_M000_IG02:                ;; offset=0x0063
       mov      edi, dword ptr [rdx+0x40]
       mov      dword ptr [rbp-0x2C], edi
       mov      r8, gword ptr [rdx]
       mov      gword ptr [rbp-0x160], r8
 
G_M000_IG03:                ;; offset=0x0073
       cmp      dword ptr [rbp-0x2C], 2
       jbe      G_M000_IG25
       xor      edi, edi
       mov      dword ptr [rdx+0x44], edi
 
G_M000_IG04:                ;; offset=0x0082
       cmp      dword ptr [rbp-0x2C], 0
       je       G_M000_IG18
       mov      rdi, 0x7F7D8CBBD4A0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      r8, gword ptr [rbp-0x160]
       mov      r15, gword ptr [r8+0x20]
       mov      rdx, bword ptr [rbp-0x158]
       mov      r14, qword ptr [rdx+0x28]
       mov      r13, r14
       movzx    r12, word  ptr [rdx+0x4C]
       mov      rax, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x168], rax
       lea      rdi, bword ptr [rbx+0x08]
       mov      rsi, r8
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [rbx+0x18], r14
       lea      rdi, bword ptr [rbx+0x10]
       mov      rsi, gword ptr [rbp-0x168]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x158]
       mov      rdi, gword ptr [rdx+0x10]
       movzx    rax, byte  ptr [rdx+0x4E]
       mov      rcx, gword ptr [rdx+0x58]
       mov      rsi, gword ptr [r15+0x08]
       cmp      byte  ptr [rsi], sil
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE0], r8
       mov      gword ptr [rbp-0x138], rsi
       mov      qword ptr [rbp-0xF8], r13
       mov      word  ptr [rbp-0xE8], r12w
       mov      gword ptr [rbp-0x148], rbx
       mov      gword ptr [rbp-0x140], rdi
       mov      byte  ptr [rbp-0xE6], al
       mov      gword ptr [rbp-0xD8], rcx
       mov      dword ptr [rbp-0xF0], -1
       lea      rdi, [rbp-0x148]
       call     [System.Runtime.CompilerServices.AsyncMethodBuilderCore:Start[SharpLink.Runtime.RpcSession+<PumpGeneratedOutboundStreamAsync>d__140`1[int]](byref)]
       mov      rdi, gword ptr [rbp-0xE0]
       mov      rax, 0x7F75A5801810
       cmp      rdi, gword ptr [rax]
       jne      SHORT G_M000_IG11
 
G_M000_IG05:                ;; offset=0x0169
       xor      rbx, rbx
 
G_M000_IG06:                ;; offset=0x016B
       mov      gword ptr [rbp-0x40], rbx
       mov      word  ptr [rbp-0x38], 0
       mov      byte  ptr [rbp-0x36], 0
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       jne      G_M000_IG14
 
G_M000_IG07:                ;; offset=0x0186
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       je       G_M000_IG23
 
G_M000_IG08:                ;; offset=0x0193
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG20
 
G_M000_IG09:                ;; offset=0x01AE
       mov      rdi, 0x7F7D8C7CF178
       cmp      qword ptr [rbx], rdi
       je       G_M000_IG22
 
G_M000_IG10:                ;; offset=0x01C1
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x38]
       mov      r11, 0x7F7D89E73240
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG23
 
G_M000_IG11:                ;; offset=0x01DB
       mov      rbx, gword ptr [rbp-0xE0]
       test     rbx, rbx
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01E7
       jmp      SHORT G_M000_IG06
 
G_M000_IG13:                ;; offset=0x01E9
       mov      rdi, 0x7F7D8BED4E40
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       call     [System.Threading.Tasks.Task:.ctor():this]
       mov      gword ptr [rbp-0xE0], rbx
       jmp      SHORT G_M000_IG12
 
G_M000_IG14:                ;; offset=0x020D
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG15
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0235
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x38]
       mov      r11, 0x7F7D89E73238
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG16:                ;; offset=0x0254
       test     r15d, r15d
       jne      G_M000_IG07
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG17:                ;; offset=0x0262
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x40], edi
       lea      rdi, bword ptr [rdx+0x60]
       lea      rsi, bword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       lea      rsi, bword ptr [rdx+0x50]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Server.ServerGeneratedBridge+<PumpOutboundStreamAsync>d__7`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG54
 
G_M000_IG18:                ;; offset=0x029A
       vmovdqu  xmm0, xmmword ptr [rdx+0x60]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG19:                ;; offset=0x02A4
       xor      esi, esi
       mov      qword ptr [rdx+0x60], rsi
       mov      qword ptr [rdx+0x68], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x40], -1
       jmp      G_M000_IG07
 
G_M000_IG20:                ;; offset=0x02C1
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x02D2
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x02DF
       movsx    rsi, word  ptr [rbp-0x38]
       mov      rdi, rbx
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       nop      
 
G_M000_IG23:                ;; offset=0x02EE
       mov      rdx, bword ptr [rbp-0x158]
       cmp      dword ptr [rdx+0x44], 1
       je       SHORT G_M000_IG26
 
G_M000_IG24:                ;; offset=0x02FB
       xor      rdi, rdi
       mov      gword ptr [rdx+0x18], rdi
       jmp      G_M000_IG52
 
G_M000_IG25:                ;; offset=0x0306
       mov      edi, dword ptr [rbp-0x2C]
       lea      rax, [reloc @RWD00]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG26:                ;; offset=0x031F
       xor      rsi, rsi
       mov      gword ptr [rdx+0x20], rsi
 
G_M000_IG27:                ;; offset=0x0325
       mov      dword ptr [rdx+0x48], esi
 
G_M000_IG28:                ;; offset=0x0328
       cmp      dword ptr [rbp-0x2C], 1
       je       G_M000_IG32
       mov      rsi, qword ptr [rdx+0x28]
       lea      rdx, [rbp-0x58]
       mov      rdi, gword ptr [rbp-0x160]
       call     [SharpLink.Server.ServerGeneratedBridge:GetSelectedTerminal(long,byref):SharpLink.Abstractions.SharpLinkException:this]
       mov      rbx, rax
       test     rbx, rbx
       je       G_M000_IG36
       mov      rdx, bword ptr [rbp-0x158]
       movzx    rdx, word  ptr [rdx+0x4C]
       mov      rdi, bword ptr [rbp-0x158]
       mov      rsi, qword ptr [rdi+0x28]
       mov      r8, gword ptr [rbp-0x160]
       mov      rdi, gword ptr [r8+0x10]
       mov      rcx, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.RpcSession:CompleteSendStream(long,ushort,System.Exception):this]
       cmp      byte  ptr [rbp-0x58], 0
       je       G_M000_IG37
       mov      r8, gword ptr [rbp-0x160]
       mov      rcx, gword ptr [r8+0x10]
       mov      rcx, gword ptr [rcx+0x110]
       mov      rdi, bword ptr [rbp-0x158]
       mov      rsi, qword ptr [rdi+0x28]
       mov      rdi, gword ptr [r8+0x10]
       mov      rdx, rbx
       call     [SharpLink.Runtime.RpcSessionExtensions:SendRpcErrorWithBackpressureAsync(SharpLink.Runtime.RpcSession,long,SharpLink.Abstractions.SharpLinkException,System.Threading.CancellationToken):System.Threading.Tasks.ValueTask]
       mov      gword ptr [rbp-0x50], rax
       mov      qword ptr [rbp-0x48], rdx
       mov      rsi, gword ptr [rbp-0x50]
       movsx    rdi, word  ptr [rbp-0x48]
       mov      gword ptr [rbp-0x40], rsi
       mov      word  ptr [rbp-0x38], di
       mov      byte  ptr [rbp-0x36], 0
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       je       G_M000_IG34
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG30
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
 
G_M000_IG29:                ;; offset=0x03FF
       movzx    r15, r15b
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0405
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x38]
       mov      r11, 0x7F7D89E73248
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG31:                ;; offset=0x0424
       test     r15d, r15d
       jne      SHORT G_M000_IG34
       mov      rdi, bword ptr [rbp-0x158]
       mov      dword ptr [rdi+0x40], 1
       add      rdi, 96
       lea      rsi, bword ptr [rbp-0x40]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      rdi, bword ptr [rbp-0x158]
       lea      rsi, bword ptr [rdi+0x50]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Server.ServerGeneratedBridge+<PumpOutboundStreamAsync>d__7`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x40]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG54
 
G_M000_IG32:                ;; offset=0x0469
       vmovdqu  xmm0, xmmword ptr [rdx+0x60]
       vmovdqu  xmmword ptr [rbp-0x40], xmm0
 
G_M000_IG33:                ;; offset=0x0473
       xor      esi, esi
       mov      qword ptr [rdx+0x60], rsi
       mov      qword ptr [rdx+0x68], rsi
       mov      dword ptr [rdx+0x40], -1
 
G_M000_IG34:                ;; offset=0x0484
       mov      rbx, gword ptr [rbp-0x40]
       test     rbx, rbx
       je       G_M000_IG37
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG35
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       G_M000_IG37
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG37
 
G_M000_IG35:                ;; offset=0x04CD
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x38]
       mov      r11, 0x7F7D89E73250
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG37
 
G_M000_IG36:                ;; offset=0x04E7
       mov      r8, gword ptr [rbp-0x160]
       mov      rbx, gword ptr [r8+0x08]
       mov      r15, gword ptr [r8+0x18]
       mov      r14, gword ptr [r8+0x10]
       mov      rdi, bword ptr [rbp-0x158]
       mov      r13, qword ptr [rdi+0x28]
       mov      r12, qword ptr [rdi+0x30]
       mov      rax, qword ptr [rdi+0x38]
       mov      qword ptr [rbp-0x150], rax
       mov      rdi, gword ptr [rdi+0x18]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetLogicalException(System.Exception):System.Exception]
       mov      gword ptr [rsp], rax
       mov      rsi, r15
       mov      rdx, r14
       mov      rcx, r13
       mov      r8, r12
       mov      r9, qword ptr [rbp-0x150]
       mov      rdi, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Server.SharpLinkServer:MapStreamServiceException(SharpLink.Runtime.StripedLongMap`1[SharpLink.Server.ServerCallCancellationState],SharpLink.Runtime.RpcSession,long,long,long,System.Exception):SharpLink.Abstractions.SharpLinkException:this]
       mov      rcx, rax
       mov      rdi, bword ptr [rbp-0x158]
       movzx    rdx, word  ptr [rdi+0x4C]
       mov      rsi, qword ptr [rdi+0x28]
       mov      r8, gword ptr [rbp-0x160]
       mov      rdi, gword ptr [r8+0x10]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.RpcSession:SendStreamErrorAsync(long,ushort,SharpLink.Abstractions.SharpLinkException):this]
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0567
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x48], 1
 
G_M000_IG38:                ;; offset=0x0575
       mov      rdx, bword ptr [rbp-0x158]
       mov      rdi, gword ptr [rdx+0x18]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       je       G_M000_IG46
 
G_M000_IG39:                ;; offset=0x058F
       mov      gword ptr [rbp-0x68], rax
       xor      edi, edi
       mov      dword ptr [rbp-0x60], edi
       test     byte  ptr [rbp-0x60], 4
       jne      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x059E
       mov      rdi, gword ptr [rbp-0x68]
       test     dword ptr [rdi+0x34], 0x1600000
       jne      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x05AB
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x40], 2
       lea      rdi, bword ptr [rdx+0x70]
       mov      rsi, gword ptr [rbp-0x68]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [rbp-0x60]
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x78], esi
       lea      rsi, bword ptr [rdx+0x50]
       mov      rdi, rdx
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[SharpLink.Server.ServerGeneratedBridge+<PumpOutboundStreamAsync>d__7`1[int]](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x68]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredTaskAwaitable+ConfiguredTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG54
 
G_M000_IG42:                ;; offset=0x05F2
       vmovdqu  xmm0, xmmword ptr [rdx+0x70]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG43:                ;; offset=0x05FC
       xor      edi, edi
       mov      qword ptr [rdx+0x70], rdi
       mov      qword ptr [rdx+0x78], rdi
       mov      dword ptr [rdx+0x40], -1
 
G_M000_IG44:                ;; offset=0x060D
       mov      rdi, gword ptr [rbp-0x68]
       mov      esi, dword ptr [rbp-0x60]
       mov      eax, dword ptr [rdi+0x34]
       and      eax, 0x11000000
       cmp      eax, 0x1000000
       je       SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x0623
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG46:                ;; offset=0x0629
       mov      rdi, bword ptr [rbp-0x158]
       mov      rbx, gword ptr [rdi+0x20]
       test     rbx, rbx
       je       SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0639
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AE905D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0650
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG49:                ;; offset=0x0659
       mov      rdi, rax
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Capture(System.Exception):System.Runtime.ExceptionServices.ExceptionDispatchInfo]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Throw():this]
       int3     
 
G_M000_IG50:                ;; offset=0x066E
       mov      rdi, bword ptr [rbp-0x158]
       cmp      dword ptr [rdi+0x48], 1
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x067B
       xor      rsi, rsi
       mov      gword ptr [rdi+0x20], rsi
       mov      rdx, rdi
       jmp      G_M000_IG24
 
G_M000_IG52:                ;; offset=0x0689
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x40], -2
       lea      rdi, bword ptr [rdx+0x50]
       cmp      gword ptr [rdi], 0
       jne      SHORT G_M000_IG56
 
G_M000_IG53:                ;; offset=0x06A1
       mov      rsi, 0x7F75A5801810
       mov      rsi, gword ptr [rsi]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG54:                ;; offset=0x06B3
       nop      
 
G_M000_IG55:                ;; offset=0x06B4
       add      rsp, 328
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG56:                ;; offset=0x06C6
       mov      rdi, gword ptr [rdi]
       xor      esi, esi
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:SetExistingTaskResult(System.Threading.Tasks.Task`1[System.Threading.Tasks.VoidTaskResult],System.Threading.Tasks.VoidTaskResult)]
       jmp      SHORT G_M000_IG54
 
G_M000_IG57:                ;; offset=0x06D3
       push     rax
 
G_M000_IG58:                ;; offset=0x06D4
       mov      rsi, rdi
       mov      rdi, 0x7F7D8AE905D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x06EE
       xor      eax, eax
       jmp      SHORT G_M000_IG68
 
G_M000_IG60:                ;; offset=0x06F2
       mov      rdx, bword ptr [rbp-0x158]
       lea      rdi, bword ptr [rdx+0x18]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x158]
       mov      rbx, gword ptr [rdx+0x18]
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AE908C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG66
 
G_M000_IG61:                ;; offset=0x0727
       test     rbx, rbx
       jne      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x072C
       xor      eax, eax
       jmp      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0730
       mov      rax, 0x7F7D8AE909F0
       cmp      qword ptr [rbx], rax
       jne      SHORT G_M000_IG62
 
G_M000_IG64:                ;; offset=0x073F
       mov      eax, 1
 
G_M000_IG65:                ;; offset=0x0744
       test     eax, eax
       sete     al
       movzx    rax, al
       jmp      SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x074E
       xor      eax, eax
 
G_M000_IG67:                ;; offset=0x0750
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG68:                ;; offset=0x0758
       add      rsp, 8
       ret      
 
G_M000_IG69:                ;; offset=0x075D
       push     rax
 
G_M000_IG70:                ;; offset=0x075E
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x44], 1
       lea      rax, G_M000_IG23
 
G_M000_IG71:                ;; offset=0x0773
       add      rsp, 8
       ret      
 
G_M000_IG72:                ;; offset=0x0778
       push     rax
 
G_M000_IG73:                ;; offset=0x0779
       mov      rsi, rdi
       mov      rdx, bword ptr [rbp-0x158]
       lea      rdi, bword ptr [rdx+0x20]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rax, G_M000_IG38
 
G_M000_IG74:                ;; offset=0x0793
       add      rsp, 8
       ret      
 
G_M000_IG75:                ;; offset=0x0798
       push     rax
 
G_M000_IG76:                ;; offset=0x0799
       mov      rsi, rdi
       mov      rdx, bword ptr [rbp-0x158]
       mov      dword ptr [rdx+0x40], -2
       lea      rdi, bword ptr [rdx+0x50]
       call     [System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder:SetException(System.Exception):this]
       lea      rax, G_M000_IG54
 
G_M000_IG77:                ;; offset=0x07BB
       add      rsp, 8
       ret      
 
RWD00  	dd	0000001Fh ; case G_M000_IG04
       	dd	000002C5h ; case G_M000_IG28
       	dd	0000058Fh ; case G_M000_IG42

; Total bytes 1984
