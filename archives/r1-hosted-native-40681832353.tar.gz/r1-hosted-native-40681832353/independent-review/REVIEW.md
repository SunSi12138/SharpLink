# Independent R1 hosted native review — run40681832353

## Verdict

**Valid, complete non-timed mechanism evidence; narrow target branch change verified. Not performance Go; #931 remains NoGo/Draft.** The second `hasNext` conditional test and false-path default-item assignment are eliminated in this actual TCP Tier1 body. The out-of-line jump to yield remains, total body grows, and frame does not shrink. Thus “target duplicate conditional removed” is supported; “entire success-path branch/jump removed,” “smaller optimized body,” or “regression solved” are not.

Live run: https://github.com/SunSi12138/SharpLink/actions/runs/40681832353 — completed/success, attempt1, tool `9c0cf9e682deb38c4c321e93db0f11d1338bc7bd`. Independent read2026-10-28 11:47–11:51 UTC. PR956 is validation-only/Draft, not a product merge candidate.

## Raw integrity/source/runtime checks

Official artifact12813460614,89,150,325 bytes, SHA256 `c619069c6f79ca4332425e3a3e89acd86fbab8ea72d025d884077646869a76ed`, matched against live GitHub artifact metadata. Independently hashed ZIP and compared every extracted file byte-for-byte with its ZIP entry. Checked all9 DLLs per arm against disk hashes, process-reported hashes and loaded assembly source/version/path. Exact only differing DLL: SharpLink.Client.

Baseline Client=`ac17c8d8ea0203edbe7b8cf19ddb95eaa24d4d2c`; R1 Client=`94adeae886c4ddfd0c02ec2dcb700cd97e9cad80`; all other product DLLs common ac17c8d8, matching archived run40646151477 candidate snapshot exactly. Probe and generated module unchanged from that archive. Source diff ac17→94adeae8 is exactly8 lines in SharpLinkClient.Interceptors.cs,4 additions/4 deletions: move false exit inside the existing inner try, remove ternary/default item assignment and outer duplicate test. No stacked product optimization. Tool verifies clean exact source before and after build. Build log0 warnings/errors.

SDK10.0.102; both process proofs load Microsoft.NETCore.App and Microsoft.AspNetCore.App10.0.13 under private r1-runtime. Independently SHA512-verified the archived official runtime tarballs against exact workflow pins:

- dotnet: `9574d95364110409416735e7842796f8d614c21d74cb25d204a3e4cfd11b2c05efdf19ca89b8069650a04f64add2705967dcb04b8665a36d7a3f30a5d8c05afe`
- aspnetcore: `7b20d4164f097e1cf616d8174b6a64be100e6f30dc4e028b16e551e8b0c86dff0ef424bb4bf52d1ff0ecca38e102d3fa80814e06cb85a32d6eee4c3b99764f79`

Exactly2 non-timed processes, baseline then candidate, each4352 RPCs including first traced call; both exit0. Fixed probe/source implements250ms pauses after1024/2048/3072/4096, then return from preflight before timing loop. Host command warmup/measurement arguments0/0; default tiering/PGO, no threshold forcing, same CPUs0,1 reported as same-core SMT siblings. Each has1 worker/1 connection and actual generated dynamic TCP request `PhysicalTcp.__IScalarStream_SharpLinkRequest_ACC1F20B0513B621`. Timing records do not exist. This does not prove the JIT tier of future timed processes.

Independently matched gate rows to their exact raw listing line/method/tier/size; both arms contain all4 true positive-size Tier1 targets. Lower/instrumented tiers remain retained, not accepted as optimized Tier1.

| Target | ac17 bytes | R1 bytes | Main `sub rsp` ac17/R1 |
|---|---:|---:|---:|
|intercepted iterator|4806|5077|288/288|
|dynamic iterator|2402|2693|200/200|
|server bridge|1984|1984|328/328|
|runtime pump|8146|8193|616/616|

Interception body **+271B (+5.64%)**, not smaller. Identical-source dynamic iterator/runtime pump also vary in generated size: profile-specific generated code differences are not additional product edits or demonstrated performance causes.

## Exact branch mechanism

Raw `native/preflight/baseline-jit.txt`, target starts line12663; candidate starts line12691. Actual target is `SharpLinkClient+InterceptedAsyncEnumerable<int>+<GetAsyncEnumerator>.MoveNext`, Tier1.

- ac17 IG13/0x018E tests `r15d`; successful path Current IG14→IG15 jump→IG65/0x0852 tests same `r15d` again→yield IG66. False first test reaches IG63/0x0837 `xor ebx,ebx` then duplicate test.
- R1 IG13/0x018E first test remains. False branch targets normal completion IG85. Current IG14→IG15 still jumps out-of-line, now directly to yield IG64/0x084E; no second `hasNext` test/default item assignment intervenes.

The complete hosted gate supports this narrow structural claim. Earlier cloudattempt003 is still **failed/incomplete**: both arms missing optimized Runtime pump/Server bridge (2/4 targets only), retained at artifacts/attempts/r1-native-003/preflight/gate.json. It is not converted to pass by this distinct hosted environment, nor evidence that hosted timing would pass.

## Justified bounded next timing experiment

No new run is authorized/executed by this review. Mechanism gate now supports one new-candidate test rather than repeating unchanged old/new Client samples. The minimum directly decision-relevant design is to reuse the original frozen #931 full-product48-process protocol with **original full baselinecc7c458b vs full R1 candidate94adeae8** (all product components built/prepared at their actual source, not old Client mixed with new Runtime): static/dynamic intercepted TCP × items1/100 ×1 worker/1 ready connection ×6 alternating AB/BA pairs ×2 arms; private10.0.13,3s warmup/6s measurement, fixed matching CPU topology, no disassembly/build activity while timed. Freeze exact reviewed tool/source/arm plan and failure/analysis method before execution.

Retain all48 raw samples, host records, errors, ordered ticks, source/binary identity and required preparation gates; exactly one planned schedule, no replacements/extensions or sample exclusion. Reuse existing applicable correctness evidence and require exact-head independent review; changed harness needs separate review. Analyze every scene and primary metric (throughput, CPU/op, P99/P99.9, allocation), not just dynamic100 or an overall mean. Keep previous full-product/FullOpts/PGO and cloudfailed artifacts separate.

This comparison answers whether the actual R1 product recovers the original bad baseline, not a clean estimate of R1's incremental timing effect. If the root separately needs causal timing of R1 vs ac17, it must predeclare that comparator before running (e.g. fixed balanced3-arm design); do not add favorable post-hoc samples. Comparing only R1/ac17 cannot clear original cc7c458b regression. No 3% margin or other new equivalence allowance is introduced here. CI success/no significance/crossing1 cannot establish equivalence; absent satisfaction of original approved no-regression acceptance, result stays Hold/NoGo. A regression or inconclusive result does not authorize retries; use tree's next evidence-triggered action.

The user’s2.0.3 stretch target (+10%QPS/−20%P99) is a separate matched-baseline requirement and cannot be inferred from this mechanism or #931 protocol. No functional scope reduction is justified.

Reproduction: `verify.py` checks artifact extraction, source/loaded-DLL identities, runtime profile, fixed count and all native rows; `independent-verification.json` and8 extracted target `.asm` files are its derived outputs. No product/tool implementation or GitHub mutation was performed by this reviewer.
