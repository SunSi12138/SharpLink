; SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1+<GetAsyncEnumerator>d__8[int]:MoveNext():this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 209440
; 27 inlinees with PGO data; 81 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rbx
       sub      rsp, 288
       lea      rbp, [rsp+0x140]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa  xmmword ptr [rbp-0x110], xmm8
       vmovdqa  xmmword ptr [rbp-0x100], xmm8
       mov      rax, -192
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x30], rax
       mov      gword ptr [rbp-0xF0], rdi
       mov      rdx, rdi
 
G_M000_IG02:                ;; offset=0x005C
       mov      esi, dword ptr [rdx+0x30]
       mov      dword ptr [rbp-0x24], esi
       mov      r8, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0xF8], r8
 
G_M000_IG03:                ;; offset=0x006D
       mov      esi, dword ptr [rbp-0x24]
       add      esi, 4
       cmp      esi, 8
       ja       G_M000_IG65
 
G_M000_IG04:                ;; offset=0x007C
       mov      esi, esi
       lea      rdi, [reloc @RWD00]
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rax, G_M000_IG02
       add      rdi, rax
       jmp      rdi
 
G_M000_IG05:                ;; offset=0x0094
       cmp      dword ptr [rbp-0x24], -4
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x009A
       mov      dword ptr [rbp-0x24], -1
       mov      dword ptr [rdx+0x30], -1
       cmp      byte  ptr [rdx+0x3C], 0
       jne      G_M000_IG85
 
G_M000_IG07:                ;; offset=0x00B2
       mov      rdx, gword ptr [rbp-0xF0]
       mov      eax, dword ptr [rbp-0x24]
       dec      eax
       cmp      eax, 2
       jbe      G_M000_IG16
 
G_M000_IG08:                ;; offset=0x00C7
       mov      rdi, gword ptr [rbp-0xF8]
       cmp      gword ptr [rdi+0x10], 0
       jne      G_M000_IG20
       lea      rbx, bword ptr [rdi+0x38]
       mov      r15, gword ptr [rdi+0x08]
       test     r15, r15
       je       G_M000_IG21
       cmp      byte  ptr [rbx+0x19], 0
       jne      G_M000_IG22
 
G_M000_IG09:                ;; offset=0x00F4
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rax, gword ptr [rdx+0x18]
       mov      rcx, 0x7F7D8CB797F8
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG26
       mov      rdi, rax
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      gword ptr [rbp-0xD8], rax
       mov      qword ptr [rbp-0xD0], rdx
 
G_M000_IG10:                ;; offset=0x0129
       vmovdqu  xmm0, xmmword ptr [rbp-0xD8]
       vmovdqu  xmmword ptr [rbp-0x60], xmm0
 
G_M000_IG11:                ;; offset=0x0136
       mov      rdi, gword ptr [rbp-0xF8]
       cmp      byte  ptr [rdi+0x51], 0
       jne      G_M000_IG33
       xor      esi, esi
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x34], esi
       mov      rsi, gword ptr [rbp-0x60]
       movzx    rax, byte  ptr [rbp-0x56]
       movsx    rcx, word  ptr [rbp-0x58]
       mov      gword ptr [rbp-0x70], rsi
       mov      word  ptr [rbp-0x68], cx
       mov      byte  ptr [rbp-0x66], al
       mov      byte  ptr [rbp-0x65], 0
       mov      rbx, gword ptr [rbp-0x70]
       test     rbx, rbx
       jne      G_M000_IG27
 
G_M000_IG12:                ;; offset=0x017C
       mov      rbx, gword ptr [rbp-0x70]
       test     rbx, rbx
       jne      G_M000_IG30
       movzx    r15, byte  ptr [rbp-0x66]
 
G_M000_IG13:                ;; offset=0x018E
       test     r15d, r15d
       je       G_M000_IG85
 
G_M000_IG14:                ;; offset=0x0197
       mov      rdx, gword ptr [rbp-0xF0]
       mov      r11, gword ptr [rdx+0x18]
       mov      rax, 0x7F7D8CB797F8
       cmp      qword ptr [r11], rax
       jne      G_M000_IG63
       mov      ebx, dword ptr [r11+0xE4]
 
G_M000_IG15:                ;; offset=0x01BC
       mov      rdi, gword ptr [rbp-0xF8]
       movsx    rsi, byte  ptr [rdi+0x1C]
       jmp      G_M000_IG64
 
G_M000_IG16:                ;; offset=0x01CD
       mov      edi, eax
       lea      rsi, [reloc @RWD36]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG17:                ;; offset=0x01E5
       lea      rdi, bword ptr [rdx+0x90]
 
G_M000_IG18:                ;; offset=0x01EC
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG19:                ;; offset=0x01F5
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x24], -1
       mov      dword ptr [rdx+0x30], -1
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x0211
       lea      rsi, bword ptr [rdi+0x38]
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rsi+0x10]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rax, qword ptr [rsi+0x20]
       mov      qword ptr [rsp+0x20], rax
       mov      rdi, gword ptr [rdi+0x10]
       mov      rax, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Client.SharpLinkClient+ClientLogicalCallState:TryEnterProgress(SharpLink.Abstractions.RpcDeadline,System.TimeProvider):bool:this]
       test     eax, eax
       jne      G_M000_IG09
       jmp      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x0253
       mov      edi, 0x2077
       mov      rsi, 0x7F7D8AF5D180
       call     [CORINFO_HELP_STRCNS]
       mov      rdi, rax
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG22:                ;; offset=0x0272
       cmp      byte  ptr [rbx+0x18], 0
       jne      SHORT G_M000_IG23
       mov      rdi, rbx
       call     [SharpLink.Abstractions.RpcDeadline:get_Timestamp():long:this]
       mov      rbx, rax
       mov      rdi, r15
       mov      rax, qword ptr [r15]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x38]System.TimeProvider:GetTimestamp():long:this
       cmp      rbx, rax
       setle    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x029C
       mov      rdi, r15
       mov      rax, qword ptr [r15]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x38]System.TimeProvider:GetTimestamp():long:this
       sub      rax, qword ptr [rbx]
       cmp      rax, qword ptr [rbx+0x20]
       setae    bl
       movzx    rbx, bl
 
G_M000_IG24:                ;; offset=0x02B6
       test     ebx, ebx
       je       G_M000_IG09
 
G_M000_IG25:                ;; offset=0x02BE
       call     [SharpLink.Client.SharpLinkClient:CreateDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG26:                ;; offset=0x02CD
       mov      rdi, rax
       mov      r11, 0x7F7D89E72348
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this
       mov      gword ptr [rbp-0xD8], rax
       mov      qword ptr [rbp-0xD0], rdx
       jmp      G_M000_IG10
 
G_M000_IG27:                ;; offset=0x02F0
       mov      rsi, rbx
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG28
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0318
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x68]
       mov      r11, 0x7F7D89E72368
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG29:                ;; offset=0x0337
       test     r15d, r15d
       jne      G_M000_IG12
       mov      dword ptr [rbp-0x24], 1
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x30], 1
       lea      rdi, bword ptr [rdx+0x90]
       lea      rsi, bword ptr [rbp-0x70]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x50], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x50]
       mov      rdi, 0x7F7D8CBB9BE8
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x70]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG116
 
G_M000_IG30:                ;; offset=0x0395
       mov      rsi, rbx
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG32
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG31
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG31:                ;; offset=0x03CC
       movzx    r15, byte  ptr [r15+0x38]
       jmp      G_M000_IG13
 
G_M000_IG32:                ;; offset=0x03D6
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x68]
       mov      r11, 0x7F7D89E72370
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
       jmp      G_M000_IG13
 
G_M000_IG33:                ;; offset=0x03F3
       mov      rbx, gword ptr [rbp-0x60]
       test     rbx, rbx
       je       SHORT G_M000_IG36
       mov      rsi, rbx
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG34
       mov      esi, dword ptr [rax+0x34]
       and      esi, 0x1600000
       cmp      esi, 0x1000000
       sete     sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x042C
       movsx    rsi, word  ptr [rbp-0x58]
       mov      rdi, rbx
       mov      r11, 0x7F7D89E72378
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       cmp      eax, 1
       sete     sil
       movzx    rsi, sil
 
G_M000_IG35:                ;; offset=0x044C
       test     esi, esi
       je       SHORT G_M000_IG41
 
G_M000_IG36:                ;; offset=0x0450
       mov      rbx, gword ptr [rbp-0x60]
       test     rbx, rbx
       jne      SHORT G_M000_IG37
       movzx    r15, byte  ptr [rbp-0x56]
       jmp      SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x0460
       mov      rsi, rbx
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG39
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG38
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG38:                ;; offset=0x0497
       movzx    r15, byte  ptr [r15+0x38]
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x049E
       movsx    rsi, word  ptr [rbp-0x58]
       mov      rdi, rbx
       mov      r11, 0x7F7D89E72380
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
 
G_M000_IG40:                ;; offset=0x04B6
       mov      rdi, gword ptr [rbp-0xF8]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ThrowIfDeadlineExpired():this]
       jmp      G_M000_IG13
 
G_M000_IG41:                ;; offset=0x04C8
       lea      rdi, [rbp-0x60]
       call     [System.Threading.Tasks.ValueTask`1[bool]:AsTask():System.Threading.Tasks.Task`1[bool]:this]
       mov      rdx, gword ptr [rbp-0xF0]
       lea      rdi, bword ptr [rdx+0x28]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0xF0]
 
G_M000_IG42:                ;; offset=0x04EC
       cmp      dword ptr [rbp-0x24], 2
       je       G_M000_IG48
       xor      edi, edi
       mov      dword ptr [rdx+0x34], edi
       mov      rdi, gword ptr [rdx+0x28]
       mov      rax, gword ptr [rbp-0xF8]
       vmovdqu  ymm0, ymmword ptr [rax+0x38]
       vmovdqu  ymmword ptr [rbp-0xC8], ymm0
       mov      rsi, qword ptr [rax+0x58]
       mov      qword ptr [rbp-0xA8], rsi
       mov      rsi, gword ptr [rax+0x08]
       mov      rcx, gword ptr [rdx+0x10]
       cmp      byte  ptr [rcx+0x24], 0
       je       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x052C
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG44:                ;; offset=0x0538
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      r8, qword ptr [rbp-0xA8]
       mov      qword ptr [rsp+0x20], r8
       mov      rdx, rcx
       call     [SharpLink.Abstractions.SharpLinkTimer:WaitAsync(System.Threading.Tasks.Task,SharpLink.Abstractions.RpcDeadline,System.TimeProvider,System.Threading.CancellationToken):System.Threading.Tasks.ValueTask`1[bool]]
       mov      gword ptr [rbp-0x80], rax
       mov      qword ptr [rbp-0x78], rdx
       mov      rsi, gword ptr [rbp-0x80]
       movzx    rdi, byte  ptr [rbp-0x76]
       movsx    rax, word  ptr [rbp-0x78]
       mov      gword ptr [rbp-0x70], rsi
       mov      word  ptr [rbp-0x68], ax
       mov      byte  ptr [rbp-0x66], dil
       mov      byte  ptr [rbp-0x65], 0
       mov      r15, gword ptr [rbp-0x70]
       test     r15, r15
       je       G_M000_IG51
 
G_M000_IG45:                ;; offset=0x059B
       mov      rsi, r15
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG46
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x05C1
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x68]
       mov      r11, 0x7F7D89E72388
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG47:                ;; offset=0x05DE
       test     ebx, ebx
       jne      G_M000_IG51
       mov      dword ptr [rbp-0x24], 2
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x30], 2
       lea      rdi, bword ptr [rdx+0x90]
       lea      rsi, bword ptr [rbp-0x70]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x50], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x50]
       mov      rdi, 0x7F7D8CBB9BE8
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x70]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG116
 
G_M000_IG48:                ;; offset=0x063B
       lea      rdi, bword ptr [rdx+0x90]
 
G_M000_IG49:                ;; offset=0x0642
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG50:                ;; offset=0x064B
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x24], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG51:                ;; offset=0x0662
       mov      rbx, gword ptr [rbp-0x70]
       test     rbx, rbx
       jne      SHORT G_M000_IG52
       movzx    r15, byte  ptr [rbp-0x66]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x0672
       mov      rsi, rbx
       mov      rdi, 0x7F7D8C5518B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG54
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG53
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG53:                ;; offset=0x06A9
       movzx    r15, byte  ptr [r15+0x38]
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x06B0
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x68]
       mov      r11, 0x7F7D89E72390
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
 
G_M000_IG55:                ;; offset=0x06C8
       test     r15d, r15d
       jne      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x06CD
       mov      rax, gword ptr [rbp-0xF8]
       mov      rdi, gword ptr [rax+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG57
       call     [SharpLink.Client.SharpLinkClient+ClientLogicalCallState:TryClaimDeadline():bool:this]
 
G_M000_IG57:                ;; offset=0x06E3
       mov      rdx, gword ptr [rbp-0xF0]
       mov      byte  ptr [rdx+0x3D], 1
       call     [SharpLink.Client.SharpLinkClient:CreateDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      r15, rax
       mov      rbx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rdi, r15
       xor      rdx, rdx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateOwnerCore(System.Exception,System.Threading.CancellationTokenSource,System.Exception):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r14, rax
       mov      rdi, gword ptr [rbx+0x28]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, r14
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r14
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG58:                ;; offset=0x073C
       xor      edi, edi
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x34], edi
       mov      rdi, gword ptr [rdx+0x28]
       cmp      byte  ptr [rdi], dil
       mov      gword ptr [rbp-0x90], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x88], edi
       test     byte  ptr [rbp-0x88], 4
       jne      SHORT G_M000_IG59
       mov      rdi, gword ptr [rbp-0x90]
       test     dword ptr [rdi+0x34], 0x1600000
       jne      G_M000_IG62
 
G_M000_IG59:                ;; offset=0x077B
       mov      dword ptr [rbp-0x24], 3
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x30], 3
       lea      rdi, bword ptr [rdx+0xA0]
       mov      rsi, gword ptr [rbp-0x90]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x88]
       mov      rbx, gword ptr [rbp-0xF0]
       mov      dword ptr [rbx+0xA8], edx
       mov      gword ptr [rbp-0x50], rbx
       lea      rdx, bword ptr [rbx+0x40]
       lea      rsi, [rbp-0x50]
       mov      rdi, 0x7F7D8CBB9BE8
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x90]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG116
 
G_M000_IG60:                ;; offset=0x07E7
       vmovdqu  xmm0, xmmword ptr [rdx+0xA0]
       vmovdqu  xmmword ptr [rbp-0x90], xmm0
 
G_M000_IG61:                ;; offset=0x07F7
       xor      edi, edi
       mov      qword ptr [rdx+0xA0], rdi
       mov      qword ptr [rdx+0xA8], rdi
       mov      dword ptr [rbp-0x24], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG62:                ;; offset=0x0815
       lea      rdi, [rbp-0x90]
       call     [System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]:GetResult():bool:this]
       mov      r15d, eax
       xor      rdi, rdi
       mov      rdx, gword ptr [rbp-0xF0]
       mov      gword ptr [rdx+0x28], rdi
       jmp      G_M000_IG13
 
G_M000_IG63:                ;; offset=0x0837
       mov      rdi, r11
       mov      r11, 0x7F7D89E72350
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      ebx, eax
       jmp      G_M000_IG15
 
G_M000_IG64:                ;; offset=0x084E
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x34], ebx
       mov      dword ptr [rbp-0x24], -4
       mov      dword ptr [rdx+0x30], -4
       jmp      G_M000_IG109
 
G_M000_IG65:                ;; offset=0x086B
       cmp      byte  ptr [rdx+0x3C], 0
       jne      G_M000_IG118
       mov      dword ptr [rbp-0x24], -1
       mov      dword ptr [rdx+0x30], -1
       mov      r8, gword ptr [rbp-0xF8]
       lea      rsi, bword ptr [r8+0x18]
       mov      edi, 1
       xchg     dword ptr [rsi], edi
       test     edi, edi
       je       SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x0899
       mov      rdi, 0x7F7D8B057150
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0x10465
       mov      rsi, 0x7F7D8B834600
       call     [CORINFO_HELP_STRCNS]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x08D5
       xor      esi, esi
       mov      dword ptr [rdx+0x34], esi
       lea      rsi, bword ptr [r8+0x20]
       mov      rdi, gword ptr [rsi]
       mov      rax, gword ptr [rsi+0x10]
       movsx    rsi, word  ptr [rsi+0x08]
       mov      gword ptr [rbp-0x48], rdi
       mov      word  ptr [rbp-0x40], si
       mov      byte  ptr [rbp-0x3E], 0
       mov      gword ptr [rbp-0x38], rax
       mov      rbx, gword ptr [rbp-0x48]
       test     rbx, rbx
       je       G_M000_IG73
 
G_M000_IG68:                ;; offset=0x0907
       mov      rsi, rbx
       mov      rdi, 0x7F7D8CB9A7B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG69
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x092F
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x40]
       mov      r11, 0x7F7D89E72358
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG70:                ;; offset=0x094E
       test     r15d, r15d
       jne      G_M000_IG73
       xor      edi, edi
       mov      rdx, gword ptr [rbp-0xF0]
       mov      dword ptr [rdx+0x30], edi
       lea      rdi, bword ptr [rdx+0x78]
       lea      rsi, bword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       call     CORINFO_HELP_ASSIGN_BYREF
       mov      gword ptr [rbp-0x50], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x50]
       mov      rdi, 0x7F7D8CBB9BE8
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x48]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[SharpLink.Abstractions.SharpLinkClientInvocationResult]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG116
 
G_M000_IG71:                ;; offset=0x09A5
       vmovdqu  xmm0, xmmword ptr [rdx+0x78]
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       mov      rsi, qword ptr [rdx+0x88]
       mov      qword ptr [rbp-0x38], rsi
 
G_M000_IG72:                ;; offset=0x09BA
       xor      esi, esi
       mov      qword ptr [rdx+0x78], rsi
       mov      qword ptr [rdx+0x80], rsi
       mov      qword ptr [rdx+0x88], rsi
       mov      dword ptr [rbp-0x24], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG73:                ;; offset=0x09DC
       mov      r8, gword ptr [rbp-0xF8]
       mov      rbx, gword ptr [rbp-0x48]
       test     rbx, rbx
       jne      SHORT G_M000_IG74
       mov      r15, gword ptr [rbp-0x38]
       jmp      SHORT G_M000_IG77
 
G_M000_IG74:                ;; offset=0x09F2
       mov      rsi, rbx
       mov      rdi, 0x7F7D8CB9A7B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG76
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG75
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG75:                ;; offset=0x0A29
       mov      r15, gword ptr [r15+0x38]
       mov      r8, gword ptr [rbp-0xF8]
       jmp      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0A36
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x40]
       mov      r11, 0x7F7D89E72360
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:GetResult(short):SharpLink.Abstractions.SharpLinkClientInvocationResult:this
       mov      r15, rax
       mov      r8, gword ptr [rbp-0xF8]
 
G_M000_IG77:                ;; offset=0x0A55
       mov      gword ptr [rbp-0x30], r15
       mov      rdi, r8
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ThrowIfDeadlineExpired():this]
       lea      rdi, [rbp-0x30]
       mov      rsi, 0x7F7D8CBB0A90
       call     [SharpLink.Abstractions.SharpLinkClientInvocationResult:GetValue[System.__Canon]():System.__Canon:this]
       mov      rbx, rax
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rdi, gword ptr [rdi+0x60]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rdx+0x70]
       call     [System.Threading.CancellationTokenSource:CreateLinkedTokenSource(System.Threading.CancellationToken,System.Threading.CancellationToken):System.Threading.CancellationTokenSource]
       mov      rdx, gword ptr [rbp-0xF0]
       lea      rdi, bword ptr [rdx+0x10]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG78:                ;; offset=0x0AA9
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rdx+0x10]
       cmp      byte  ptr [rsi+0x24], 0
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0ABA
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG80:                ;; offset=0x0AC6
       mov      rdi, 0x7F7D8CB797F8
       cmp      qword ptr [rbx], rdi
       jne      SHORT G_M000_IG81
       mov      rdi, rbx
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this]
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0AE0
       mov      rdi, rbx
       mov      r11, 0x7F7D89E72340
       call     [r11]System.Collections.Generic.IAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this
 
G_M000_IG82:                ;; offset=0x0AF0
       mov      rdx, gword ptr [rbp-0xF0]
       lea      rdi, bword ptr [rdx+0x18]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG83:                ;; offset=0x0B04
       mov      rdx, gword ptr [rbp-0xF0]
       mov      byte  ptr [rdx+0x3D], 0
       xor      rdi, rdi
       mov      gword ptr [rdx+0x20], rdi
 
G_M000_IG84:                ;; offset=0x0B15
       mov      dword ptr [rdx+0x38], edi
       jmp      G_M000_IG05
 
G_M000_IG85:                ;; offset=0x0B1D
       mov      r15, gword ptr [rbp-0xF0]
       cmp      byte  ptr [r15+0x3D], 0
       jne      G_M000_IG105
 
G_M000_IG86:                ;; offset=0x0B2F
       mov      rdx, gword ptr [rbp-0xF0]
       cmp      dword ptr [rbp-0x24], 4
       je       G_M000_IG92
       mov      rdi, gword ptr [rdx+0x10]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:TryCancelLifetime(System.Threading.CancellationTokenSource)]
       xor      edi, edi
       mov      rbx, gword ptr [rbp-0xF0]
       mov      dword ptr [rbx+0x34], edi
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, 0x7F7D8CB797F8
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG87
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:DisposeAsync():System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      qword ptr [rbp-0xE0], rdx
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0B7F
       mov      r11, 0x7F7D89E72338
       call     [r11]System.IAsyncDisposable:DisposeAsync():System.Threading.Tasks.ValueTask:this
       mov      gword ptr [rbp-0xE8], rax
       mov      qword ptr [rbp-0xE0], rdx
 
G_M000_IG88:                ;; offset=0x0B9A
       mov      rsi, gword ptr [rbp-0xE8]
       movsx    rdi, word  ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xA0], rsi
       mov      word  ptr [rbp-0x98], di
       mov      byte  ptr [rbp-0x96], 0
       mov      r15, gword ptr [rbp-0xA0]
       test     r15, r15
       je       G_M000_IG94
 
G_M000_IG89:                ;; offset=0x0BCE
       mov      rsi, r15
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG90
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0BF6
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x98]
       mov      r11, 0x7F7D89E72398
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG91:                ;; offset=0x0C18
       test     r14d, r14d
       jne      SHORT G_M000_IG94
       mov      dword ptr [rbx+0x30], 4
       lea      rdi, bword ptr [rbx+0xB0]
       lea      rsi, bword ptr [rbp-0xA0]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x50], rbx
       lea      rdx, bword ptr [rbx+0x40]
       lea      rsi, [rbp-0x50]
       mov      rdi, 0x7F7D8CBB9BE8
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG116
 
G_M000_IG92:                ;; offset=0x0C6A
       vmovdqu  xmm0, xmmword ptr [rdx+0xB0]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG93:                ;; offset=0x0C7A
       xor      esi, esi
       mov      qword ptr [rdx+0xB0], rsi
       mov      qword ptr [rdx+0xB8], rsi
       mov      dword ptr [rdx+0x30], -1
       mov      rbx, rdx
 
G_M000_IG94:                ;; offset=0x0C94
       mov      r15, gword ptr [rbp-0xA0]
       test     r15, r15
       je       SHORT G_M000_IG101
 
G_M000_IG95:                ;; offset=0x0CA0
       mov      rsi, r15
       mov      rdi, 0x7F7D8AF56E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG98
 
G_M000_IG96:                ;; offset=0x0CB7
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG101
 
G_M000_IG97:                ;; offset=0x0CC8
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG101
 
G_M000_IG98:                ;; offset=0x0CD5
       mov      rdi, 0x7F7D8C7CF178
       cmp      qword ptr [r15], rdi
       jne      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0CE4
       movsx    rsi, word  ptr [rbp-0x98]
       mov      rdi, r15
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0CF7
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x98]
       mov      r11, 0x7F7D89E723A0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       nop      
 
G_M000_IG101:                ;; offset=0x0D10
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, qword ptr [r15]
       mov      rdi, 0x7F7D8C7D5810
       cmp      r14, rdi
       jne      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0D26
       mov      rdi, r15
       mov      esi, 1
       call     [System.Threading.CancellationTokenSource+Linked1CancellationTokenSource:Dispose(bool):this]
       jmp      SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0D36
       mov      rdi, r15
       mov      esi, 1
       mov      rax, qword ptr [r14+0x40]
       call     [rax+0x28]System.Threading.CancellationTokenSource:Dispose(bool):this
 
G_M000_IG104:                ;; offset=0x0D45
       mov      rdi, r15
       call     [System.GC:SuppressFinalize(System.Object)]
       mov      r15, rbx
 
G_M000_IG105:                ;; offset=0x0D51
       mov      rbx, gword ptr [r15+0x20]
       test     rbx, rbx
       je       SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0D5A
       mov      rsi, rbx
       mov      rdi, 0x7F7D8AE905D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG107
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG107:                ;; offset=0x0D7A
       mov      rdi, rax
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Capture(System.Exception):System.Runtime.ExceptionServices.ExceptionDispatchInfo]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Throw():this]
       int3     
 
G_M000_IG108:                ;; offset=0x0D8F
       cmp      byte  ptr [r15+0x3C], 0
       jne      G_M000_IG118
       xor      rsi, rsi
       mov      gword ptr [r15+0x20], rsi
       jmp      G_M000_IG118
 
G_M000_IG109:                ;; offset=0x0DA5
       lea      rbx, bword ptr [rdx+0x48]
       mov      byte  ptr [rbx+0x22], 1
       cmp      byte  ptr [rbx+0x23], 0
       jne      G_M000_IG123
       mov      byte  ptr [rbx+0x23], 1
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG117
 
G_M000_IG110:                ;; offset=0x0DC7
       test     r15, r15
       je       G_M000_IG116
 
G_M000_IG111:                ;; offset=0x0DD0
       mov      r14, gword ptr [rbx+0x10]
       test     r14, r14
       jne      G_M000_IG131
       cmp      byte  ptr [rbx+0x24], 0
       jne      G_M000_IG124
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, 0x7F7D8C97AB80
       cmp      qword ptr [r15+0x18], rdi
       jne      G_M000_IG130
       mov      r15, rsi
       test     r15, r15
       je       SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0E07
       mov      rdi, 0x7F7D8CA3A628
       cmp      qword ptr [r15], rdi
       jne      G_M000_IG125
 
G_M000_IG113:                ;; offset=0x0E1A
       test     r15, r15
       je       G_M000_IG126
       mov      rdi, 0x7F75A5801898
       mov      rbx, gword ptr [rdi]
       cmp      byte  ptr [rbx+0x38], 0
       jne      G_M000_IG127
 
G_M000_IG114:                ;; offset=0x0E3A
       mov      r14, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [r14+0x10]
       mov      rsi, r15
       cmp      dword ptr [rdi], edi
       call     [System.Collections.Concurrent.ConcurrentQueueSegment`1[System.__Canon]:TryEnqueue(System.__Canon):bool:this]
       test     eax, eax
       je       G_M000_IG128
 
G_M000_IG115:                ;; offset=0x0E55
       add      rbx, 120
       mov      edi, 1
       xchg     dword ptr [rbx], edi
       test     edi, edi
       jne      SHORT G_M000_IG116
       mov      rdi, 0x7F75A58019E8
       mov      rbx, gword ptr [rdi]
       lea      rdi, bword ptr [rbx+0x160]
       lock     
       inc      dword ptr [rdi]
       mov      rdi, rbx
       call     [System.Threading.PortableThreadPool+WorkerThread:MaybeAddWorkingWorker(System.Threading.PortableThreadPool)]
       cmp      dword ptr [rbx+0x164], 6
       jne      G_M000_IG129
 
G_M000_IG116:                ;; offset=0x0E91
       vzeroupper 
       add      rsp, 288
       pop      rbx
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG117:                ;; offset=0x0EA4
       mov      rsi, 0x7F75A5801DB8
       mov      rsi, gword ptr [rsi]
       mov      rdi, rbx
       xor      rdx, rdx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      r15, rax
       jmp      G_M000_IG110
 
G_M000_IG118:                ;; offset=0x0EC3
       mov      r15, gword ptr [rbp-0xF0]
       mov      dword ptr [r15+0x30], -2
       xor      rdi, rdi
       mov      gword ptr [r15+0x10], rdi
 
G_M000_IG119:                ;; offset=0x0ED8
       mov      gword ptr [r15+0x18], rdi
 
G_M000_IG120:                ;; offset=0x0EDC
       mov      gword ptr [r15+0x20], rdi
 
G_M000_IG121:                ;; offset=0x0EE0
       mov      gword ptr [r15+0x28], rdi
 
G_M000_IG122:                ;; offset=0x0EE4
       mov      dword ptr [r15+0x34], edi
       lea      rdi, bword ptr [r15+0x40]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x48]
       mov      byte  ptr [rdi+0x22], 0
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SignalCompletion():this]
       jmp      SHORT G_M000_IG116
 
G_M000_IG123:                ;; offset=0x0F02
       call     [System.ThrowHelper:ThrowInvalidOperationException()]
       int3     
 
G_M000_IG124:                ;; offset=0x0F09
       mov      rdx, gword ptr [rbx+0x08]
       mov      rsi, r15
       mov      rdi, 0x7F7D8C940C38
       mov      ecx, 1
       call     [System.Threading.ThreadPool:UnsafeQueueUserWorkItem[System.__Canon](System.Action`1[System.__Canon],System.__Canon,bool):bool]
       jmp      G_M000_IG116
 
G_M000_IG125:                ;; offset=0x0F2A
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG126:                ;; offset=0x0F30
       mov      edi, 44
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG127:                ;; offset=0x0F3C
       mov      rdi, 0x7F75A5801850
       mov      rdi, gword ptr [rdi]
       cmp      byte  ptr [rdi+0x9D], 0
       je       G_M000_IG114
       mov      rdi, 0x7F75A5801850
       mov      rdi, gword ptr [rdi]
       mov      rsi, r15
       call     [System.Diagnostics.Tracing.FrameworkEventSource:ThreadPoolEnqueueWorkObject(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG128:                ;; offset=0x0F71
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Collections.Concurrent.ConcurrentQueue`1[System.__Canon]:EnqueueSlow(System.__Canon):this]
       jmp      G_M000_IG115
 
G_M000_IG129:                ;; offset=0x0F82
       mov      rdi, rbx
       call     [System.Threading.PortableThreadPool+GateThread:EnsureRunningSlow(System.Threading.PortableThreadPool)]
       jmp      G_M000_IG116
 
G_M000_IG130:                ;; offset=0x0F90
       mov      rdi, gword ptr [r15+0x08]
       call     [r15+0x18]System.Action`1[System.__Canon]:Invoke(System.__Canon):this
       jmp      G_M000_IG116
 
G_M000_IG131:                ;; offset=0x0F9D
       mov      rsi, r14
       mov      rdi, 0x7F7D8AF5A7C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG132
       mov      rsi, r14
       mov      rdi, 0x7F7D8C940CE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0FCB
       movzx    rcx, byte  ptr [rbx+0x24]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:InvokeContinuationWithContext(System.Object,System.Action`1[System.Object],System.Object,bool)]
       jmp      G_M000_IG116
 
G_M000_IG133:                ;; offset=0x0FE4
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:ScheduleCapturedContext(System.Object,System.Action`1[System.Object],System.Object)]
       jmp      G_M000_IG116
 
G_M000_IG134:                ;; offset=0x0FF9
       sub      rsp, 40
 
G_M000_IG135:                ;; offset=0x0FFD
       mov      rbx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, 1
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:TransferLifetime(System.Exception,System.Threading.CancellationTokenSource,bool):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG137
 
G_M000_IG136:                ;; offset=0x1018
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG137:                ;; offset=0x1021
       mov      rdi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG138:                ;; offset=0x1033
       sub      rsp, 40
 
G_M000_IG139:                ;; offset=0x1037
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C1528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG141
 
G_M000_IG140:                ;; offset=0x104E
       xor      eax, eax
       jmp      SHORT G_M000_IG142
 
G_M000_IG141:                ;; offset=0x1052
       mov      gword ptr [rbp-0x100], rax
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rdi, gword ptr [rdx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG142:                ;; offset=0x1074
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG143:                ;; offset=0x107C
       sub      rsp, 40
 
G_M000_IG144:                ;; offset=0x1080
       mov      rdx, gword ptr [rbp-0xF0]
       mov      byte  ptr [rdx+0x3D], 1
       mov      rdi, gword ptr [rbp-0x100]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      r15, rax
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rdx, gword ptr [rdx+0x10]
       mov      rdi, r15
       mov      rsi, gword ptr [rbp-0x100]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rdi, gword ptr [rdx+0x28]
       mov      rsi, gword ptr [rdx+0x18]
       mov      rdx, gword ptr [rdx+0x10]
       mov      rcx, rbx
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG145:                ;; offset=0x10EC
       sub      rsp, 40
 
G_M000_IG146:                ;; offset=0x10F0
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C1528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x110A
       xor      eax, eax
       jmp      SHORT G_M000_IG154
 
G_M000_IG148:                ;; offset=0x110E
       mov      gword ptr [rbp-0x108], rbx
       mov      r15, gword ptr [rbp-0xF0]
       cmp      byte  ptr [r15+0x3D], 0
       jne      SHORT G_M000_IG152
 
G_M000_IG149:                ;; offset=0x1123
       mov      rdi, gword ptr [r15+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x1133
       mov      rdi, rbx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       setne    al
       movzx    rax, al
       jmp      SHORT G_M000_IG153
 
G_M000_IG151:                ;; offset=0x1147
       mov      eax, 1
       jmp      SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x114E
       xor      eax, eax
 
G_M000_IG153:                ;; offset=0x1150
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG154:                ;; offset=0x1158
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG155:                ;; offset=0x1160
       sub      rsp, 40
 
G_M000_IG156:                ;; offset=0x1164
       mov      r15, gword ptr [rbp-0xF0]
       mov      byte  ptr [r15+0x3D], 1
       mov      rdi, gword ptr [rbp-0x108]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      rbx, rax
       mov      rdx, gword ptr [r15+0x10]
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x108]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r14, rax
       mov      rdi, gword ptr [rbp-0x108]
       call     [System.Threading.Tasks.Task:FromException(System.Exception):System.Threading.Tasks.Task]
       mov      rdi, rax
       mov      rsi, gword ptr [r15+0x18]
       mov      rdx, gword ptr [r15+0x10]
       mov      rcx, r14
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r14
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG157:                ;; offset=0x11CF
       sub      rsp, 40
 
G_M000_IG158:                ;; offset=0x11D3
       mov      rsi, rdi
       mov      rdi, 0x7F7D8C7C0880
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x11ED
       xor      eax, eax
       jmp      SHORT G_M000_IG167
 
G_M000_IG160:                ;; offset=0x11F1
       mov      gword ptr [rbp-0x110], rbx
       mov      r15, gword ptr [rbp-0xF0]
       cmp      byte  ptr [r15+0x3D], 0
       jne      SHORT G_M000_IG165
 
G_M000_IG161:                ;; offset=0x1206
       mov      rdi, rbx
       call     [SharpLink.Abstractions.SharpLinkException:get_Code():int:this]
       cmp      eax, 13
       jne      SHORT G_M000_IG165
 
G_M000_IG162:                ;; offset=0x1214
       mov      rdi, gword ptr [rbp-0xF8]
       add      rdi, 56
       mov      rsi, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rsi+0x08]
       call     [SharpLink.Abstractions.RpcDeadline:IsExpired(System.TimeProvider):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG164
 
G_M000_IG163:                ;; offset=0x1234
       mov      rdi, rbx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       setne    al
       movzx    rax, al
       jmp      SHORT G_M000_IG166
 
G_M000_IG164:                ;; offset=0x1248
       mov      eax, 1
       jmp      SHORT G_M000_IG166
 
G_M000_IG165:                ;; offset=0x124F
       xor      eax, eax
 
G_M000_IG166:                ;; offset=0x1251
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG167:                ;; offset=0x1259
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG168:                ;; offset=0x1261
       sub      rsp, 40
 
G_M000_IG169:                ;; offset=0x1265
       mov      r15, gword ptr [rbp-0xF0]
       mov      byte  ptr [r15+0x3D], 1
       mov      rdi, gword ptr [rbp-0x110]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Abstractions.SharpLinkException:get_Code():int:this]
       mov      ebx, eax
       mov      rdi, gword ptr [rbp-0x110]
       call     [SharpLink.Abstractions.SharpLinkException:get_DetailCode():ushort:this]
       mov      r14d, eax
       mov      rdi, 0x7F7D8C7C0880
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, gword ptr [rbp-0x110]
       mov      rax, gword ptr [rbp-0x110]
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]System.Exception:get_Message():System.String:this
       mov      rcx, rax
       mov      esi, ebx
       mov      edx, r14d
       mov      rdi, r13
       mov      r8, gword ptr [rbp-0x110]
       call     [SharpLink.Abstractions.SharpLinkException:.ctor(int,ushort,System.String,System.Exception):this]
       mov      rdx, gword ptr [r15+0x10]
       mov      rdi, r13
       mov      rsi, gword ptr [rbp-0x110]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      rbx, rax
       mov      rdi, gword ptr [rbp-0x110]
       call     [System.Threading.Tasks.Task:FromException(System.Exception):System.Threading.Tasks.Task]
       mov      rdi, rax
       mov      rsi, gword ptr [r15+0x18]
       mov      rdx, gword ptr [r15+0x10]
       mov      rcx, rbx
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r13
 
G_M000_IG170:                ;; offset=0x131D
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG171:                ;; offset=0x1323
       sub      rsp, 40
 
G_M000_IG172:                ;; offset=0x1327
       mov      rsi, rdi
       mov      r15, gword ptr [rbp-0xF0]
       lea      rdi, bword ptr [r15+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rax, G_M000_IG85
 
G_M000_IG173:                ;; offset=0x1341
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG174:                ;; offset=0x1349
       sub      rsp, 40
 
G_M000_IG175:                ;; offset=0x134D
       mov      rbx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, 1
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:TransferLifetime(System.Exception,System.Threading.CancellationTokenSource,bool):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x1368
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG177:                ;; offset=0x1371
       mov      rdi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG178:                ;; offset=0x1383
       sub      rsp, 40
 
G_M000_IG179:                ;; offset=0x1387
       mov      rbx, rdi
       mov      r15, gword ptr [rbp-0xF0]
       mov      dword ptr [r15+0x30], -2
       xor      rdi, rdi
       mov      gword ptr [r15+0x10], rdi
 
G_M000_IG180:                ;; offset=0x139F
       mov      gword ptr [r15+0x18], rdi
 
G_M000_IG181:                ;; offset=0x13A3
       mov      gword ptr [r15+0x20], rdi
 
G_M000_IG182:                ;; offset=0x13A7
       mov      gword ptr [r15+0x28], rdi
 
G_M000_IG183:                ;; offset=0x13AB
       mov      dword ptr [r15+0x34], edi
       lea      rdi, bword ptr [r15+0x40]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x48]
       mov      rsi, rbx
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SetException(System.Exception):this]
       lea      rax, G_M000_IG116
 
G_M000_IG184:                ;; offset=0x13CD
       vzeroupper 
       add      rsp, 40
       ret      
 
RWD00  	dd	00000038h ; case G_M000_IG05
       	dd	0000080Fh ; case G_M000_IG65
       	dd	0000080Fh ; case G_M000_IG65
       	dd	0000080Fh ; case G_M000_IG65
       	dd	00000949h ; case G_M000_IG71
       	dd	00000038h ; case G_M000_IG05
       	dd	00000038h ; case G_M000_IG05
       	dd	00000038h ; case G_M000_IG05
       	dd	00000AD3h ; case G_M000_IG86
RWD36  	dd	00000189h ; case G_M000_IG17
       	dd	00000490h ; case G_M000_IG42
       	dd	0000078Bh ; case G_M000_IG60

; Total bytes 5077
