# Hosted R1 native mechanism and new boundary-test evidence

Run40681832353, attempt1, exact remote tool9c0cf9e682deb38c4c321e93db0f11d1338bc7bd:
independent VALID non-timed mechanism only. Both4352-operation processes pass all
four Tier1 targets, private10.0.13/defaultPGO and loaded-source/DLL identity gates.
The duplicate hasNext test/default assignment is removed, long jump remains,
intercepted body4806→5077 bytes/frame288 unchanged. No performance Go: #931 NoGo
and earlier cloud001/002/003 failures remain unchanged in their prior archive.

`hosted/extracted/` contains byte-identical original ZIP members except EXACTLY
the two official runtime installer tarballs. `official-artifact-members.json`
records every original member SHA256/size, inclusion status and excluded installers'
SHA512. Official ZIP itself is a transport container, not duplicated here. It is
89,150,325 bytes, SHA256c619069c6f79ca4332425e3a3e89acd86fbab8ea72d025d884077646869a76ed.
No raw native/process/host/identity/build/proof logs, prepared DLLs or failures were
removed or sanitized. Release metadata, verification logs and exact official
installer URLs/SHA512 pins remain in the reviewed tool patch. No build cache was
present in the official ZIP and no additional member exclusions were made.

`independent-review/` is the analyst's unmodified report,8 extracted target bodies,
verification JSON and verifier. Its original `verify.py` intentionally expects the
full official ZIP plus extracted/ folder and can be rerun after retrieving that
artifact; the compact mirror's complete member hashes are independently auditable
without reinstalling runtimes. `owner-revalidation.json`, if present, is supplemental
owner output outside the official ZIP, explicitly distinguished from raw evidence.

`native-tool-reviewed.patch` is local reviewed760a6d7 with tree identical to executed
remote9c0cf9e; not a claim that the local SHA executed on GitHub. `r1-product.patch`
is exact ac17→94 source change. `current-boundary-tests/` retains all8-test logs,
JSON/HTML results, test-only patch and provenance. Tests ran exactc4cb577 with src/
identical to94adeae8; this is8 focused Linux/private10.0.13 passes, not a full suite.
The earlier67 Unit/5 Integration macOS results remain in the older cloud archive.

This archive is evidence retention only: not a release, performance acceptance,
merge authorization, or permission to change the frozen future diagnostic plan.
