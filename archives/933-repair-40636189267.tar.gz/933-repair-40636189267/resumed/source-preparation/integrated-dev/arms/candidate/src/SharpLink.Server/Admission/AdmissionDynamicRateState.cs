using System.Threading.RateLimiting;

namespace SharpLink.Server;

/// <summary>
/// Serializes one logical Global / Contract / Method rate lineage. Old generation states remain
/// independently usable, but every post-transition grant is conservatively charged to the current
/// state so overlapping generations cannot manufacture quota.
/// </summary>
internal sealed class AdmissionRateTransitionLineage
{
    internal Lock Gate { get; } = new();

    private AdmissionDynamicRateState? _current;

    internal AdmissionDynamicRateState? CurrentLocked => _current;

    internal void AttachFresh(AdmissionDynamicRateState state)
    {
        lock (Gate)
        {
            if (_current is not null)
                throw new InvalidOperationException("Admission rate lineage already has a current state.");
            _current = state;
        }
    }

    internal void CommitTransition(
        AdmissionDynamicRateState source,
        AdmissionDynamicRateState? target,
        long now)
    {
        lock (Gate)
        {
            if (!ReferenceEquals(_current, source))
            {
                throw new InvalidOperationException(
                    "Admission rate transition source is no longer the current logical rate state.");
            }

            target?.InitializeTransitionLocked(source, now);
            _current = target;
        }
    }

    internal void DetachIfCurrentLocked(AdmissionDynamicRateState state)
    {
        if (ReferenceEquals(_current, state))
            _current = null;
    }
}

/// <summary>
/// SharpLink-owned deterministic rate state. Configuration is immutable per program generation;
/// quota/history are mutable under the logical lineage lock and may be conservatively translated
/// into a prepared successor at publication time.
/// </summary>
internal sealed class AdmissionDynamicRateState : IDisposable, IAdmissionRateWaiterOwner
{
    private readonly AdmissionRateStateDefinition _definition;
    private readonly TimeProvider _timeProvider;
    private readonly long[] _slidingSegments;
    private AdmissionRateWaitQueue _waiters;
    private ITimer? _timer;
    private long _tokenDebt;
    private long _tokenAnchor;
    private long _tokenTransitionCredit;
    private long _slidingOwnTotal;
    private int _slidingCurrentSegment;
    private long _slidingSegmentStart;
    private long _transitionDebt;
    private long _transitionDebtExpiry;
    private long _latestGrantTimestamp = long.MinValue;
    private int _disposed;

    internal AdmissionDynamicRateState(
        AdmissionRateStateDefinition definition,
        TimeProvider timeProvider,
        AdmissionRateTransitionLineage? lineage = null)
    {
        if (definition.Kind is AdmissionRateStateKind.None or AdmissionRateStateKind.FixedWindow)
        {
            throw new InvalidOperationException(
                "Legacy dynamic rate state supports TokenBucket or SlidingWindow only.");
        }
        _definition = definition;
        _timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        Lineage = lineage ?? new AdmissionRateTransitionLineage();
        _slidingSegments = definition.Kind == AdmissionRateStateKind.SlidingWindow
            ? new long[definition.Segments]
            : [];

        var now = _timeProvider.GetTimestamp();
        _tokenAnchor = now;
        _slidingSegmentStart = now;
        if (lineage is null)
            Lineage.AttachFresh(this);
    }

    internal AdmissionRateTransitionLineage Lineage { get; }

    internal AdmissionRateStateDefinition Definition => _definition;

    internal int WaitingCount
    {
        get
        {
            lock (Lineage.Gate)
                return _waiters.Count;
        }
    }

    internal long TransitionDebtForDiagnostics
    {
        get
        {
            lock (Lineage.Gate)
            {
                AdvanceLocked(_timeProvider.GetTimestamp());
                return GetBurdenLocked();
            }
        }
    }

    internal long TransitionBarrierExpiryForDiagnostics
    {
        get
        {
            lock (Lineage.Gate)
            {
                var now = _timeProvider.GetTimestamp();
                AdvanceLocked(now);
                return GetDebtExpiryLocked(now);
            }
        }
    }

    internal RateLimitLease AttemptAcquire(int permitCount)
    {
        ValidatePermitCount(permitCount);
        lock (Lineage.Gate)
        {
            if (_disposed != 0)
                return AdmissionRateLeases.Failed;

            var now = _timeProvider.GetTimestamp();
            AdvanceLocked(now);
            if (_waiters.Count != 0 || !CanGrantLocked())
                return AdmissionRateLeases.Failed;

            RecordGrantLocked(now);
            return AdmissionRateLeases.Acquired;
        }
    }

    internal ValueTask<RateLimitLease> AcquireAsync(
        int permitCount,
        CancellationToken cancellationToken)
    {
        ValidatePermitCount(permitCount);
        if (cancellationToken.IsCancellationRequested)
            return ValueTask.FromCanceled<RateLimitLease>(cancellationToken);

        AdmissionRateWaiter waiter;
        lock (Lineage.Gate)
        {
            if (_disposed != 0)
                return ValueTask.FromResult<RateLimitLease>(AdmissionRateLeases.Failed);

            var now = _timeProvider.GetTimestamp();
            AdvanceLocked(now);
            if (_waiters.Count == 0 && CanGrantLocked())
            {
                RecordGrantLocked(now);
                return ValueTask.FromResult<RateLimitLease>(AdmissionRateLeases.Acquired);
            }

            waiter = new AdmissionRateWaiter(this, cancellationToken);
            _waiters.Enqueue(waiter);
            ScheduleTimerLocked(now);
        }

        waiter.RegisterCancellation();
        return new ValueTask<RateLimitLease>(waiter.Task);
    }

    internal void CommitTransitionTo(AdmissionDynamicRateState? target)
        => Lineage.CommitTransition(this, target, _timeProvider.GetTimestamp());

    internal void InitializeTransitionLocked(AdmissionDynamicRateState source, long now)
    {
        if (!ReferenceEquals(Lineage, source.Lineage))
            throw new InvalidOperationException("Admission rate transition target belongs to a different lineage.");
        if (_disposed != 0)
            throw new ObjectDisposedException(nameof(AdmissionDynamicRateState));

        source.AdvanceLocked(now);
        ResetPreparedTargetLocked(now);

        if (source._definition.Kind == _definition.Kind)
        {
            switch (_definition.Kind)
            {
                case AdmissionRateStateKind.TokenBucket:
                    CopyTransitionBarrierLocked(source, now);
                    _tokenDebt = source._tokenDebt;
                    _tokenTransitionCredit = Math.Min(source._tokenTransitionCredit, _transitionDebt);
                    _tokenAnchor = source._definition.Secondary == _definition.Secondary &&
                                   source._definition.PeriodTicks == _definition.PeriodTicks
                        ? source._tokenAnchor
                        : now;
                    _latestGrantTimestamp = source._latestGrantTimestamp;
                    break;
                case AdmissionRateStateKind.SlidingWindow:
                    if (source._definition.PeriodTicks == _definition.PeriodTicks &&
                        source._definition.Segments == _definition.Segments)
                    {
                        CopyTransitionBarrierLocked(source, now);
                        Array.Copy(source._slidingSegments, _slidingSegments, _slidingSegments.Length);
                        _slidingOwnTotal = source._slidingOwnTotal;
                        _slidingCurrentSegment = source._slidingCurrentSegment;
                        _slidingSegmentStart = source._slidingSegmentStart;
                        _latestGrantTimestamp = source._latestGrantTimestamp;
                    }
                    else
                    {
                        InitializeConservativeBarrierLocked(source, now);
                    }
                    break;
                default:
                    throw new InvalidOperationException("Unsupported admission rate transition kind.");
            }
        }
        else
        {
            InitializeConservativeBarrierLocked(source, now);
        }
    }

    private void CopyTransitionBarrierLocked(AdmissionDynamicRateState source, long now)
    {
        _transitionDebt = source._transitionDebt;
        if (_transitionDebt == 0)
        {
            _transitionDebtExpiry = 0;
            return;
        }

        var anchor = source._latestGrantTimestamp == long.MinValue
            ? now
            : source._latestGrantTimestamp;
        var targetExpiry = SaturatingAdd(
            anchor,
            GetBarrierHorizonTimestampTicks(_transitionDebt));
        _transitionDebtExpiry = Math.Max(source._transitionDebtExpiry, targetExpiry);
    }

    private void InitializeConservativeBarrierLocked(AdmissionDynamicRateState source, long now)
    {
        var burden = source.GetBurdenLocked();
        _transitionDebt = burden;
        _latestGrantTimestamp = source._latestGrantTimestamp;
        _transitionDebtExpiry = burden == 0
            ? 0
            : GetConservativeTransitionExpiryLocked(source, now, burden);
    }

    private long GetConservativeTransitionExpiryLocked(
        AdmissionDynamicRateState source,
        long now,
        long burden)
    {
        var sourceExpiry = source.GetDebtExpiryLocked(now);
        var anchor = source._latestGrantTimestamp == long.MinValue
            ? now
            : source._latestGrantTimestamp;
        var targetExpiry = SaturatingAdd(anchor, GetBarrierHorizonTimestampTicks(burden));
        return Math.Max(sourceExpiry, targetExpiry);
    }

    private void ResetPreparedTargetLocked(long now)
    {
        _tokenDebt = 0;
        _tokenAnchor = now;
        _tokenTransitionCredit = 0;
        _slidingOwnTotal = 0;
        _slidingCurrentSegment = 0;
        _slidingSegmentStart = now;
        if (_slidingSegments.Length != 0)
            Array.Clear(_slidingSegments);
        _transitionDebt = 0;
        _transitionDebtExpiry = 0;
        _latestGrantTimestamp = long.MinValue;
    }

    private void RecordGrantLocked(long now)
    {
        RecordOwnGrantLocked();
        _latestGrantTimestamp = Math.Max(_latestGrantTimestamp, now);

        var current = Lineage.CurrentLocked;
        if (current is null || ReferenceEquals(current, this))
            return;

        var sourceExpiry = GetDebtExpiryLocked(now);
        current.AdvanceLocked(now);
        current.RecordLegacyGrantLocked(now, sourceExpiry);
        current.ScheduleTimerLocked(now);
    }

    private void RecordOwnGrantLocked()
    {
        switch (_definition.Kind)
        {
            case AdmissionRateStateKind.TokenBucket:
                _tokenDebt = SaturatingAdd(_tokenDebt, 1);
                break;
            case AdmissionRateStateKind.SlidingWindow:
                _slidingSegments[_slidingCurrentSegment] = SaturatingAdd(
                    _slidingSegments[_slidingCurrentSegment], 1);
                _slidingOwnTotal = SaturatingAdd(_slidingOwnTotal, 1);
                break;
            default:
                throw new InvalidOperationException("Unsupported admission rate state kind.");
        }
    }

    private void RecordLegacyGrantLocked(long now, long sourceExpiry)
    {
        _transitionDebt = SaturatingAdd(_transitionDebt, 1);
        var targetExpiry = SaturatingAdd(
            now,
            GetBarrierHorizonTimestampTicks(_transitionDebt));
        _transitionDebtExpiry = Math.Max(
            _transitionDebtExpiry,
            Math.Max(sourceExpiry, targetExpiry));
        _latestGrantTimestamp = Math.Max(_latestGrantTimestamp, now);
    }

    private bool CanGrantLocked()
        => GetBurdenLocked() < _definition.Limit;

    private long GetBurdenLocked()
        => SaturatingAdd(_transitionDebt, GetOwnBurdenLocked());

    private long GetOwnBurdenLocked()
        => _definition.Kind switch
        {
            AdmissionRateStateKind.TokenBucket => _tokenDebt,
            AdmissionRateStateKind.SlidingWindow => _slidingOwnTotal,
            _ => long.MaxValue
        };

    private long GetDebtExpiryLocked(long now)
    {
        if (GetBurdenLocked() == 0)
            return now;

        if (_definition.Kind == AdmissionRateStateKind.TokenBucket)
            return GetTokenCombinedDebtExpiryLocked(now);

        var expiry = _transitionDebt == 0 ? now : _transitionDebtExpiry;
        switch (_definition.Kind)
        {
            case AdmissionRateStateKind.SlidingWindow when _slidingOwnTotal != 0:
                expiry = Math.Max(expiry, GetSlidingOwnDebtExpiryLocked());
                break;
        }
        return expiry;
    }

    private long GetTokenCombinedDebtExpiryLocked(long now)
    {
        var uncreditedTransitionDebt = Math.Max(0, _transitionDebt - _tokenTransitionCredit);
        var cadenceDebt = SaturatingAdd(_tokenDebt, uncreditedTransitionDebt);
        var cadenceExpiry = cadenceDebt == 0
            ? now
            : SaturatingAdd(
                _tokenAnchor,
                SaturatingMultiply(
                    DivideRoundUp(cadenceDebt, _definition.Secondary),
                    GetPeriodTimestampTicks()));
        return _transitionDebt == 0
            ? cadenceExpiry
            : Math.Max(_transitionDebtExpiry, cadenceExpiry);
    }

    private long GetSlidingOwnDebtExpiryLocked()
        => SaturatingAdd(
            _slidingSegmentStart,
            SaturatingMultiply(_definition.Segments, GetSlidingSegmentTimestampTicks()));

    private void AdvanceLocked(long now)
    {
        if (_definition.Kind == AdmissionRateStateKind.TokenBucket)
        {
            AdvanceTokenBucketLocked(now);
            CompleteTokenTransitionBarrierLocked(now);
            return;
        }

        if (_transitionDebt != 0 && now >= _transitionDebtExpiry)
        {
            _transitionDebt = 0;
            _transitionDebtExpiry = 0;
        }

        if (_definition.Kind == AdmissionRateStateKind.SlidingWindow)
            AdvanceSlidingWindowLocked(now);
    }

    private void AdvanceTokenBucketLocked(long now)
    {
        var period = GetPeriodTimestampTicks();
        var elapsed = now - _tokenAnchor;
        if (elapsed < period)
            return;

        var periods = elapsed / period;
        var credit = SaturatingMultiply(periods, _definition.Secondary);
        if (_tokenDebt != 0)
        {
            var ownCredit = Math.Min(_tokenDebt, credit);
            _tokenDebt -= ownCredit;
            credit -= ownCredit;
        }

        if (credit != 0 && _transitionDebt != 0 && _tokenTransitionCredit < _transitionDebt)
        {
            var remainingTransitionDebt = _transitionDebt - _tokenTransitionCredit;
            _tokenTransitionCredit = SaturatingAdd(
                _tokenTransitionCredit,
                Math.Min(credit, remainingTransitionDebt));
        }

        _tokenAnchor = SaturatingAdd(_tokenAnchor, SaturatingMultiply(periods, period));
    }

    private void CompleteTokenTransitionBarrierLocked(long now)
    {
        if (_transitionDebt == 0 || now < _transitionDebtExpiry)
            return;

        var prepaid = Math.Min(_transitionDebt, _tokenTransitionCredit);
        var remainingTransitionDebt = _transitionDebt - prepaid;
        _tokenDebt = SaturatingAdd(_tokenDebt, remainingTransitionDebt);
        _transitionDebt = 0;
        _transitionDebtExpiry = 0;
        _tokenTransitionCredit = 0;
    }

    private void AdvanceSlidingWindowLocked(long now)
    {
        var segment = GetSlidingSegmentTimestampTicks();
        var elapsed = now - _slidingSegmentStart;
        if (elapsed < segment)
            return;

        var steps = elapsed / segment;
        if (steps >= _definition.Segments)
        {
            Array.Clear(_slidingSegments);
            _slidingOwnTotal = 0;
            _slidingCurrentSegment = (_slidingCurrentSegment + (int)(steps % _definition.Segments)) %
                                     _definition.Segments;
            _slidingSegmentStart = SaturatingAdd(
                _slidingSegmentStart,
                SaturatingMultiply(steps, segment));
            return;
        }

        for (var step = 0L; step < steps; step++)
        {
            _slidingCurrentSegment = (_slidingCurrentSegment + 1) % _definition.Segments;
            var expired = _slidingSegments[_slidingCurrentSegment];
            if (expired != 0)
            {
                _slidingOwnTotal -= expired;
                _slidingSegments[_slidingCurrentSegment] = 0;
            }
            _slidingSegmentStart = SaturatingAdd(_slidingSegmentStart, segment);
        }
    }

    private long GetNextAvailabilityTimestampLocked(long now)
    {
        if (CanGrantLocked())
            return now;

        var next = _transitionDebt == 0 ? long.MaxValue : _transitionDebtExpiry;
        switch (_definition.Kind)
        {
            case AdmissionRateStateKind.TokenBucket when _tokenDebt != 0:
                next = Math.Min(next, GetNextTokenOwnAvailabilityLocked());
                break;
            case AdmissionRateStateKind.SlidingWindow when _slidingOwnTotal != 0:
                next = Math.Min(next, GetNextSlidingOwnAvailabilityLocked());
                break;
        }
        return next;
    }

    private long GetNextTokenOwnAvailabilityLocked()
    {
        var requiredReduction = GetBurdenLocked() - _definition.Limit + 1;
        if (requiredReduction <= 0)
            return _timeProvider.GetTimestamp();
        if (requiredReduction > _tokenDebt)
            return long.MaxValue;

        var periods = DivideRoundUp(requiredReduction, _definition.Secondary);
        return SaturatingAdd(
            _tokenAnchor,
            SaturatingMultiply(periods, GetPeriodTimestampTicks()));
    }

    private long GetNextSlidingOwnAvailabilityLocked()
    {
        var segment = GetSlidingSegmentTimestampTicks();
        for (var offset = 1; offset <= _definition.Segments; offset++)
        {
            var index = (_slidingCurrentSegment + offset) % _definition.Segments;
            if (_slidingSegments[index] == 0)
                continue;
            return SaturatingAdd(
                _slidingSegmentStart,
                SaturatingMultiply(offset, segment));
        }
        return long.MaxValue;
    }

    private AdmissionRateWaiter? GrantWaitersLocked(long now)
    {
        AdvanceLocked(now);
        AdmissionRateWaiter? grantedHead = null;
        AdmissionRateWaiter? grantedTail = null;
        while (!_waiters.IsEmpty && CanGrantLocked())
        {
            var waiter = _waiters.Dequeue();
            RecordGrantLocked(now);
            if (grantedTail is null)
                grantedHead = waiter;
            else
                grantedTail.Next = waiter;
            grantedTail = waiter;
        }
        ScheduleTimerLocked(now);
        return grantedHead;
    }

    private void ScheduleTimerLocked(long now)
    {
        if (_disposed != 0 || _waiters.IsEmpty)
        {
            _timer?.Change(Timeout.InfiniteTimeSpan, Timeout.InfiniteTimeSpan);
            return;
        }

        AdvanceLocked(now);
        if (CanGrantLocked())
            return;

        var next = GetNextAvailabilityTimestampLocked(now);
        if (next == long.MaxValue)
            return;
        var due = TimestampDeltaToTimeSpan(Math.Max(1, next - now));
        _timer ??= _timeProvider.CreateTimer(
            static state => ((AdmissionDynamicRateState)state!).OnTimer(),
            this,
            Timeout.InfiniteTimeSpan,
            Timeout.InfiniteTimeSpan);
        _timer.Change(due, Timeout.InfiniteTimeSpan);
    }

    private void OnTimer()
    {
        AdmissionRateWaiter? granted;
        lock (Lineage.Gate)
        {
            if (_disposed != 0)
                return;
            granted = GrantWaitersLocked(_timeProvider.GetTimestamp());
        }
        AdmissionRateWaitQueue.CompleteGranted(granted);
    }

    void IAdmissionRateWaiterOwner.CancelRateWaiter(AdmissionRateWaiter waiter) => CancelWaiter(waiter);

    private void CancelWaiter(AdmissionRateWaiter waiter)
    {
        var removed = false;
        lock (Lineage.Gate)
        {
            removed = _waiters.Remove(waiter);
            if (removed)
                ScheduleTimerLocked(_timeProvider.GetTimestamp());
        }
        if (removed)
            waiter.CompleteCanceled();
    }

    public void Dispose()
    {
        AdmissionRateWaiter? failed;
        ITimer? timer;
        lock (Lineage.Gate)
        {
            if (_disposed != 0)
                return;
            _disposed = 1;
            failed = _waiters.DetachAll();
            timer = _timer;
            _timer = null;
            Lineage.DetachIfCurrentLocked(this);
        }
        timer?.Dispose();
        AdmissionRateWaitQueue.CompleteFailed(failed);
    }

    private long GetBarrierHorizonTimestampTicks(long burden)
    {
        if (burden <= 0)
            return 0;

        return _definition.Kind switch
        {
            AdmissionRateStateKind.TokenBucket => SaturatingMultiply(
                DivideRoundUp(burden, _definition.Secondary),
                GetPeriodTimestampTicks()),
            AdmissionRateStateKind.SlidingWindow => GetWindowTimestampTicks(),
            _ => long.MaxValue
        };
    }

    private long GetPeriodTimestampTicks()
        => ToTimestampTicks(_definition.PeriodTicks);

    private long GetWindowTimestampTicks()
        => ToTimestampTicks(_definition.PeriodTicks);

    private long GetSlidingSegmentTimestampTicks()
        => Math.Max(1, DivideRoundUp(GetWindowTimestampTicks(), _definition.Segments));

    private long ToTimestampTicks(long timeSpanTicks)
    {
        var scaled = (decimal)timeSpanTicks * _timeProvider.TimestampFrequency /
                     TimeSpan.TicksPerSecond;
        if (scaled >= long.MaxValue)
            return long.MaxValue;
        return Math.Max(1, (long)Math.Ceiling(scaled));
    }

    private TimeSpan TimestampDeltaToTimeSpan(long timestampTicks)
    {
        var scaled = (decimal)timestampTicks * TimeSpan.TicksPerSecond /
                     _timeProvider.TimestampFrequency;
        if (scaled >= TimeSpan.MaxValue.Ticks)
            return TimeSpan.MaxValue;
        return TimeSpan.FromTicks(Math.Max(1, (long)Math.Ceiling(scaled)));
    }

    private static long DivideRoundUp(long value, long divisor)
        => value <= 0 ? 0 : (value - 1) / divisor + 1;

    private static long SaturatingAdd(long left, long right)
    {
        if (right <= 0)
            return left;
        return left > long.MaxValue - right ? long.MaxValue : left + right;
    }

    private static long SaturatingMultiply(long left, long right)
    {
        if (left <= 0 || right <= 0)
            return 0;
        return left > long.MaxValue / right ? long.MaxValue : left * right;
    }

    private static void ValidatePermitCount(int permitCount)
    {
        if (permitCount != 1)
        {
            throw new ArgumentOutOfRangeException(
                nameof(permitCount),
                "Admission rate limiters acquire exactly one permit.");
        }
    }

}
