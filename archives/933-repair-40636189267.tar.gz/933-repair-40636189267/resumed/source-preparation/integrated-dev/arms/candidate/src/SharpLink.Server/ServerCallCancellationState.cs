namespace SharpLink.Server;

internal enum ServerCallCancellationReason : byte
{
    None,
    RemoteCancel,
    ConsumerAbandoned,
    DeadlineExceeded,
    ModuleDraining,
    ServerStopping,
    ConnectionClosed,
    AdmissionResourceExhausted,
    PreAdmissionStreamResourceExhausted,
    Completed
}

/// <summary>
/// An immutable lookup/snapshot lease that binds a pooled call state to one request generation.
/// </summary>
internal readonly struct ServerCallCancellationLease
{
    private readonly ServerCallCancellationState? _state;

    internal ServerCallCancellationLease(
        ServerCallCancellationState state,
        long requestId,
        long generation)
    {
        _state = state ?? throw new ArgumentNullException(nameof(state));
        RequestId = requestId;
        Generation = generation;
    }

    internal long RequestId { get; }

    internal long Generation { get; }

    internal ServerCallCancellationState State
        => _state ?? throw new InvalidOperationException("The server call cancellation lease is empty.");

    internal bool TryAcquire()
        => _state?.TryAcquire(RequestId, Generation) == true;

    internal void ReleaseUse() => State.ReleaseUse();
}

/// <summary>
/// Owns cancellation, deadline timing and terminal-response eligibility for one server invocation.
/// The first terminal source wins and all later sources become no-ops.
/// </summary>
internal sealed class ServerCallCancellationState : IDisposable
{
    private const int MaxRetained = 4096;
    private static readonly ConcurrentStack<ServerCallCancellationState> Pool = new();
    private static Action<ServerCallCancellationState>? s_beforeRequestActivationForTests;
    private static int s_retainedCount;

    private readonly Lock _lifetimeGate = new();
    private readonly Lock _terminalGate = new();
    private CancellationTokenSource? _invocationCancellation;
    private CancellationTokenRegistration _serverStoppingRegistration;
    private CancellationTokenRegistration _connectionClosedRegistration;
    private CancellationTokenRegistration _moduleDrainingRegistration;
    private int _reason;
    private int _abandonedRecorded;
    private int _moduleDrainResponseClaimed;
    private bool _disposeRequested;
    private int _externalUsers;
    private long _leaseGeneration;
    private AdmissionProgram? _admissionProgramUse;
    private AdmissionLease? _admissionLease;
    private SharpLinkBufferWriterPool? _payloadPool;
    private IRpcByteBufferWriter? _payloadOwner;
    private ServerDecodedBytesPermit? _decodedBytesPermit;
    private TimeProvider? _timeProvider;

    private ServerCallCancellationState()
    {
    }

    public long RequestId { get; private set; }

    public RpcDeadline Deadline { get; private set; }

    public CancellationToken InvocationToken
        => _invocationCancellation?.Token ?? CancellationToken.None;

    public ServerCallCancellationReason Reason
        => (ServerCallCancellationReason)Volatile.Read(ref _reason);

    public bool IsAbandoned => Reason is not (ServerCallCancellationReason.None or ServerCallCancellationReason.Completed);

    internal bool HasPayloadOwnerForDiagnostics => Volatile.Read(ref _payloadOwner) is not null;

    internal static Action<ServerCallCancellationState>? BeforeRequestActivationForTests
    {
        get => Volatile.Read(ref s_beforeRequestActivationForTests);
        set => Volatile.Write(ref s_beforeRequestActivationForTests, value);
    }

    public static ServerCallCancellationState Rent(
        long requestId,
        RpcDeadline deadline,
        TimeProvider timeProvider,
        CancellationToken connectionClosedToken,
        CancellationToken serverStoppingToken,
        bool supportsCooperativeCancellation)
        => Rent(
            requestId,
            deadline,
            timeProvider,
            connectionClosedToken,
            serverStoppingToken,
            CancellationToken.None,
            supportsCooperativeCancellation);

    public static ServerCallCancellationState Rent(
        long requestId,
        RpcDeadline deadline,
        TimeProvider timeProvider,
        CancellationToken connectionClosedToken,
        CancellationToken serverStoppingToken,
        CancellationToken moduleDrainingToken,
        bool supportsCooperativeCancellation)
    {
        if (!Pool.TryPop(out var state))
            state = new ServerCallCancellationState();
        else
            Interlocked.Decrement(ref s_retainedCount);

        _ = Interlocked.Increment(ref state._leaseGeneration);
        state.RequestId = requestId;
        state.Deadline = deadline;
        state._timeProvider = timeProvider ?? throw new ArgumentNullException(nameof(timeProvider));
        state._reason = (int)ServerCallCancellationReason.None;
        state._abandonedRecorded = 0;
        state._moduleDrainResponseClaimed = 0;
        state._admissionProgramUse = null;
        state._admissionLease = null;
        state._payloadPool = null;
        state._payloadOwner = null;
        state._decodedBytesPermit = null;
        state._disposeRequested = false;
        state._externalUsers = 0;
        state._serverStoppingRegistration = default;
        state._connectionClosedRegistration = default;
        state._moduleDrainingRegistration = default;
        state._invocationCancellation = supportsCooperativeCancellation
            ? new CancellationTokenSource()
            : null;
        if (moduleDrainingToken.CanBeCanceled)
        {
            state._moduleDrainingRegistration = moduleDrainingToken.UnsafeRegister(
                static callbackState =>
                    ((ServerCallCancellationState)callbackState!).InvokeCancellation(
                        ServerCallCancellationReason.ModuleDraining),
                state);
        }
        // Register server shutdown before connection closure so forced server shutdown has a
        // deterministic reason when both tokens have already been canceled.
        if (serverStoppingToken.CanBeCanceled)
        {
            state._serverStoppingRegistration = serverStoppingToken.UnsafeRegister(
                static callbackState =>
                    ((ServerCallCancellationState)callbackState!).InvokeCancellation(
                        ServerCallCancellationReason.ServerStopping),
                state);
        }
        if (connectionClosedToken.CanBeCanceled)
        {
            state._connectionClosedRegistration = connectionClosedToken.UnsafeRegister(
                static callbackState =>
                    ((ServerCallCancellationState)callbackState!).InvokeCancellation(
                        ServerCallCancellationReason.ConnectionClosed),
                state);
        }

        return state;
    }

    internal void AttachAdmissionProgramUse(AdmissionProgram admissionProgram)
    {
        ArgumentNullException.ThrowIfNull(admissionProgram);
        if (Interlocked.CompareExchange(ref _admissionProgramUse, admissionProgram, null) is not null)
            throw new InvalidOperationException("An admission program use is already attached to this call.");
    }

    internal void AttachAdmissionLease(AdmissionLease lease)
    {
        ArgumentNullException.ThrowIfNull(lease);
        if (Interlocked.CompareExchange(ref _admissionLease, lease, null) is not null)
            throw new InvalidOperationException("An admission lease is already attached to this call.");
    }

    internal void AttachPayloadOwner(
        SharpLinkBufferWriterPool pool,
        IRpcByteBufferWriter owner)
    {
        ArgumentNullException.ThrowIfNull(pool);
        ArgumentNullException.ThrowIfNull(owner);
        if (Interlocked.CompareExchange(ref _payloadOwner, owner, null) is not null)
            throw new InvalidOperationException("A retained payload owner is already attached to this call.");
        _payloadPool = pool;
    }

    internal void AttachDecodedBytesPermit(ServerDecodedBytesPermit decodedBytesPermit)
    {
        ArgumentNullException.ThrowIfNull(decodedBytesPermit);
        if (Volatile.Read(ref _payloadOwner) is null)
        {
            throw new InvalidOperationException(
                "Decoded-byte ownership cannot outlive a call without its physical decoded payload owner.");
        }
        if (Interlocked.CompareExchange(ref _decodedBytesPermit, decodedBytesPermit, null) is not null)
            throw new InvalidOperationException("Decoded-byte ownership is already attached to this call.");
    }

    internal ServerCallCancellationLease CaptureLease(long requestId)
        => new(this, requestId, Volatile.Read(ref _leaseGeneration));

    internal bool TryAcquire(long expectedRequestId, long expectedGeneration)
    {
        lock (_lifetimeGate)
        {
            if (_disposeRequested || RequestId != expectedRequestId ||
                _leaseGeneration != expectedGeneration)
                return false;
            _externalUsers++;
            return true;
        }
    }

    internal bool TryActivateRequest(ServerRequestPermit requestPermit)
    {
        ArgumentNullException.ThrowIfNull(requestPermit);
        Volatile.Read(ref s_beforeRequestActivationForTests)?.Invoke(this);
        lock (_terminalGate)
        {
            if (Reason != ServerCallCancellationReason.None)
                return false;
            requestPermit.Activate();
            return true;
        }
    }

    public void ReleaseUse()
    {
        var shouldDispose = false;
        lock (_lifetimeGate)
        {
            if (--_externalUsers < 0)
                throw new InvalidOperationException("Server call cancellation state use count underflowed.");
            shouldDispose = _disposeRequested && _externalUsers == 0;
        }
        if (shouldDispose)
            ReturnCore();
    }

    public bool TryCancel(ServerCallCancellationReason reason)
    {
        if (reason is ServerCallCancellationReason.None or ServerCallCancellationReason.Completed)
            throw new ArgumentOutOfRangeException(nameof(reason));

        return TryClaimTerminal(reason, signalCancellation: true, out _, out _);
    }

    public bool TryAcceptStreamData()
        => TryClaimStreamProgress(signalCancellation: true, out _);

    /// <summary>
    /// Claims the same stream-progress terminal boundary without invoking application cancellation
    /// callbacks on the caller thread. The caller must arrange <see cref="NotifyInvocationCancellation"/>
    /// when <paramref name="cancellationNotificationRequired"/> is true while retaining a lease.
    /// </summary>
    internal bool TryAcceptStreamDataDeferredCancellation(out bool cancellationNotificationRequired)
        => TryClaimStreamProgress(signalCancellation: false, out cancellationNotificationRequired);

    public bool TryClaimResponse()
        => TryClaimTerminal(
               ServerCallCancellationReason.Completed,
               signalCancellation: true,
               out var claimedReason,
               out _) &&
           claimedReason == ServerCallCancellationReason.Completed;

    internal void NotifyInvocationCancellation()
    {
        try
        {
            _invocationCancellation?.Cancel();
        }
        catch
        {
            // User cancellation callbacks are best-effort notification after terminal ownership
            // has already been decided. They cannot replace the selected RPC result.
        }
    }

    private bool TryClaimStreamProgress(
        bool signalCancellation,
        out bool cancellationNotificationRequired)
    {
        cancellationNotificationRequired = false;
        if (Reason != ServerCallCancellationReason.None)
            return false;

        var timeProvider = _timeProvider ?? throw new InvalidOperationException(
            "Server call state has no time provider.");
        if (Deadline.IsExpired(timeProvider))
        {
            _ = TryClaimTerminal(
                ServerCallCancellationReason.DeadlineExceeded,
                signalCancellation,
                out _,
                out cancellationNotificationRequired);
            return false;
        }

        return Reason == ServerCallCancellationReason.None;
    }

    private bool TryClaimTerminal(
        ServerCallCancellationReason proposedReason,
        bool signalCancellation,
        out ServerCallCancellationReason claimedReason,
        out bool cancellationNotificationRequired)
    {
        if (proposedReason == ServerCallCancellationReason.None)
            throw new ArgumentOutOfRangeException(nameof(proposedReason));

        var claimed = false;
        cancellationNotificationRequired = false;
        lock (_terminalGate)
        {
            var reason = proposedReason;
            var timeProvider = _timeProvider ?? throw new InvalidOperationException(
                "Server call state has no time provider.");
            if (reason != ServerCallCancellationReason.DeadlineExceeded && Deadline.IsExpired(timeProvider))
                reason = ServerCallCancellationReason.DeadlineExceeded;

            if (Interlocked.CompareExchange(ref _reason, (int)reason, (int)ServerCallCancellationReason.None) !=
                (int)ServerCallCancellationReason.None)
            {
                claimedReason = Reason;
                return false;
            }

            claimed = true;
            claimedReason = reason;
            if (reason != ServerCallCancellationReason.Completed)
                cancellationNotificationRequired = _invocationCancellation is not null;
        }

        if (claimedReason == ServerCallCancellationReason.Completed)
            return true;

        if (signalCancellation && cancellationNotificationRequired)
        {
            NotifyInvocationCancellation();
            cancellationNotificationRequired = false;
        }
        return claimed;
    }

    public bool TryRecordAbandoned()
        => IsAbandoned && Interlocked.Exchange(ref _abandonedRecorded, 1) == 0;

    public bool TryClaimModuleDrainResponse()
        => Reason == ServerCallCancellationReason.ModuleDraining &&
           Interlocked.Exchange(ref _moduleDrainResponseClaimed, 1) == 0;

    public void Dispose()
    {
        var shouldDispose = false;
        lock (_lifetimeGate)
        {
            if (_disposeRequested)
                return;
            _disposeRequested = true;
            shouldDispose = _externalUsers == 0;
        }
        if (shouldDispose)
            ReturnCore();
    }

    private void InvokeCancellation(ServerCallCancellationReason reason)
    {
        lock (_lifetimeGate)
        {
            if (_disposeRequested)
                return;
            _externalUsers++;
        }

        try
        {
            TryCancel(reason);
        }
        finally
        {
            ReleaseUse();
        }
    }

    private void ReturnCore()
    {
        _moduleDrainingRegistration.Dispose();
        _connectionClosedRegistration.Dispose();
        _serverStoppingRegistration.Dispose();
        _invocationCancellation?.Dispose();
        Interlocked.Exchange(ref _admissionLease, null)?.Dispose();
        Interlocked.Exchange(ref _admissionProgramUse, null)?.ReleaseUse();
        var payloadOwner = Interlocked.Exchange(ref _payloadOwner, null);
        var payloadPool = Interlocked.Exchange(ref _payloadPool, null);
        var decodedBytesPermit = Interlocked.Exchange(ref _decodedBytesPermit, null);
        if (payloadOwner is not null)
        {
            (payloadPool ?? throw new InvalidOperationException("A retained payload has no owning pool."))
                .Return(payloadOwner);
            decodedBytesPermit?.Dispose();
        }
        else if (decodedBytesPermit is not null)
        {
            // This should be unreachable because decoded-byte ownership is attached only after the
            // corresponding physical owner. Release conservatively rather than leak accounting if
            // an invariant violation reaches teardown.
            decodedBytesPermit.Dispose();
        }
        _invocationCancellation = null;
        _connectionClosedRegistration = default;
        _serverStoppingRegistration = default;
        _moduleDrainingRegistration = default;
        RequestId = 0;
        Deadline = default;
        _timeProvider = null;
        _reason = (int)ServerCallCancellationReason.None;
        _abandonedRecorded = 0;
        _moduleDrainResponseClaimed = 0;

        while (true)
        {
            var retained = Volatile.Read(ref s_retainedCount);
            if (retained >= MaxRetained)
                return;
            if (Interlocked.CompareExchange(ref s_retainedCount, retained + 1, retained) == retained)
                break;
        }
        Pool.Push(this);
    }
}
