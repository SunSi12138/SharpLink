namespace SharpLink.Server;

internal sealed partial class SharpLinkServer
{
    internal ServerCallAdmissionResult TryReserveCall(
        ServerConnectionState connection,
        out ServerRequestPermit? permit)
        => _callAdmission.TryReserveCall(connection, out permit);


    internal ServerCallAdmissionResult TryReserveCall(
        ServerConnectionState connection,
        bool mayDecode,
        out ServerRequestPermit? permit)
        => _callAdmission.TryReserveCall(connection, testHooks: null, mayDecode, out permit);

    internal ServerCallAdmissionResult TryReserveCall(
        ServerConnectionState connection,
        ServerRequestPermitTestHooks? testHooks,
        bool mayDecode,
        out ServerRequestPermit? permit)
        => _callAdmission.TryReserveCall(connection, testHooks, mayDecode, out permit);
}
