namespace SharpLink.Server;

/// <summary>
/// The sole construction input for <see cref="SharpLinkServer"/>. All values are materialized from
/// one immutable <see cref="ServerBuildPlan"/> and owned by the existing build transaction before
/// this composition reaches the runtime object.
/// </summary>
internal sealed class ServerRuntimeComposition
{
    private readonly ISharpLinkServerInterceptor[] _interceptors;
    private readonly IReadOnlyList<ISharpLinkGeneratedAssemblyManifest> _staticManifests;

    internal ServerRuntimeComposition(
        IServerTransportListener transportListener,
        FrozenDictionary<long, ServiceRegistration> services,
        TimeSpan heartbeatCheckInterval,
        TimeSpan heartbeatTimeout,
        ILogger logger,
        SharpLinkRuntimeContext runtimeContext,
        SharpLinkCompressionSendPolicy responseCompressionPolicy,
        ISharpLinkServerAuthenticator? authenticator,
        bool authenticationRequired,
        SharpLinkProtocolOptions protocolOptions,
        RpcSessionFlushOptions? rpcSessionFlushOptions,
        ISharpLinkServerInterceptor[] interceptors,
        IRpcExceptionMapper exceptionMapper,
        ServerServiceCleanup serviceCleanup,
        IServiceProvider serviceProvider,
        IReadOnlyList<ISharpLinkGeneratedAssemblyManifest> staticManifests,
        SharpLinkAdmissionController admissionController,
        ServerConnectionAdmission connectionAdmission,
        ServerShutdownPlan shutdownPlan,
        FrameworkTaskSupervisor frameworkTasks)
    {
        TransportListener = transportListener ?? throw new ArgumentNullException(nameof(transportListener));
        Services = services ?? throw new ArgumentNullException(nameof(services));
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(heartbeatCheckInterval, TimeSpan.Zero);
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(heartbeatTimeout, TimeSpan.Zero);
        if (heartbeatTimeout <= heartbeatCheckInterval)
            throw new ArgumentException("Heartbeat timeout must be greater than check interval.");
        Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        RuntimeContext = runtimeContext ?? throw new ArgumentNullException(nameof(runtimeContext));
        ResponseCompressionPolicy = responseCompressionPolicy ?? throw new ArgumentNullException(nameof(responseCompressionPolicy));
        _ = CompressionSendPolicySnapshot.CreateValidated(ResponseCompressionPolicy);
        ProtocolOptions = protocolOptions ?? throw new ArgumentNullException(nameof(protocolOptions));
        ArgumentNullException.ThrowIfNull(interceptors);
        ExceptionMapper = exceptionMapper ?? throw new ArgumentNullException(nameof(exceptionMapper));
        ServiceCleanup = serviceCleanup ?? throw new ArgumentNullException(nameof(serviceCleanup));
        ServiceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        ArgumentNullException.ThrowIfNull(staticManifests);
        ShutdownPlan = shutdownPlan ?? throw new ArgumentNullException(nameof(shutdownPlan));
        FrameworkTasks = frameworkTasks ?? throw new ArgumentNullException(nameof(frameworkTasks));
        AdmissionController = admissionController ?? throw new ArgumentNullException(nameof(admissionController));

        _interceptors = [.. interceptors];
        for (var index = 0; index < staticManifests.Count; index++)
            _ = staticManifests[index] ?? throw new ArgumentException("Static manifests cannot contain null.", nameof(staticManifests));
        _staticManifests = staticManifests;
        HeartbeatCheckInterval = heartbeatCheckInterval;
        HeartbeatTimeout = heartbeatTimeout;
        Authentication = new ServerAuthenticationCoordinator(
            authenticator,
            authenticationRequired,
            logger,
            runtimeContext.TimeProvider);
        RpcSessionFlushOptions = rpcSessionFlushOptions;
        AdmissionProgram = admissionController.IsEnabled ? new AdmissionProgram(admissionController) : null;
        ConnectionAdmission = connectionAdmission ?? throw new ArgumentNullException(nameof(connectionAdmission));
    }

    internal IServerTransportListener TransportListener { get; }

    internal FrozenDictionary<long, ServiceRegistration> Services { get; }

    internal TimeSpan HeartbeatCheckInterval { get; }

    internal TimeSpan HeartbeatTimeout { get; }

    internal ILogger Logger { get; }

    internal SharpLinkRuntimeContext RuntimeContext { get; }

    internal SharpLinkCompressionSendPolicy ResponseCompressionPolicy { get; }

    internal ServerAuthenticationCoordinator Authentication { get; }

    internal SharpLinkProtocolOptions ProtocolOptions { get; }

    internal RpcSessionFlushOptions? RpcSessionFlushOptions { get; }

    internal ISharpLinkServerInterceptor[] Interceptors => _interceptors;

    internal IRpcExceptionMapper ExceptionMapper { get; }

    internal ServerServiceCleanup ServiceCleanup { get; }

    internal IServiceProvider ServiceProvider { get; }

    internal IReadOnlyList<ISharpLinkGeneratedAssemblyManifest> StaticManifests => _staticManifests;

    internal AdmissionProgram? AdmissionProgram { get; }

    internal SharpLinkAdmissionController AdmissionController { get; }

    internal ServerConnectionAdmission ConnectionAdmission { get; }

    internal ServerShutdownPlan ShutdownPlan { get; }

    internal FrameworkTaskSupervisor FrameworkTasks { get; }
}
