namespace SharpLink.Client;

internal sealed partial class SharpLinkClient
{
    private ValueTask<TResponse> InvokeUnaryInterceptedAsync<TRequest, TResponse>(
        RpcMethodDescriptor method,
        TRequest request,
        IRpcCodec<TRequest> requestCodec,
        IRpcCodec<TResponse> responseCodec,
        ClientInterceptorGeneration interceptors,
        ResolvedCallControl control,
        CancellationToken cancellationToken)
        => new UnaryInterceptorState<TRequest, TResponse>(
            this, method, request, requestCodec, responseCodec, interceptors, control, cancellationToken).InvokeTypedAsync();

    private ValueTask InvokeOneWayInterceptedAsync<TRequest, TStreams>(
        RpcMethodDescriptor method,
        TRequest request,
        IRpcCodec<TRequest> requestCodec,
        TStreams streams,
        ClientInterceptorGeneration interceptors,
        ResolvedCallControl control,
        CancellationToken cancellationToken)
        where TStreams : struct, IRpcClientStreamWriter
        => new OneWayInterceptorState<TRequest, TStreams>(
            this, method, request, requestCodec, streams, interceptors, control, cancellationToken).InvokeVoidAsync();

    private ValueTask<TResponse> InvokeClientStreamingInterceptedAsync<TRequest, TResponse, TStreams>(
        RpcMethodDescriptor method,
        TRequest request,
        IRpcCodec<TRequest> requestCodec,
        IRpcCodec<TResponse> responseCodec,
        TStreams streams,
        ClientInterceptorGeneration interceptors,
        ResolvedCallControl control,
        CancellationToken cancellationToken)
        where TStreams : struct, IRpcClientStreamWriter
        => new ClientStreamingInterceptorState<TRequest, TResponse, TStreams>(
            this, method, request, requestCodec, responseCodec, streams, interceptors, control, cancellationToken).InvokeTypedAsync();

    private IAsyncEnumerable<TResponse> InvokeServerStreamingIntercepted<TRequest, TResponse>(
        RpcMethodDescriptor method,
        TRequest request,
        IRpcCodec<TRequest> requestCodec,
        IRpcCodec<TResponse> responseCodec,
        ClientInterceptorGeneration interceptors,
        ResolvedCallControl control,
        CancellationToken cancellationToken)
    {
        var state = new ServerStreamingInterceptorState<TRequest, TResponse>(
            this, method, request, requestCodec, responseCodec, interceptors, control, cancellationToken);
        return new InterceptedAsyncEnumerable<TResponse>(
            state.InvokeAsync(), method.ResponseNullable, state.Deadline,
            _runtimeContext.TimeProvider, state.LogicalCall, state.InvocationCancellation);
    }

    private IAsyncEnumerable<TResponse> InvokeDuplexStreamingIntercepted<TRequest, TResponse, TStreams>(
        RpcMethodDescriptor method,
        TRequest request,
        IRpcCodec<TRequest> requestCodec,
        IRpcCodec<TResponse> responseCodec,
        TStreams streams,
        ClientInterceptorGeneration interceptors,
        ResolvedCallControl control,
        CancellationToken cancellationToken)
        where TStreams : struct, IRpcClientStreamWriter
    {
        var state = new DuplexStreamingInterceptorState<TRequest, TResponse, TStreams>(
            this, method, request, requestCodec, responseCodec, streams, interceptors, control, cancellationToken);
        return new InterceptedAsyncEnumerable<TResponse>(
            state.InvokeAsync(), method.ResponseNullable, state.Deadline,
            _runtimeContext.TimeProvider, state.LogicalCall, state.InvocationCancellation);
    }

    private abstract class ClientInterceptorState
    {
        private readonly SharpLinkClient _client;
        private readonly ClientInterceptorGeneration _interceptors;
        private readonly SharpLinkClientInvocationContext _context;
        private readonly ResolvedCallControl _control;
        private long _started;

        protected ClientInterceptorState(
            SharpLinkClient client,
            RpcMethodDescriptor method,
            object? request,
            ClientInterceptorGeneration interceptors,
            ResolvedCallControl control,
            CancellationToken cancellationToken)
        {
            _client = client;
            _interceptors = interceptors;
            _control = control;
            _context = new SharpLinkClientInvocationContext(
                method, request, _control.Metadata, cancellationToken);
            _context.InterceptorPipelineState = this;
        }

        protected SharpLinkClient Client => _client;
        protected SharpLinkClientInvocationContext Context => _context;
        internal RpcDeadline Deadline => _control.Deadline;
        internal ClientLogicalCallState? LogicalCall => _control.LogicalCall;
        internal CancellationToken InvocationCancellation => _context.CancellationToken;

        public ValueTask<SharpLinkClientInvocationResult> InvokeAsync()
            => RunChainAsync();

        private async ValueTask<SharpLinkClientInvocationResult> RunChainAsync()
        {
            _started = _client._runtimeContext.TimeProvider.GetTimestamp();
            try
            {
                var result = await AwaitInvocationWithinFrozenDeadlineAsync(
                    _interceptors.Entry(_context)).ConfigureAwait(false);
                ValidateResult(result);
                MarkChainSucceeded(_context);
                return result;
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(_context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(_context);
            }
        }

        protected async ValueTask<TResult> RunTypedChainAsync<TResult>()
        {
            _started = _client._runtimeContext.TimeProvider.GetTimestamp();
            try
            {
                var result = await AwaitInvocationWithinFrozenDeadlineAsync(
                    _interceptors.Entry(_context)).ConfigureAwait(false);
                ValidateResult(result);
                MarkChainSucceeded(_context);
                return result.GetValue<TResult>();
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(_context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(_context);
            }
        }

        protected void MarkChainSucceeded(SharpLinkClientInvocationContext context)
        {
            if (context.Status == SharpLinkInvocationStatus.Pending)
                context.Status = SharpLinkInvocationStatus.Succeeded;
        }

        protected async ValueTask RunVoidChainAsync()
        {
            _started = _client._runtimeContext.TimeProvider.GetTimestamp();
            try
            {
                var result = await AwaitInvocationWithinFrozenDeadlineAsync(
                    _interceptors.Entry(_context)).ConfigureAwait(false);
                ValidateResult(result);
                MarkChainSucceeded(_context);
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(_context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(_context);
            }
        }

        private async ValueTask<SharpLinkClientInvocationResult> AwaitInvocationWithinFrozenDeadlineAsync(
            ValueTask<SharpLinkClientInvocationResult> invocation)
        {
            if (!_control.Deadline.HasValue)
                return await invocation.ConfigureAwait(false);
            if (invocation.IsCompletedSuccessfully)
            {
                var result = invocation.Result;
                ThrowIfFrozenDeadlineExpired();
                return result;
            }

            var invocationTask = invocation.AsTask();
            if (!await SharpLinkTimer.WaitAsync(
                    invocationTask,
                    _control.Deadline,
                    _client._runtimeContext.TimeProvider,
                    CancellationToken.None).ConfigureAwait(false))
            {
                _control.LogicalCall?.TryClaimDeadline();
                var failure = CreateDeadlineExceededException();
                SharpLinkPhysicalWork.TrackAbandonedUserWork(failure, invocationTask);
                throw failure;
            }
            return await invocationTask.ConfigureAwait(false);
        }

        internal ValueTask<SharpLinkClientInvocationResult> InvokeComposedInterceptorAsync(
            ISharpLinkClientInterceptor interceptor,
            SharpLinkClientInvocationDelegate next,
            SharpLinkClientInvocationContext context)
        {
            if (_control.LogicalCall is { } logicalCall &&
                !logicalCall.TryEnterProgress(_control.Deadline, _client._runtimeContext.TimeProvider))
            {
                return ValueTask.FromException<SharpLinkClientInvocationResult>(
                    CreateDeadlineExceededException());
            }

            try
            {
                return interceptor.InvokeAsync(context, next);
            }
            catch (Exception exception)
            {
                return ValueTask.FromException<SharpLinkClientInvocationResult>(exception);
            }
        }

        internal ValueTask<SharpLinkClientInvocationResult> InvokeComposedTerminalAsync(
            SharpLinkClientInvocationContext context)
        {
            if (_control.LogicalCall is { } logicalCall &&
                !logicalCall.TryEnterProgress(_control.Deadline, _client._runtimeContext.TimeProvider))
            {
                return ValueTask.FromException<SharpLinkClientInvocationResult>(
                    CreateDeadlineExceededException());
            }

            return InvokeTerminalTrackedAsync(context);
        }

        private ValueTask<SharpLinkClientInvocationResult> InvokeTerminalTrackedAsync(
            SharpLinkClientInvocationContext context)
            => InvokeTerminalAsync(context);

        protected ResolvedCallControl GetTerminalControl(SharpLinkClientInvocationContext context)
            // The terminal boundary only replaces the metadata observed by the pipeline. Every
            // other captured field (lifetime source, telemetry detail, retry generation, time
            // provider, shared logical call) must stay exactly as the invocation captured it, so
            // this copies the control instead of rebuilding it field by field.
            => _control with
            {
                Metadata = context.Metadata is { Count: > 0 } ? context.Metadata : null
            };

        private void ThrowIfFrozenDeadlineExpired()
        {
            if (_control.LogicalCall is { } logicalCall)
            {
                if (!logicalCall.TryEnterProgress(_control.Deadline, _client._runtimeContext.TimeProvider))
                    throw CreateDeadlineExceededException();
                return;
            }
            if (_control.Deadline.IsExpired(_client._runtimeContext.TimeProvider))
                throw CreateDeadlineExceededException();
        }

        protected void MarkTerminalSucceeded(SharpLinkClientInvocationContext context)
            => context.Status = SharpLinkInvocationStatus.Succeeded;

        protected void MarkTerminalFailed(SharpLinkClientInvocationContext context, Exception exception)
        {
            if (IsCancellationException(exception))
            {
                context.Status = SharpLinkInvocationStatus.Cancelled;
                context.ErrorCode = SharpLinkErrorCode.Cancelled;
            }
            else
            {
                context.Status = SharpLinkInvocationStatus.Failed;
                context.ErrorCode = exception is SharpLinkException sharpLinkException
                    ? sharpLinkException.Code
                    : SharpLinkErrorCode.Internal;
            }
            context.Exception = exception;
        }

        protected void MarkTerminalElapsed(SharpLinkClientInvocationContext context)
            => context.Elapsed = _client._runtimeContext.TimeProvider.GetElapsedTime(_started);

        protected abstract ValueTask<SharpLinkClientInvocationResult> InvokeTerminalAsync(
            SharpLinkClientInvocationContext context);

        protected abstract void ValidateResult(SharpLinkClientInvocationResult result);

        private static bool IsCancellationException(Exception exception)
            => exception is OperationCanceledException or
               SharpLinkException { Code: SharpLinkErrorCode.Cancelled };
    }

    private sealed class UnaryInterceptorState<TRequest, TResponse> : ClientInterceptorState
    {
        private readonly RpcMethodDescriptor _method;
        private readonly TRequest _request;
        private readonly IRpcCodec<TRequest> _requestCodec;
        private readonly IRpcCodec<TResponse> _responseCodec;

        public UnaryInterceptorState(
            SharpLinkClient client,
            RpcMethodDescriptor method,
            TRequest request,
            IRpcCodec<TRequest> requestCodec,
            IRpcCodec<TResponse> responseCodec,
            ClientInterceptorGeneration interceptors,
            ResolvedCallControl control,
            CancellationToken cancellationToken)
            : base(client, method, request, interceptors, control, cancellationToken)
        {
            _method = method;
            _request = request;
            _requestCodec = requestCodec;
            _responseCodec = responseCodec;
        }

        public ValueTask<TResponse> InvokeTypedAsync()
            => RunTypedChainAsync<TResponse>();

        protected override void ValidateResult(SharpLinkClientInvocationResult result)
        {
            var value = result.GetValue<TResponse>();
            if (!Context.Method.ResponseNullable && default(TResponse) is null && value is null)
                throw new InvalidCastException("A non-nullable intercepted RPC response was null.");
        }

        protected override async ValueTask<SharpLinkClientInvocationResult> InvokeTerminalAsync(
            SharpLinkClientInvocationContext context)
        {
            try
            {
                var control = GetTerminalControl(context);
                var response = await Client.InvokeUnaryWithOptionalRetryAsync(
                    _method, _request, _requestCodec, _responseCodec, control, context.CancellationToken).ConfigureAwait(false);
                MarkTerminalSucceeded(context);
                return new SharpLinkClientInvocationResult(response);
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(context);
            }
        }
    }

    private sealed class OneWayInterceptorState<TRequest, TStreams> : ClientInterceptorState
        where TStreams : struct, IRpcClientStreamWriter
    {
        private readonly RpcMethodDescriptor _method;
        private readonly TRequest _request;
        private readonly IRpcCodec<TRequest> _requestCodec;
        private readonly TStreams _streams;

        public OneWayInterceptorState(
            SharpLinkClient client,
            RpcMethodDescriptor method,
            TRequest request,
            IRpcCodec<TRequest> requestCodec,
            TStreams streams,
            ClientInterceptorGeneration interceptors,
            ResolvedCallControl control,
            CancellationToken cancellationToken)
            : base(client, method, request, interceptors, control, cancellationToken)
        {
            _method = method;
            _request = request;
            _requestCodec = requestCodec;
            _streams = streams;
        }

        public ValueTask InvokeVoidAsync()
            => RunVoidChainAsync();

        protected override void ValidateResult(SharpLinkClientInvocationResult result)
        {
            if (result.Value is not null)
                throw new InvalidCastException("An intercepted OneWay result must be null.");
        }

        protected override async ValueTask<SharpLinkClientInvocationResult> InvokeTerminalAsync(
            SharpLinkClientInvocationContext context)
        {
            try
            {
                var control = GetTerminalControl(context);
                await Client.InvokeOneWayCoreAsync(
                    _method,
                    _request, _requestCodec, _streams, control, context.CancellationToken).ConfigureAwait(false);
                MarkTerminalSucceeded(context);
                return default;
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(context);
            }
        }
    }

    private sealed class ClientStreamingInterceptorState<TRequest, TResponse, TStreams> : ClientInterceptorState
        where TStreams : struct, IRpcClientStreamWriter
    {
        private readonly RpcMethodDescriptor _method;
        private readonly TRequest _request;
        private readonly IRpcCodec<TRequest> _requestCodec;
        private readonly IRpcCodec<TResponse> _responseCodec;
        private readonly TStreams _streams;

        public ClientStreamingInterceptorState(
            SharpLinkClient client,
            RpcMethodDescriptor method,
            TRequest request,
            IRpcCodec<TRequest> requestCodec,
            IRpcCodec<TResponse> responseCodec,
            TStreams streams,
            ClientInterceptorGeneration interceptors,
            ResolvedCallControl control,
            CancellationToken cancellationToken)
            : base(client, method, request, interceptors, control, cancellationToken)
        {
            _method = method;
            _request = request;
            _requestCodec = requestCodec;
            _responseCodec = responseCodec;
            _streams = streams;
        }

        public ValueTask<TResponse> InvokeTypedAsync()
            => RunTypedChainAsync<TResponse>();

        protected override void ValidateResult(SharpLinkClientInvocationResult result)
        {
            var value = result.GetValue<TResponse>();
            if (!Context.Method.ResponseNullable && default(TResponse) is null && value is null)
                throw new InvalidCastException("A non-nullable intercepted RPC response was null.");
        }

        protected override async ValueTask<SharpLinkClientInvocationResult> InvokeTerminalAsync(
            SharpLinkClientInvocationContext context)
        {
            try
            {
                var control = GetTerminalControl(context);
                var response = await Client.InvokeClientStreamingCoreAsync(
                    _method,
                    _request, _requestCodec, _responseCodec, _streams, control,
                    context.CancellationToken).ConfigureAwait(false);
                MarkTerminalSucceeded(context);
                return new SharpLinkClientInvocationResult(response);
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(context);
            }
        }
    }

    private sealed class ServerStreamingInterceptorState<TRequest, TResponse> : ClientInterceptorState
    {
        private readonly RpcMethodDescriptor _method;
        private readonly TRequest _request;
        private readonly IRpcCodec<TRequest> _requestCodec;
        private readonly IRpcCodec<TResponse> _responseCodec;

        public ServerStreamingInterceptorState(
            SharpLinkClient client,
            RpcMethodDescriptor method,
            TRequest request,
            IRpcCodec<TRequest> requestCodec,
            IRpcCodec<TResponse> responseCodec,
            ClientInterceptorGeneration interceptors,
            ResolvedCallControl control,
            CancellationToken cancellationToken)
            : base(client, method, request, interceptors, control, cancellationToken)
        {
            _method = method;
            _request = request;
            _requestCodec = requestCodec;
            _responseCodec = responseCodec;
        }

        protected override ValueTask<SharpLinkClientInvocationResult> InvokeTerminalAsync(
            SharpLinkClientInvocationContext context)
        {
            try
            {
                var stream = Client.InvokeServerStreamingCore(
                    _method, _request, _requestCodec, _responseCodec,
                    GetTerminalControl(context), context.CancellationToken);
                MarkTerminalSucceeded(context);
                return ValueTask.FromResult(new SharpLinkClientInvocationResult(stream));
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(context);
            }
        }

        protected override void ValidateResult(SharpLinkClientInvocationResult result)
        {
            if (result.Value is not IAsyncEnumerable<TResponse>)
                throw new InvalidCastException($"The intercepted result is not {typeof(IAsyncEnumerable<TResponse>).FullName}.");
        }
    }

    private sealed class DuplexStreamingInterceptorState<TRequest, TResponse, TStreams> : ClientInterceptorState
        where TStreams : struct, IRpcClientStreamWriter
    {
        private readonly RpcMethodDescriptor _method;
        private readonly TRequest _request;
        private readonly IRpcCodec<TRequest> _requestCodec;
        private readonly IRpcCodec<TResponse> _responseCodec;
        private readonly TStreams _streams;

        public DuplexStreamingInterceptorState(
            SharpLinkClient client,
            RpcMethodDescriptor method,
            TRequest request,
            IRpcCodec<TRequest> requestCodec,
            IRpcCodec<TResponse> responseCodec,
            TStreams streams,
            ClientInterceptorGeneration interceptors,
            ResolvedCallControl control,
            CancellationToken cancellationToken)
            : base(client, method, request, interceptors, control, cancellationToken)
        {
            _method = method;
            _request = request;
            _requestCodec = requestCodec;
            _responseCodec = responseCodec;
            _streams = streams;
        }

        protected override ValueTask<SharpLinkClientInvocationResult> InvokeTerminalAsync(
            SharpLinkClientInvocationContext context)
        {
            try
            {
                var stream = Client.InvokeDuplexStreamingCore(
                    _method, _request, _requestCodec, _responseCodec, _streams,
                    GetTerminalControl(context), context.CancellationToken);
                MarkTerminalSucceeded(context);
                return ValueTask.FromResult(new SharpLinkClientInvocationResult(stream));
            }
            catch (Exception exception)
            {
                MarkTerminalFailed(context, exception);
                throw;
            }
            finally
            {
                MarkTerminalElapsed(context);
            }
        }

        protected override void ValidateResult(SharpLinkClientInvocationResult result)
        {
            if (result.Value is not IAsyncEnumerable<TResponse>)
                throw new InvalidCastException($"The intercepted result is not {typeof(IAsyncEnumerable<TResponse>).FullName}.");
        }
    }

    private sealed class InterceptedAsyncEnumerable<T>(
        ValueTask<SharpLinkClientInvocationResult> invocation,
        bool responseNullable,
        RpcDeadline deadline,
        TimeProvider timeProvider,
        ClientLogicalCallState? logicalCall,
        CancellationToken invocationCancellation) : IAsyncEnumerable<T>
    {
        private int _enumerated;

        public async IAsyncEnumerator<T> GetAsyncEnumerator(
            CancellationToken cancellationToken = default)
        {
            if (Interlocked.Exchange(ref _enumerated, 1) != 0)
                throw new InvalidOperationException("An intercepted RPC stream can only be enumerated once.");

            // InvokeAsync already owns the frozen-deadline wait. A second waiter can abandon that
            // wrapper rather than the underlying user task and obscures the physical parent.
            var invocationResult = await invocation.ConfigureAwait(false);
            ThrowIfDeadlineExpired();
            var stream = invocationResult.GetValue<IAsyncEnumerable<T>>();
            var lifetimeCancellation = CancellationTokenSource.CreateLinkedTokenSource(
                invocationCancellation, cancellationToken);
            IAsyncEnumerator<T> enumerator;
            try
            {
                enumerator = stream.GetAsyncEnumerator(lifetimeCancellation.Token);
            }
            catch (Exception exception)
            {
                if (SharpLinkPhysicalWork.TransferLifetime(exception, lifetimeCancellation) is { } terminal)
                    throw terminal;
                lifetimeCancellation.Dispose();
                throw;
            }
            var ownershipTransferred = false;
            try
            {
                while (true)
                {
                    bool hasNext;
                    T item;
                    try
                    {
                        ThrowIfDeadlineExpired();
                        var moveNext = enumerator.MoveNextAsync();
                        if (!deadline.HasValue)
                        {
                            hasNext = await moveNext.ConfigureAwait(false);
                        }
                        else if (moveNext.IsCompletedSuccessfully)
                        {
                            hasNext = moveNext.Result;
                            ThrowIfDeadlineExpired();
                        }
                        else
                        {
                            var moveNextTask = moveNext.AsTask();
                            bool completed;
                            try
                            {
                                completed = await SharpLinkTimer.WaitAsync(
                                    moveNextTask, deadline, timeProvider,
                                    lifetimeCancellation.Token).ConfigureAwait(false);
                            }
                            catch (OperationCanceledException exception) when (lifetimeCancellation.IsCancellationRequested)
                            {
                                ownershipTransferred = true;
                                var failure = SharpLinkPhysicalWork.CreateCancellationTerminal(exception);
                                var physical = SharpLinkPhysicalWork.CreateCarrierOwner(failure, exception, lifetimeCancellation);
                                physical.Track(CompleteAbandonedStreamAsync(moveNextTask, enumerator, lifetimeCancellation, physical));
                                throw failure;
                            }
                            if (!completed)
                            {
                                logicalCall?.TryClaimDeadline();
                                ownershipTransferred = true;
                                var failure = CreateDeadlineExceededException();
                                var physical = SharpLinkPhysicalWork.CreateOwner(failure, lifetimeCancellation);
                                physical.Track(CompleteAbandonedStreamAsync(moveNextTask, enumerator, lifetimeCancellation, physical));
                                throw failure;
                            }
                            hasNext = await moveNextTask.ConfigureAwait(false);
                        }
                        item = hasNext ? enumerator.Current : default!;
                        if (hasNext && !responseNullable && default(T) is null && item is null)
                            throw new InvalidCastException("A non-nullable intercepted RPC stream response was null.");
                    }
                    catch (OperationCanceledException exception) when (!ownershipTransferred &&
                        (lifetimeCancellation.IsCancellationRequested || SharpLinkPhysicalWork.GetAbandonedUserWork(exception) is not null))
                    {
                        ownershipTransferred = true;
                        var failure = SharpLinkPhysicalWork.CreateCancellationTerminal(exception);
                        var physical = SharpLinkPhysicalWork.CreateCarrierOwner(failure, exception, lifetimeCancellation);
                        physical.Track(CompleteAbandonedStreamAsync(
                            Task.FromException(exception), enumerator, lifetimeCancellation, physical));
                        throw failure;
                    }
                    catch (SharpLinkException exception) when (
                        !ownershipTransferred && exception.Code == SharpLinkErrorCode.DeadlineExceeded &&
                        (deadline.IsExpired(timeProvider) || SharpLinkPhysicalWork.GetAbandonedUserWork(exception) is not null))
                    {
                        ownershipTransferred = true;
                        var failure = new SharpLinkException(exception.Code, exception.DetailCode, exception.Message, exception);
                        var physical = SharpLinkPhysicalWork.CreateCarrierOwner(failure, exception, lifetimeCancellation);
                        physical.Track(CompleteAbandonedStreamAsync(
                            Task.FromException(exception), enumerator, lifetimeCancellation, physical));
                        throw failure;
                    }

                    if (!hasNext)
                        yield break;
                    yield return item;
                }
            }
            finally
            {
                if (!ownershipTransferred)
                {
                    try
                    {
                        TryCancelLifetime(lifetimeCancellation);
                        await enumerator.DisposeAsync().ConfigureAwait(false);
                    }
                    catch (Exception exception)
                    {
                        if (SharpLinkPhysicalWork.TransferLifetime(exception, lifetimeCancellation) is { } terminal)
                            throw terminal;
                        lifetimeCancellation.Dispose();
                        throw;
                    }
                    lifetimeCancellation.Dispose();
                }
            }
        }

        private static async Task CompleteAbandonedStreamAsync(
            Task pendingMove,
            IAsyncEnumerator<T> enumerator,
            CancellationTokenSource lifetimeCancellation,
            SharpLinkPhysicalWork.PhysicalOwner physical)
        {
            await Task.CompletedTask.ConfigureAwait(ConfigureAwaitOptions.ForceYielding);
            TryCancelLifetime(lifetimeCancellation);
            try { await pendingMove.ConfigureAwait(false); }
            catch (Exception exception) { await physical.WaitForDescendantAsync(exception).ConfigureAwait(false); }
            try { await enumerator.DisposeAsync().ConfigureAwait(false); }
            catch (Exception exception) { await physical.WaitForDescendantAsync(exception).ConfigureAwait(false); }
        }

        private void ThrowIfDeadlineExpired()
        {
            if (logicalCall is not null)
            {
                if (!logicalCall.TryEnterProgress(deadline, timeProvider))
                    throw CreateDeadlineExceededException();
                return;
            }
            if (deadline.IsExpired(timeProvider))
                throw CreateDeadlineExceededException();
        }

        private static void TryCancelLifetime(CancellationTokenSource cancellation)
        {
            try { cancellation.Cancel(); }
            catch
            {
                // User callbacks cannot replace the terminal outcome selected by the call.
            }
        }
    }
}
