namespace SharpLink.Server;

internal sealed partial class SharpLinkServer
{
    // Test-only handshake used to order lifecycle races without relying on lock waiter fairness.
    private Action? _replacementStateGateEnteredForTesting = null;

    public void ReplaceInterceptors(IEnumerable<ISharpLinkServerInterceptor> interceptors)
    {
        var candidate = ServerInterceptorGeneration.Create(CreateInterceptorSnapshot(interceptors));
        lock (_stateGate)
        {
            Volatile.Read(ref _replacementStateGateEnteredForTesting)?.Invoke();
            if (_lifecycle.HasStopStarted)
            {
                throw new InvalidOperationException(
                    $"Server state '{CurrentState}' does not accept runtime interceptor replacement.");
            }

            if (MaintenanceConfigured || CurrentState is ServerState.Draining or ServerState.Stopped or ServerState.Faulted)
            {
                throw new InvalidOperationException(
                    $"Server state '{CurrentState}' does not accept runtime interceptor replacement.");
            }

            Volatile.Write(ref _serverInterceptorGeneration, candidate);
        }
    }

    private static ISharpLinkServerInterceptor[] CreateInterceptorSnapshot(
        IEnumerable<ISharpLinkServerInterceptor> interceptors)
    {
        ArgumentNullException.ThrowIfNull(interceptors);
        var candidate = interceptors.ToArray();
        for (var index = 0; index < candidate.Length; index++)
        {
            if (candidate[index] is null)
            {
                throw new ArgumentException(
                    "The interceptor sequence cannot contain null elements.",
                    nameof(interceptors));
            }
        }
        return candidate.Length == 0 ? Array.Empty<ISharpLinkServerInterceptor>() : candidate;
    }
}
