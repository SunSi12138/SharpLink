; Assembly listing for method SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1+<GetAsyncEnumerator>d__8[int]:MoveNext():this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 210720
; 27 inlinees with PGO data; 83 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 312
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x128], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x120], zmm8
       vmovdqu32 zmmword ptr [rbp-0xE0], zmm8
       vmovdqu32 zmmword ptr [rbp-0xA0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       mov      gword ptr [rbp-0x108], rdi
       mov      rdx, rdi
 
G_M000_IG02:                ;; offset=0x0059
       mov      esi, dword ptr [rdx+0x30]
       mov      dword ptr [rbp-0x2C], esi
       mov      r8, gword ptr [rdx+0x08]
       mov      gword ptr [rbp-0x110], r8
 
G_M000_IG03:                ;; offset=0x006A
       mov      esi, dword ptr [rbp-0x2C]
       add      esi, 4
       cmp      esi, 8
       ja       G_M000_IG65
 
G_M000_IG04:                ;; offset=0x0079
       mov      esi, esi
       lea      rdi, [reloc @RWD00]
       mov      edi, dword ptr [rdi+4*rsi]
       lea      rax, G_M000_IG02
       add      rdi, rax
       jmp      rdi
 
G_M000_IG05:                ;; offset=0x0091
       cmp      dword ptr [rbp-0x2C], -4
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0097
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x30], -1
       cmp      byte  ptr [rdx+0x3C], 0
       jne      G_M000_IG85
 
G_M000_IG07:                ;; offset=0x00AF
       mov      rdx, gword ptr [rbp-0x108]
       mov      eax, dword ptr [rbp-0x2C]
       dec      eax
       cmp      eax, 2
       jbe      G_M000_IG16
 
G_M000_IG08:                ;; offset=0x00C4
       mov      rdi, gword ptr [rbp-0x110]
       cmp      gword ptr [rdi+0x10], 0
       jne      G_M000_IG20
       lea      rbx, bword ptr [rdi+0x38]
       mov      r15, gword ptr [rdi+0x08]
       test     r15, r15
       je       G_M000_IG21
       cmp      byte  ptr [rbx+0x19], 0
       jne      G_M000_IG22
 
G_M000_IG09:                ;; offset=0x00F1
       mov      rdx, gword ptr [rbp-0x108]
       mov      rax, gword ptr [rdx+0x18]
       mov      rcx, 0x7F02325388E8
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG26
       mov      rdi, rax
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      gword ptr [rbp-0xE0], rax
       mov      qword ptr [rbp-0xD8], rdx
 
G_M000_IG10:                ;; offset=0x0126
       vmovdqu32 xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG11:                ;; offset=0x0132
       mov      rdi, gword ptr [rbp-0x110]
       cmp      byte  ptr [rdi+0x51], 0
       jne      G_M000_IG33
       xor      esi, esi
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x34], esi
       mov      rsi, gword ptr [rbp-0x68]
       movzx    rax, byte  ptr [rbp-0x5E]
       movsx    rcx, word  ptr [rbp-0x60]
       mov      gword ptr [rbp-0x78], rsi
       mov      word  ptr [rbp-0x70], cx
       mov      byte  ptr [rbp-0x6E], al
       mov      byte  ptr [rbp-0x6D], 0
       mov      rbx, gword ptr [rbp-0x78]
       test     rbx, rbx
       jne      G_M000_IG27
 
G_M000_IG12:                ;; offset=0x0178
       mov      rbx, gword ptr [rbp-0x78]
       test     rbx, rbx
       jne      G_M000_IG30
       movzx    r15, byte  ptr [rbp-0x6E]
 
G_M000_IG13:                ;; offset=0x018A
       test     r15d, r15d
       je       G_M000_IG85
 
G_M000_IG14:                ;; offset=0x0193
       mov      rdx, gword ptr [rbp-0x108]
       mov      r11, gword ptr [rdx+0x18]
       mov      rax, 0x7F02325388E8
       cmp      qword ptr [r11], rax
       jne      G_M000_IG63
       mov      ebx, dword ptr [r11+0xE4]
 
G_M000_IG15:                ;; offset=0x01B8
       mov      rdi, gword ptr [rbp-0x110]
       movsx    rsi, byte  ptr [rdi+0x1C]
       jmp      G_M000_IG64
 
G_M000_IG16:                ;; offset=0x01C9
       mov      edi, eax
       lea      rsi, [reloc @RWD36]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG17:                ;; offset=0x01E1
       lea      rdi, bword ptr [rdx+0x90]
 
G_M000_IG18:                ;; offset=0x01E8
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG19:                ;; offset=0x01F1
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x30], -1
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x020D
       lea      rsi, bword ptr [rdi+0x38]
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu  xmm0, xmmword ptr [rsi+0x10]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      rax, qword ptr [rsi+0x20]
       mov      qword ptr [rsp+0x20], rax
       mov      rdi, gword ptr [rdi+0x10]
       mov      rax, gword ptr [rbp-0x110]
       mov      rsi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Client.SharpLinkClient+ClientLogicalCallState:TryEnterProgress(SharpLink.Abstractions.RpcDeadline,System.TimeProvider):bool:this]
       test     eax, eax
       jne      G_M000_IG09
       jmp      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x024F
       mov      edi, 0x2077
       mov      rsi, 0x7F023091D180
       call     [CORINFO_HELP_STRCNS]
       mov      rdi, rax
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG22:                ;; offset=0x026E
       cmp      byte  ptr [rbx+0x18], 0
       jne      SHORT G_M000_IG23
       mov      rdi, rbx
       call     [SharpLink.Abstractions.RpcDeadline:get_Timestamp():long:this]
       mov      rbx, rax
       mov      rdi, r15
       mov      rax, qword ptr [r15]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x38]System.TimeProvider:GetTimestamp():long:this
       cmp      rbx, rax
       setle    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0298
       mov      rdi, r15
       mov      rax, qword ptr [r15]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x38]System.TimeProvider:GetTimestamp():long:this
       sub      rax, qword ptr [rbx]
       cmp      rax, qword ptr [rbx+0x20]
       setae    bl
       movzx    rbx, bl
 
G_M000_IG24:                ;; offset=0x02B2
       test     ebx, ebx
       je       G_M000_IG09
 
G_M000_IG25:                ;; offset=0x02BA
       call     [SharpLink.Client.SharpLinkClient:CreateDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG26:                ;; offset=0x02C9
       mov      rdi, rax
       mov      r11, 0x7F022F8322F8
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:MoveNextAsync():System.Threading.Tasks.ValueTask`1[bool]:this
       mov      gword ptr [rbp-0xE0], rax
       mov      qword ptr [rbp-0xD8], rdx
       jmp      G_M000_IG10
 
G_M000_IG27:                ;; offset=0x02EC
       mov      rsi, rbx
       mov      rdi, 0x7F0231F118B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG28
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0314
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x70]
       mov      r11, 0x7F022F832318
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG29:                ;; offset=0x0333
       test     r15d, r15d
       jne      G_M000_IG12
       mov      dword ptr [rbp-0x2C], 1
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x30], 1
       lea      rdi, bword ptr [rdx+0x90]
       lea      rsi, bword ptr [rbp-0x78]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x58], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x58]
       mov      rdi, 0x7F0232579048
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x78]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG118
 
G_M000_IG30:                ;; offset=0x0391
       mov      rsi, rbx
       mov      rdi, 0x7F0231F118B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG32
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG31
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG31:                ;; offset=0x03C8
       movzx    r15, byte  ptr [r15+0x38]
       jmp      G_M000_IG13
 
G_M000_IG32:                ;; offset=0x03D2
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x70]
       mov      r11, 0x7F022F832320
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
       jmp      G_M000_IG13
 
G_M000_IG33:                ;; offset=0x03EF
       mov      rbx, gword ptr [rbp-0x68]
       test     rbx, rbx
       je       SHORT G_M000_IG36
       mov      rsi, rbx
       mov      rdi, 0x7F0231F118B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG34
       mov      esi, dword ptr [rax+0x34]
       and      esi, 0x1600000
       cmp      esi, 0x1000000
       sete     sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0428
       movsx    rsi, word  ptr [rbp-0x60]
       mov      rdi, rbx
       mov      r11, 0x7F022F832328
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       cmp      eax, 1
       sete     sil
       movzx    rsi, sil
 
G_M000_IG35:                ;; offset=0x0448
       test     esi, esi
       je       SHORT G_M000_IG41
 
G_M000_IG36:                ;; offset=0x044C
       mov      rbx, gword ptr [rbp-0x68]
       test     rbx, rbx
       jne      SHORT G_M000_IG37
       movzx    r15, byte  ptr [rbp-0x5E]
       jmp      SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x045C
       mov      rsi, rbx
       mov      rdi, 0x7F0231F118B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG39
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG38
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG38:                ;; offset=0x0493
       movzx    r15, byte  ptr [r15+0x38]
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x049A
       movsx    rsi, word  ptr [rbp-0x60]
       mov      rdi, rbx
       mov      r11, 0x7F022F832330
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
 
G_M000_IG40:                ;; offset=0x04B2
       mov      rdi, gword ptr [rbp-0x110]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ThrowIfDeadlineExpired():this]
       jmp      G_M000_IG13
 
G_M000_IG41:                ;; offset=0x04C4
       lea      rdi, [rbp-0x68]
       call     [System.Threading.Tasks.ValueTask`1[bool]:AsTask():System.Threading.Tasks.Task`1[bool]:this]
       mov      rdx, gword ptr [rbp-0x108]
       lea      rdi, bword ptr [rdx+0x28]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, gword ptr [rbp-0x108]
 
G_M000_IG42:                ;; offset=0x04E8
       cmp      dword ptr [rbp-0x2C], 2
       je       G_M000_IG48
       xor      edi, edi
       mov      dword ptr [rdx+0x34], edi
       mov      rdi, gword ptr [rdx+0x28]
       mov      rax, gword ptr [rbp-0x110]
       vmovdqu  ymm0, ymmword ptr [rax+0x38]
       vmovdqu  ymmword ptr [rbp-0xD0], ymm0
       mov      rsi, qword ptr [rax+0x58]
       mov      qword ptr [rbp-0xB0], rsi
       mov      rsi, gword ptr [rax+0x08]
       mov      rcx, gword ptr [rdx+0x10]
       cmp      byte  ptr [rcx+0x24], 0
       je       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0528
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG44:                ;; offset=0x0534
       vmovdqu32 xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rsp], xmm0
       vmovdqu32 xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rsp+0x10], xmm0
       mov      r8, qword ptr [rbp-0xB0]
       mov      qword ptr [rsp+0x20], r8
       mov      rdx, rcx
       call     [SharpLink.Abstractions.SharpLinkTimer:WaitAsync(System.Threading.Tasks.Task,SharpLink.Abstractions.RpcDeadline,System.TimeProvider,System.Threading.CancellationToken):System.Threading.Tasks.ValueTask`1[bool]]
       mov      gword ptr [rbp-0x88], rax
       mov      qword ptr [rbp-0x80], rdx
       mov      rsi, gword ptr [rbp-0x88]
       movzx    rdi, byte  ptr [rbp-0x7E]
       movsx    rax, word  ptr [rbp-0x80]
       mov      gword ptr [rbp-0x78], rsi
       mov      word  ptr [rbp-0x70], ax
       mov      byte  ptr [rbp-0x6E], dil
       mov      byte  ptr [rbp-0x6D], 0
       mov      r15, gword ptr [rbp-0x78]
       test     r15, r15
       je       G_M000_IG51
 
G_M000_IG45:                ;; offset=0x059B
       mov      rsi, r15
       mov      rdi, 0x7F0231F118B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG46
       test     dword ptr [rax+0x34], 0x1600000
       setne    bl
       movzx    rbx, bl
       jmp      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x05C1
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0x70]
       mov      r11, 0x7F022F832338
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    bl
       movzx    rbx, bl
 
G_M000_IG47:                ;; offset=0x05DE
       test     ebx, ebx
       jne      G_M000_IG51
       mov      dword ptr [rbp-0x2C], 2
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x30], 2
       lea      rdi, bword ptr [rdx+0x90]
       lea      rsi, bword ptr [rbp-0x78]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x58], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x58]
       mov      rdi, 0x7F0232579048
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x78]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG118
 
G_M000_IG48:                ;; offset=0x063B
       lea      rdi, bword ptr [rdx+0x90]
 
G_M000_IG49:                ;; offset=0x0642
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rbp-0x78], xmm0
 
G_M000_IG50:                ;; offset=0x064B
       xor      esi, esi
       mov      qword ptr [rdi], rsi
       mov      qword ptr [rdi+0x08], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG51:                ;; offset=0x0662
       mov      rbx, gword ptr [rbp-0x78]
       test     rbx, rbx
       jne      SHORT G_M000_IG52
       movzx    r15, byte  ptr [rbp-0x6E]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x0672
       mov      rsi, rbx
       mov      rdi, 0x7F0231F118B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG54
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG53
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG53:                ;; offset=0x06A9
       movzx    r15, byte  ptr [r15+0x38]
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x06B0
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x70]
       mov      r11, 0x7F022F832340
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetResult(short):bool:this
       mov      r15d, eax
 
G_M000_IG55:                ;; offset=0x06C8
       test     r15d, r15d
       jne      SHORT G_M000_IG58
 
G_M000_IG56:                ;; offset=0x06CD
       mov      rax, gword ptr [rbp-0x110]
       mov      rdi, gword ptr [rax+0x10]
       test     rdi, rdi
       je       SHORT G_M000_IG57
       call     [SharpLink.Client.SharpLinkClient+ClientLogicalCallState:TryClaimDeadline():bool:this]
 
G_M000_IG57:                ;; offset=0x06E3
       mov      rdx, gword ptr [rbp-0x108]
       mov      byte  ptr [rdx+0x3D], 1
       call     [SharpLink.Client.SharpLinkClient:CreateDeadlineExceededException():SharpLink.Abstractions.SharpLinkException]
       mov      r15, rax
       mov      rbx, gword ptr [rbp-0x108]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rdi, r15
       xor      rdx, rdx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateOwnerCore(System.Exception,System.Threading.CancellationTokenSource,System.Exception):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r14, rax
       mov      rdi, gword ptr [rbx+0x28]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, r14
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r14
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG58:                ;; offset=0x073C
       xor      edi, edi
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x34], edi
       mov      rdi, gword ptr [rdx+0x28]
       cmp      byte  ptr [rdi], dil
       mov      gword ptr [rbp-0x98], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x90], edi
       test     byte  ptr [rbp-0x90], 4
       jne      SHORT G_M000_IG59
       mov      rdi, gword ptr [rbp-0x98]
       test     dword ptr [rdi+0x34], 0x1600000
       jne      G_M000_IG62
 
G_M000_IG59:                ;; offset=0x077B
       mov      dword ptr [rbp-0x2C], 3
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x30], 3
       lea      rdi, bword ptr [rdx+0xA0]
       mov      rsi, gword ptr [rbp-0x98]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edx, dword ptr [rbp-0x90]
       mov      rbx, gword ptr [rbp-0x108]
       mov      dword ptr [rbx+0xA8], edx
       mov      gword ptr [rbp-0x58], rbx
       lea      rdx, bword ptr [rbx+0x40]
       lea      rsi, [rbp-0x58]
       mov      rdi, 0x7F0232579048
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x98]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG118
 
G_M000_IG60:                ;; offset=0x07E7
       vmovdqu32 xmm0, xmmword ptr [rdx+0xA0]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG61:                ;; offset=0x07F6
       xor      edi, edi
       mov      qword ptr [rdx+0xA0], rdi
       mov      qword ptr [rdx+0xA8], rdi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG62:                ;; offset=0x0814
       lea      rdi, [rbp-0x98]
       call     [System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1+ConfiguredTaskAwaiter[bool]:GetResult():bool:this]
       mov      r15d, eax
       xor      rdi, rdi
       mov      rdx, gword ptr [rbp-0x108]
       mov      gword ptr [rdx+0x28], rdi
       jmp      G_M000_IG13
 
G_M000_IG63:                ;; offset=0x0836
       mov      rdi, r11
       mov      r11, 0x7F022F832300
       call     [r11]System.Collections.Generic.IAsyncEnumerator`1[int]:get_Current():int:this
       mov      ebx, eax
       jmp      G_M000_IG15
 
G_M000_IG64:                ;; offset=0x084D
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x34], ebx
       mov      dword ptr [rbp-0x2C], -4
       mov      dword ptr [rdx+0x30], -4
       jmp      G_M000_IG109
 
G_M000_IG65:                ;; offset=0x086A
       cmp      byte  ptr [rdx+0x3C], 0
       jne      G_M000_IG120
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x30], -1
       mov      r8, gword ptr [rbp-0x110]
       lea      rsi, bword ptr [r8+0x18]
       mov      edi, 1
       xchg     dword ptr [rsi], edi
       test     edi, edi
       je       SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x0898
       mov      rdi, 0x7F0230A17150
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      edi, 0x10465
       mov      rsi, 0x7F02311F4600
       call     [CORINFO_HELP_STRCNS]
       mov      rsi, rax
       mov      rdi, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x08D4
       xor      esi, esi
       mov      dword ptr [rdx+0x34], esi
       lea      rsi, bword ptr [r8+0x20]
       mov      rdi, gword ptr [rsi]
       mov      rax, gword ptr [rsi+0x10]
       movsx    rsi, word  ptr [rsi+0x08]
       mov      gword ptr [rbp-0x50], rdi
       mov      word  ptr [rbp-0x48], si
       mov      byte  ptr [rbp-0x46], 0
       mov      gword ptr [rbp-0x40], rax
       mov      rbx, gword ptr [rbp-0x50]
       test     rbx, rbx
       je       G_M000_IG73
 
G_M000_IG68:                ;; offset=0x0906
       mov      rsi, rbx
       mov      rdi, 0x7F0232559C08
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG69
       test     dword ptr [rax+0x34], 0x1600000
       setne    r15b
       movzx    r15, r15b
       jmp      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x092E
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x48]
       mov      r11, 0x7F022F832308
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:GetStatus(short):int:this
       test     eax, eax
       setne    r15b
       movzx    r15, r15b
 
G_M000_IG70:                ;; offset=0x094D
       test     r15d, r15d
       jne      G_M000_IG73
       xor      edi, edi
       mov      rdx, gword ptr [rbp-0x108]
       mov      dword ptr [rdx+0x30], edi
       lea      rdi, bword ptr [rdx+0x78]
       lea      rsi, bword ptr [rbp-0x50]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       call     CORINFO_HELP_ASSIGN_BYREF
       mov      gword ptr [rbp-0x58], rdx
       add      rdx, 64
       lea      rsi, [rbp-0x58]
       mov      rdi, 0x7F0232579048
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0x50]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable`1+ConfiguredValueTaskAwaiter[SharpLink.Abstractions.SharpLinkClientInvocationResult]](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG118
 
G_M000_IG71:                ;; offset=0x09A4
       vmovdqu  xmm0, xmmword ptr [rdx+0x78]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       mov      rsi, qword ptr [rdx+0x88]
       mov      qword ptr [rbp-0x40], rsi
 
G_M000_IG72:                ;; offset=0x09B9
       xor      esi, esi
       mov      qword ptr [rdx+0x78], rsi
       mov      qword ptr [rdx+0x80], rsi
       mov      qword ptr [rdx+0x88], rsi
       mov      dword ptr [rbp-0x2C], -1
       mov      dword ptr [rdx+0x30], -1
 
G_M000_IG73:                ;; offset=0x09DB
       mov      r8, gword ptr [rbp-0x110]
       mov      rbx, gword ptr [rbp-0x50]
       test     rbx, rbx
       jne      SHORT G_M000_IG74
       mov      r15, gword ptr [rbp-0x40]
       jmp      SHORT G_M000_IG77
 
G_M000_IG74:                ;; offset=0x09F1
       mov      rsi, rbx
       mov      rdi, 0x7F0232559C08
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       SHORT G_M000_IG76
       mov      edi, dword ptr [r15+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG75
       mov      rdi, r15
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG75:                ;; offset=0x0A28
       mov      r15, gword ptr [r15+0x38]
       mov      r8, gword ptr [rbp-0x110]
       jmp      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0A35
       mov      rdi, rbx
       movsx    rsi, word  ptr [rbp-0x48]
       mov      r11, 0x7F022F832310
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[SharpLink.Abstractions.SharpLinkClientInvocationResult]:GetResult(short):SharpLink.Abstractions.SharpLinkClientInvocationResult:this
       mov      r15, rax
       mov      r8, gword ptr [rbp-0x110]
 
G_M000_IG77:                ;; offset=0x0A54
       mov      gword ptr [rbp-0x38], r15
       mov      rdi, r8
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:ThrowIfDeadlineExpired():this]
       lea      rdi, [rbp-0x38]
       mov      rsi, 0x7F023255FEC0
       call     [SharpLink.Abstractions.SharpLinkClientInvocationResult:GetValue[System.__Canon]():System.__Canon:this]
       mov      rbx, rax
       mov      rdi, gword ptr [rbp-0x110]
       mov      rdi, gword ptr [rdi+0x60]
       mov      rdx, gword ptr [rbp-0x108]
       mov      rsi, gword ptr [rdx+0x70]
       call     [System.Threading.CancellationTokenSource:CreateLinkedTokenSource(System.Threading.CancellationToken,System.Threading.CancellationToken):System.Threading.CancellationTokenSource]
       mov      rdx, gword ptr [rbp-0x108]
       lea      rdi, bword ptr [rdx+0x10]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG78:                ;; offset=0x0AA8
       mov      rdx, gword ptr [rbp-0x108]
       mov      rsi, gword ptr [rdx+0x10]
       cmp      byte  ptr [rsi+0x24], 0
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0AB9
       mov      edi, 70
       call     [System.ThrowHelper:ThrowObjectDisposedException(int)]
       int3     
 
G_M000_IG80:                ;; offset=0x0AC5
       mov      rdi, 0x7F02325388E8
       cmp      qword ptr [rbx], rdi
       jne      SHORT G_M000_IG81
       mov      rdi, rbx
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this]
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0ADF
       mov      rdi, rbx
       mov      r11, 0x7F022F8322F0
       call     [r11]System.Collections.Generic.IAsyncEnumerable`1[int]:GetAsyncEnumerator(System.Threading.CancellationToken):System.Collections.Generic.IAsyncEnumerator`1[int]:this
 
G_M000_IG82:                ;; offset=0x0AEF
       mov      rdx, gword ptr [rbp-0x108]
       lea      rdi, bword ptr [rdx+0x18]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG83:                ;; offset=0x0B03
       mov      rdx, gword ptr [rbp-0x108]
       mov      byte  ptr [rdx+0x3D], 0
       xor      rdi, rdi
       mov      gword ptr [rdx+0x20], rdi
 
G_M000_IG84:                ;; offset=0x0B14
       mov      dword ptr [rdx+0x38], edi
       jmp      G_M000_IG05
 
G_M000_IG85:                ;; offset=0x0B1C
       mov      r15, gword ptr [rbp-0x108]
       cmp      byte  ptr [r15+0x3D], 0
       jne      G_M000_IG105
 
G_M000_IG86:                ;; offset=0x0B2E
       mov      rdx, gword ptr [rbp-0x108]
       cmp      dword ptr [rbp-0x2C], 4
       je       G_M000_IG92
       mov      rdi, gword ptr [rdx+0x10]
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:TryCancelLifetime(System.Threading.CancellationTokenSource)]
       xor      edi, edi
       mov      rbx, gword ptr [rbp-0x108]
       mov      dword ptr [rbx+0x34], edi
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, 0x7F02325388E8
       cmp      qword ptr [rdi], rax
       jne      SHORT G_M000_IG87
       call     [SharpLink.Runtime.PooledAsyncStreamDispatcher`1[int]:DisposeAsync():System.Threading.Tasks.ValueTask:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0B7E
       mov      r11, 0x7F022F8322E8
       call     [r11]System.IAsyncDisposable:DisposeAsync():System.Threading.Tasks.ValueTask:this
       mov      gword ptr [rbp-0xF0], rax
       mov      qword ptr [rbp-0xE8], rdx
 
G_M000_IG88:                ;; offset=0x0B99
       mov      rsi, gword ptr [rbp-0xF0]
       movsx    rdi, word  ptr [rbp-0xE8]
       mov      gword ptr [rbp-0xA8], rsi
       mov      word  ptr [rbp-0xA0], di
       mov      byte  ptr [rbp-0x9E], 0
       mov      r15, gword ptr [rbp-0xA8]
       test     r15, r15
       je       G_M000_IG94
 
G_M000_IG89:                ;; offset=0x0BCD
       mov      rsi, r15
       mov      rdi, 0x7F0230916E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG90
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0BF5
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0xA0]
       mov      r11, 0x7F022F832348
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG91:                ;; offset=0x0C17
       test     r14d, r14d
       jne      SHORT G_M000_IG94
       mov      dword ptr [rbx+0x30], 4
       lea      rdi, bword ptr [rbx+0xB0]
       lea      rsi, bword ptr [rbp-0xA8]
       call     CORINFO_HELP_ASSIGN_BYREF
       movsq    
       mov      gword ptr [rbp-0x58], rbx
       lea      rdx, bword ptr [rbx+0x40]
       lea      rsi, [rbp-0x58]
       mov      rdi, 0x7F0232579048
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:GetStateMachineBox[System.__Canon](byref,byref):System.Runtime.CompilerServices.IAsyncStateMachineBox]
       mov      rsi, rax
       lea      rdi, [rbp-0xA8]
       call     [System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1[System.Threading.Tasks.VoidTaskResult]:AwaitUnsafeOnCompleted[System.Runtime.CompilerServices.ConfiguredValueTaskAwaitable+ConfiguredValueTaskAwaiter](byref,System.Runtime.CompilerServices.IAsyncStateMachineBox)]
       jmp      G_M000_IG118
 
G_M000_IG92:                ;; offset=0x0C69
       vmovdqu32 xmm0, xmmword ptr [rdx+0xB0]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG93:                ;; offset=0x0C78
       xor      esi, esi
       mov      qword ptr [rdx+0xB0], rsi
       mov      qword ptr [rdx+0xB8], rsi
       mov      dword ptr [rdx+0x30], -1
       mov      rbx, rdx
 
G_M000_IG94:                ;; offset=0x0C92
       mov      r15, gword ptr [rbp-0xA8]
       test     r15, r15
       je       SHORT G_M000_IG101
 
G_M000_IG95:                ;; offset=0x0C9E
       mov      rsi, r15
       mov      rdi, 0x7F0230916E10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG98
 
G_M000_IG96:                ;; offset=0x0CB5
       mov      edi, dword ptr [rax+0x34]
       and      edi, 0x11000000
       cmp      edi, 0x1000000
       je       SHORT G_M000_IG101
 
G_M000_IG97:                ;; offset=0x0CC6
       mov      rdi, rax
       xor      esi, esi
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      SHORT G_M000_IG101
 
G_M000_IG98:                ;; offset=0x0CD3
       mov      rdi, 0x7F023218F178
       cmp      qword ptr [r15], rdi
       jne      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0CE2
       movsx    rsi, word  ptr [rbp-0xA0]
       mov      rdi, r15
       call     [Microsoft.Win32.SafeHandles.SafeFileHandle+ThreadPoolValueTaskSource:GetResult(short):long:this]
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0CF5
       mov      rdi, r15
       movsx    rsi, word  ptr [rbp-0xA0]
       mov      r11, 0x7F022F832350
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       nop      
 
G_M000_IG101:                ;; offset=0x0D0E
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, qword ptr [r15]
       mov      rdi, 0x7F0232195810
       cmp      r14, rdi
       jne      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0D24
       mov      rdi, r15
       mov      esi, 1
       call     [System.Threading.CancellationTokenSource+Linked1CancellationTokenSource:Dispose(bool):this]
       jmp      SHORT G_M000_IG104
 
G_M000_IG103:                ;; offset=0x0D34
       mov      rdi, r15
       mov      esi, 1
       mov      rax, qword ptr [r14+0x40]
       call     [rax+0x28]System.Threading.CancellationTokenSource:Dispose(bool):this
 
G_M000_IG104:                ;; offset=0x0D43
       mov      rdi, r15
       call     [System.GC:SuppressFinalize(System.Object)]
       mov      r15, rbx
 
G_M000_IG105:                ;; offset=0x0D4F
       mov      rbx, gword ptr [r15+0x20]
       test     rbx, rbx
       je       SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0D58
       mov      rsi, rbx
       mov      rdi, 0x7F02308505D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG107
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG107:                ;; offset=0x0D78
       mov      rdi, rax
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Capture(System.Exception):System.Runtime.ExceptionServices.ExceptionDispatchInfo]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [System.Runtime.ExceptionServices.ExceptionDispatchInfo:Throw():this]
       int3     
 
G_M000_IG108:                ;; offset=0x0D8D
       cmp      byte  ptr [r15+0x3C], 0
       jne      G_M000_IG120
       xor      rsi, rsi
       mov      gword ptr [r15+0x20], rsi
       jmp      G_M000_IG120
 
G_M000_IG109:                ;; offset=0x0DA3
       lea      rbx, bword ptr [rdx+0x48]
       mov      byte  ptr [rbx+0x22], 1
       cmp      byte  ptr [rbx+0x23], 0
       jne      G_M000_IG125
       mov      byte  ptr [rbx+0x23], 1
       mov      r15, gword ptr [rbx]
       test     r15, r15
       je       G_M000_IG126
 
G_M000_IG110:                ;; offset=0x0DC5
       test     r15, r15
       je       G_M000_IG118
       mov      r14, gword ptr [rbx+0x10]
       test     r14, r14
       jne      G_M000_IG142
       cmp      byte  ptr [rbx+0x24], 0
       je       G_M000_IG141
       mov      rbx, gword ptr [rbx+0x08]
       mov      rsi, 0x7EFD424018A0
       cmp      r15, gword ptr [rsi]
       jne      G_M000_IG119
 
G_M000_IG111:                ;; offset=0x0DFC
       mov      rax, rbx
       test     rax, rax
       je       SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0E04
       mov      rsi, 0x7F0232577E50
       cmp      qword ptr [rax], rsi
       jne      G_M000_IG127
 
G_M000_IG113:                ;; offset=0x0E17
       test     rax, rax
       je       G_M000_IG128
       mov      rdi, 0x7EFD42401898
       mov      r15, gword ptr [rdi]
       cmp      byte  ptr [r15+0x38], 0
       jne      G_M000_IG129
 
G_M000_IG114:                ;; offset=0x0E38
       mov      rdi, 0x7F02AEE81948
       mov      rax, 0x7F02AF56F180
       call     rax
       cmp      dword ptr [rax], 6
       jle      G_M000_IG130
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x30]
       test     rax, rax
       je       G_M000_IG130
 
G_M000_IG115:                ;; offset=0x0E68
       mov      rdi, gword ptr [rax+0x10]
       test     rdi, rdi
       je       G_M000_IG139
       mov      rdi, gword ptr [rdi+0x18]
       mov      gword ptr [rbp-0x130], rdi
       mov      rdi, gword ptr [rbp-0x130]
       mov      r14d, dword ptr [rdi+0x18]
       cmp      r14d, 0x7FFFFFFF
       je       G_M000_IG131
 
G_M000_IG116:                ;; offset=0x0E98
       mov      esi, dword ptr [rdi+0x14]
       add      esi, dword ptr [rdi+0x10]
       cmp      esi, r14d
       jle      G_M000_IG132
       mov      esi, r14d
       and      esi, dword ptr [rdi+0x10]
       movsxd   rsi, esi
       mov      rdi, gword ptr [rdi+0x08]
       mov      rdx, 0x7F022F8247B0
       call     [CORINFO_HELP_LDELEMA_REF]
       mov      rdi, rax
       mov      rsi, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       inc      r14d
       mov      rdi, gword ptr [rbp-0x130]
       mov      dword ptr [rdi+0x18], r14d
 
G_M000_IG117:                ;; offset=0x0EDD
       add      r15, 120
       mov      edi, 1
       xchg     dword ptr [r15], edi
       test     edi, edi
       jne      SHORT G_M000_IG118
       mov      rdi, 0x7EFD424019E8
       mov      rbx, gword ptr [rdi]
       lea      rdi, bword ptr [rbx+0x160]
       lock     
       inc      dword ptr [rdi]
       mov      rdi, rbx
       call     [System.Threading.PortableThreadPool+WorkerThread:MaybeAddWorkingWorker(System.Threading.PortableThreadPool)]
       cmp      dword ptr [rbx+0x164], 6
       jne      G_M000_IG140
 
G_M000_IG118:                ;; offset=0x0F1A
       vzeroupper 
       add      rsp, 312
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG119:                ;; offset=0x0F2F
       mov      rdi, 0x7F02325A7A10
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r14+0x10]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7EFD42401898
       mov      rdi, gword ptr [rdi]
       mov      rsi, r14
       xor      edx, edx
       call     [System.Threading.ThreadPoolWorkQueue:Enqueue(System.Object,bool):this]
       jmp      SHORT G_M000_IG118
 
G_M000_IG120:                ;; offset=0x0F73
       mov      r15, gword ptr [rbp-0x108]
       mov      dword ptr [r15+0x30], -2
       xor      rdi, rdi
       mov      gword ptr [r15+0x10], rdi
 
G_M000_IG121:                ;; offset=0x0F88
       mov      gword ptr [r15+0x18], rdi
 
G_M000_IG122:                ;; offset=0x0F8C
       mov      gword ptr [r15+0x20], rdi
 
G_M000_IG123:                ;; offset=0x0F90
       mov      gword ptr [r15+0x28], rdi
 
G_M000_IG124:                ;; offset=0x0F94
       mov      dword ptr [r15+0x34], edi
       lea      rdi, bword ptr [r15+0x40]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x48]
       mov      byte  ptr [rdi+0x22], 0
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SignalCompletion():this]
       jmp      G_M000_IG118
 
G_M000_IG125:                ;; offset=0x0FB5
       call     [System.ThrowHelper:ThrowInvalidOperationException()]
       int3     
 
G_M000_IG126:                ;; offset=0x0FBC
       mov      rsi, 0x7EFD42401DC8
       mov      rsi, gword ptr [rsi]
       mov      rdi, rbx
       xor      rdx, rdx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      r15, rax
       jmp      G_M000_IG110
 
G_M000_IG127:                ;; offset=0x0FDB
       mov      rsi, rbx
       mov      rdi, 0x7F023218AF20
       call     CORINFO_HELP_ISINSTANCEOFINTERFACE
       jmp      G_M000_IG113
 
G_M000_IG128:                ;; offset=0x0FF2
       mov      rdi, rbx
       call     [System.ThrowHelper:ThrowUnexpectedStateForKnownCallback(System.Object)]
       int3     
 
G_M000_IG129:                ;; offset=0x0FFC
       mov      rdi, 0x7EFD42401850
       mov      rdi, gword ptr [rdi]
       cmp      byte  ptr [rdi+0x9D], 0
       je       G_M000_IG114
       mov      rdi, 0x7EFD42401850
       mov      rdi, gword ptr [rdi]
       mov      rsi, rbx
       call     [System.Diagnostics.Tracing.FrameworkEventSource:ThreadPoolEnqueueWorkObject(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG130:                ;; offset=0x1031
       mov      edi, 6
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       jmp      G_M000_IG115
 
G_M000_IG131:                ;; offset=0x1041
       call     [System.Threading.ThreadPoolWorkQueue+WorkStealingQueue:LocalPush_HandleTailOverflow():int:this]
       mov      r14d, eax
       mov      rdi, gword ptr [rbp-0x130]
       jmp      G_M000_IG116
 
G_M000_IG132:                ;; offset=0x1056
       mov      byte  ptr [rbp-0xF8], 0
 
G_M000_IG133:                ;; offset=0x105D
       add      rdi, 28
       lea      rsi, [rbp-0xF8]
       call     [System.Threading.SpinLock:Enter(byref):this]
       mov      rdi, gword ptr [rbp-0x130]
       mov      r13d, dword ptr [rdi+0x14]
       mov      r12d, dword ptr [rdi+0x18]
       sub      r12d, dword ptr [rdi+0x14]
       cmp      r12d, dword ptr [rdi+0x10]
       jl       G_M000_IG137
       mov      rsi, gword ptr [rdi+0x08]
       mov      esi, dword ptr [rsi+0x08]
       add      esi, esi
       movsxd   rsi, esi
       mov      rdi, 0x7F02308222D8
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      r14, rax
       xor      eax, eax
       jmp      SHORT G_M000_IG136
 
G_M000_IG134:                ;; offset=0x10AD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG135:                ;; offset=0x10B3
       mov      rsi, gword ptr [rdi+0x08]
       lea      ecx, [rax+r13]
       and      ecx, dword ptr [rdi+0x10]
       cmp      ecx, dword ptr [rsi+0x08]
       jae      SHORT G_M000_IG134
       mov      rsi, gword ptr [rsi+8*rcx+0x10]
       cmp      eax, dword ptr [r14+0x08]
       jae      SHORT G_M000_IG134
       mov      qword ptr [rbp-0x100], rax
       lea      rdi, bword ptr [r14+8*rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, qword ptr [rbp-0x100]
       inc      edi
       mov      rax, rdi
 
G_M000_IG136:                ;; offset=0x10EB
       mov      rdi, gword ptr [rbp-0x130]
       mov      rsi, gword ptr [rdi+0x08]
       cmp      dword ptr [rsi+0x08], eax
       jg       SHORT G_M000_IG135
       lea      rdi, bword ptr [rdi+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      esi, esi
       mov      rdi, gword ptr [rbp-0x130]
       mov      dword ptr [rdi+0x14], esi
       mov      r14d, r12d
       mov      dword ptr [rdi+0x18], r14d
       mov      esi, dword ptr [rdi+0x10]
       add      esi, esi
       or       esi, 1
       mov      dword ptr [rdi+0x10], esi
 
G_M000_IG137:                ;; offset=0x1125
       mov      esi, r14d
       and      esi, dword ptr [rdi+0x10]
       movsxd   rsi, esi
       mov      rdi, gword ptr [rdi+0x08]
       mov      rdx, 0x7F022F8247B0
       call     [CORINFO_HELP_LDELEMA_REF]
       mov      rdi, rax
       mov      rsi, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      edi, [r14+0x01]
       mov      rbx, gword ptr [rbp-0x130]
       mov      dword ptr [rbx+0x18], edi
 
G_M000_IG138:                ;; offset=0x115B
       cmp      byte  ptr [rbp-0xF8], 0
       je       G_M000_IG117
       lea      rdi, bword ptr [rbx+0x1C]
       xor      esi, esi
       call     [System.Threading.SpinLock:Exit(bool):this]
       jmp      G_M000_IG117
 
G_M000_IG139:                ;; offset=0x1179
       mov      rdi, gword ptr [r15+0x08]
       mov      rsi, rbx
       cmp      dword ptr [rdi], edi
       call     [System.Collections.Concurrent.ConcurrentQueue`1[System.__Canon]:Enqueue(System.__Canon):this]
       jmp      G_M000_IG117
 
G_M000_IG140:                ;; offset=0x118D
       mov      rdi, rbx
       call     [System.Threading.PortableThreadPool+GateThread:EnsureRunningSlow(System.Threading.PortableThreadPool)]
       jmp      G_M000_IG118
 
G_M000_IG141:                ;; offset=0x119B
       mov      rsi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [r15+0x08]
       call     [r15+0x18]System.Action`1[System.__Canon]:Invoke(System.__Canon):this
       jmp      G_M000_IG118
 
G_M000_IG142:                ;; offset=0x11AC
       mov      rsi, r14
       mov      rdi, 0x7F023091A7C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG143
       mov      rsi, r14
       mov      rdi, 0x7F0232300CE8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG144
 
G_M000_IG143:                ;; offset=0x11DA
       movzx    rcx, byte  ptr [rbx+0x24]
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:InvokeContinuationWithContext(System.Object,System.Action`1[System.Object],System.Object,bool)]
       jmp      G_M000_IG118
 
G_M000_IG144:                ;; offset=0x11F3
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdi, r14
       mov      rsi, r15
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCoreShared:ScheduleCapturedContext(System.Object,System.Action`1[System.Object],System.Object)]
       jmp      G_M000_IG118
 
G_M000_IG145:                ;; offset=0x1208
       sub      rsp, 40
 
G_M000_IG146:                ;; offset=0x120C
       mov      rbx, gword ptr [rbp-0x108]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, 1
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:TransferLifetime(System.Exception,System.Threading.CancellationTokenSource,bool):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x1227
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG148:                ;; offset=0x1230
       mov      rdi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG149:                ;; offset=0x1242
       sub      rsp, 40
 
G_M000_IG150:                ;; offset=0x1246
       mov      rsi, rdi
       mov      rdi, 0x7F0232181528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x125D
       xor      eax, eax
       jmp      SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x1261
       mov      gword ptr [rbp-0x118], rax
       mov      rdx, gword ptr [rbp-0x108]
       mov      rdi, gword ptr [rdx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG153:                ;; offset=0x1283
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG154:                ;; offset=0x128B
       sub      rsp, 40
 
G_M000_IG155:                ;; offset=0x128F
       mov      rdx, gword ptr [rbp-0x108]
       mov      byte  ptr [rdx+0x3D], 1
       mov      rdi, gword ptr [rbp-0x118]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      r15, rax
       mov      rdx, gword ptr [rbp-0x108]
       mov      rdx, gword ptr [rdx+0x10]
       mov      rdi, r15
       mov      rsi, gword ptr [rbp-0x118]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x108]
       mov      rdi, gword ptr [rdx+0x28]
       mov      rsi, gword ptr [rdx+0x18]
       mov      rdx, gword ptr [rdx+0x10]
       mov      rcx, rbx
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG156:                ;; offset=0x12FB
       sub      rsp, 40
 
G_M000_IG157:                ;; offset=0x12FF
       mov      rsi, rdi
       mov      rdi, 0x7F0232181528
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x1319
       xor      eax, eax
       jmp      SHORT G_M000_IG165
 
G_M000_IG159:                ;; offset=0x131D
       mov      gword ptr [rbp-0x120], rbx
       mov      r15, gword ptr [rbp-0x108]
       cmp      byte  ptr [r15+0x3D], 0
       jne      SHORT G_M000_IG163
 
G_M000_IG160:                ;; offset=0x1332
       mov      rdi, gword ptr [r15+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:get_IsCancellationRequested():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x1342
       mov      rdi, rbx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       setne    al
       movzx    rax, al
       jmp      SHORT G_M000_IG164
 
G_M000_IG162:                ;; offset=0x1356
       mov      eax, 1
       jmp      SHORT G_M000_IG164
 
G_M000_IG163:                ;; offset=0x135D
       xor      eax, eax
 
G_M000_IG164:                ;; offset=0x135F
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG165:                ;; offset=0x1367
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG166:                ;; offset=0x136F
       sub      rsp, 40
 
G_M000_IG167:                ;; offset=0x1373
       mov      r15, gword ptr [rbp-0x108]
       mov      byte  ptr [r15+0x3D], 1
       mov      rdi, gword ptr [rbp-0x120]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCancellationTerminal(System.OperationCanceledException):System.OperationCanceledException]
       mov      rbx, rax
       mov      rdx, gword ptr [r15+0x10]
       mov      rdi, rbx
       mov      rsi, gword ptr [rbp-0x120]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      r14, rax
       mov      rdi, gword ptr [rbp-0x120]
       call     [System.Threading.Tasks.Task:FromException(System.Exception):System.Threading.Tasks.Task]
       mov      rdi, rax
       mov      rsi, gword ptr [r15+0x18]
       mov      rdx, gword ptr [r15+0x10]
       mov      rcx, r14
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, r14
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG168:                ;; offset=0x13DE
       sub      rsp, 40
 
G_M000_IG169:                ;; offset=0x13E2
       mov      rsi, rdi
       mov      rdi, 0x7F0232180880
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x13FC
       xor      eax, eax
       jmp      SHORT G_M000_IG178
 
G_M000_IG171:                ;; offset=0x1400
       mov      gword ptr [rbp-0x128], rbx
       mov      r15, gword ptr [rbp-0x108]
       cmp      byte  ptr [r15+0x3D], 0
       jne      SHORT G_M000_IG176
 
G_M000_IG172:                ;; offset=0x1415
       mov      rdi, rbx
       call     [SharpLink.Abstractions.SharpLinkException:get_Code():int:this]
       cmp      eax, 13
       jne      SHORT G_M000_IG176
 
G_M000_IG173:                ;; offset=0x1423
       mov      rdi, gword ptr [rbp-0x110]
       add      rdi, 56
       mov      rsi, gword ptr [rbp-0x110]
       mov      rsi, gword ptr [rsi+0x08]
       call     [SharpLink.Abstractions.RpcDeadline:IsExpired(System.TimeProvider):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x1443
       mov      rdi, rbx
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:GetAbandonedUserWork(System.Exception):System.Threading.Tasks.Task]
       test     rax, rax
       setne    al
       movzx    rax, al
       jmp      SHORT G_M000_IG177
 
G_M000_IG175:                ;; offset=0x1457
       mov      eax, 1
       jmp      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x145E
       xor      eax, eax
 
G_M000_IG177:                ;; offset=0x1460
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG178:                ;; offset=0x1468
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG179:                ;; offset=0x1470
       sub      rsp, 40
 
G_M000_IG180:                ;; offset=0x1474
       mov      r15, gword ptr [rbp-0x108]
       mov      byte  ptr [r15+0x3D], 1
       mov      rdi, gword ptr [rbp-0x128]
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Abstractions.SharpLinkException:get_Code():int:this]
       mov      ebx, eax
       mov      rdi, gword ptr [rbp-0x128]
       call     [SharpLink.Abstractions.SharpLinkException:get_DetailCode():ushort:this]
       mov      r14d, eax
       mov      rdi, 0x7F0232180880
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, gword ptr [rbp-0x128]
       mov      rax, gword ptr [rbp-0x128]
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]System.Exception:get_Message():System.String:this
       mov      rcx, rax
       mov      esi, ebx
       mov      edx, r14d
       mov      rdi, r13
       mov      r8, gword ptr [rbp-0x128]
       call     [SharpLink.Abstractions.SharpLinkException:.ctor(int,ushort,System.String,System.Exception):this]
       mov      rdx, gword ptr [r15+0x10]
       mov      rdi, r13
       mov      rsi, gword ptr [rbp-0x128]
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:CreateCarrierOwner(System.Exception,System.Exception,System.Threading.CancellationTokenSource):SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner]
       mov      rbx, rax
       mov      rdi, gword ptr [rbp-0x128]
       call     [System.Threading.Tasks.Task:FromException(System.Exception):System.Threading.Tasks.Task]
       mov      rdi, rax
       mov      rsi, gword ptr [r15+0x18]
       mov      rdx, gword ptr [r15+0x10]
       mov      rcx, rbx
       call     [SharpLink.Client.SharpLinkClient+InterceptedAsyncEnumerable`1[int]:CompleteAbandonedStreamAsync(System.Threading.Tasks.Task,System.Collections.Generic.IAsyncEnumerator`1[int],System.Threading.CancellationTokenSource,SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner):System.Threading.Tasks.Task]
       mov      rsi, rax
       mov      rdi, rbx
       cmp      dword ptr [rdi], edi
       call     [SharpLink.Runtime.SharpLinkPhysicalWork+PhysicalOwner:Track(System.Threading.Tasks.Task):this]
       mov      rdi, r13
 
G_M000_IG181:                ;; offset=0x152C
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG182:                ;; offset=0x1532
       sub      rsp, 40
 
G_M000_IG183:                ;; offset=0x1536
       mov      rsi, rdi
       mov      r15, gword ptr [rbp-0x108]
       lea      rdi, bword ptr [r15+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rax, G_M000_IG85
 
G_M000_IG184:                ;; offset=0x1550
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG185:                ;; offset=0x1558
       sub      rsp, 40
 
G_M000_IG186:                ;; offset=0x155C
       mov      rbx, gword ptr [rbp-0x108]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, 1
       call     [SharpLink.Runtime.SharpLinkPhysicalWork:TransferLifetime(System.Exception,System.Threading.CancellationTokenSource,bool):System.Exception]
       test     rax, rax
       je       SHORT G_M000_IG188
 
G_M000_IG187:                ;; offset=0x1577
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG188:                ;; offset=0x1580
       mov      rdi, gword ptr [rbx+0x10]
       cmp      dword ptr [rdi], edi
       call     [System.Threading.CancellationTokenSource:Dispose():this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG189:                ;; offset=0x1592
       sub      rsp, 40
 
G_M000_IG190:                ;; offset=0x1596
       mov      rbx, rdi
       mov      r15, gword ptr [rbp-0x108]
       mov      dword ptr [r15+0x30], -2
       xor      rdi, rdi
       mov      gword ptr [r15+0x10], rdi
 
G_M000_IG191:                ;; offset=0x15AE
       mov      gword ptr [r15+0x18], rdi
 
G_M000_IG192:                ;; offset=0x15B2
       mov      gword ptr [r15+0x20], rdi
 
G_M000_IG193:                ;; offset=0x15B6
       mov      gword ptr [r15+0x28], rdi
 
G_M000_IG194:                ;; offset=0x15BA
       mov      dword ptr [r15+0x34], edi
       lea      rdi, bword ptr [r15+0x40]
       call     [System.Runtime.CompilerServices.AsyncIteratorMethodBuilder:Complete():this]
       lea      rdi, bword ptr [r15+0x48]
       mov      rsi, rbx
       call     [System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore`1[bool]:SetException(System.Exception):this]
       lea      rax, G_M000_IG118
 
G_M000_IG195:                ;; offset=0x15DC
       vzeroupper 
       add      rsp, 40
       ret      
 
G_M000_IG196:                ;; offset=0x15E4
       sub      rsp, 40
 
G_M000_IG197:                ;; offset=0x15E8
       cmp      byte  ptr [rbp-0xF8], 0
       je       SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x15F1
       mov      rbx, gword ptr [rbp-0x130]
       lea      rdi, bword ptr [rbx+0x1C]
       xor      esi, esi
       call     [System.Threading.SpinLock:Exit(bool):this]
 
G_M000_IG199:                ;; offset=0x1604
       nop      
 
G_M000_IG200:                ;; offset=0x1605
       vzeroupper 
       add      rsp, 40
       ret      
 
RWD00  	dd	00000038h ; case G_M000_IG05
       	dd	00000811h ; case G_M000_IG65
       	dd	00000811h ; case G_M000_IG65
       	dd	00000811h ; case G_M000_IG65
       	dd	0000094Bh ; case G_M000_IG71
       	dd	00000038h ; case G_M000_IG05
       	dd	00000038h ; case G_M000_IG05
       	dd	00000038h ; case G_M000_IG05
       	dd	00000AD5h ; case G_M000_IG86
RWD36  	dd	00000188h ; case G_M000_IG17
       	dd	0000048Fh ; case G_M000_IG42
       	dd	0000078Eh ; case G_M000_IG60

; Total bytes of code 5645
