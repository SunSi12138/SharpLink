import json,math,statistics,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
rows={}; process=[]
for i,arm in enumerate('ABBABAAB'):
 d=json.loads((p/f'network-{i:02}-{arm}.json').read_text())
 assert d['tieredPgo']=='default' and d['runtime']=='.NET 10.0.11'
 cells={}
 for r in d['result']:
  key=(r['transport'],r['mode'],r['Tracked'],r['Items'],r['concurrency'])
  assert r['operations']==2000 and len(r['ticks'])==2000
  m={'ns':r['elapsedTicks']*1e9/r['frequency']/r['operations'],
     'bytes':r['bytes']/r['operations'],'cpu_ns':r['cpuMilliseconds']*1e6/r['operations'],
     'p99_ns':r['p99']*1e9/r['frequency'],'p999_ns':r['p999']*1e9/r['frequency']}
  cells.setdefault(key,[]).append(m)
 assert len(cells)==34 and all(len(v)==5 for v in cells.values())
 process.append({k:{metric:statistics.median(s[metric] for s in v) for metric in v[0]} for k,v in cells.items()})
for key in process[0]:
 row={'transport':key[0],'mode':key[1],'tracked':key[2],'items':key[3],'concurrency':key[4]}
 for metric in process[0][key]:
  av=[process[i][key][metric] for i,a in enumerate('ABBABAAB') if a=='A']
  bv=[process[i][key][metric] for i,a in enumerate('ABBABAAB') if a=='B']
  ratios=[process[b][key][metric]/process[a][key][metric] for a,b in [(0,1),(3,2),(5,4),(6,7)]]
  row[metric]={'A_median':statistics.median(av),'B_median':statistics.median(bv),'paired_ratios':ratios,'paired_geomean':math.prod(ratios)**.25}
 rows['|'.join(map(str,key))]=row
(p/'network-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
lines=['# Fixed complete-method-facts network campaign','','All 8 prescribed processes, 34 cells, 5 samples/cell, 2,720,000 measured complete calls retained. A/B medians and paired geometric ratios are distinct summaries. No outlier removal.','','| Transport | Mode | Tracked/items/c | A ns/op | B ns/op | paired B/A | A B/op | B B/op | CPU B/A | P99 B/A |','|---|---|---|---:|---:|---:|---:|---:|---:|---:|']
for r in rows.values():
 lines.append(f"| {r['transport']} | {r['mode']} | {r['tracked']}/{r['items']}/{r['concurrency']} | {r['ns']['A_median']:.2f} | {r['ns']['B_median']:.2f} | {r['ns']['paired_geomean']:.4f} | {r['bytes']['A_median']:.2f} | {r['bytes']['B_median']:.2f} | {r['cpu_ns']['paired_geomean']:.4f} | {r['p99_ns']['paired_geomean']:.4f} |")
(p/'network-summary.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
