# M0 tracking-label correction — 2026-10-28

The frozen campaign's `Tracked=true` means the fixture selected `[Timeout(3600)] Tracked(count, CancellationToken)` rather than `[NonCancellable] Plain(count)`. Its old `CanBeCanceled` witness establishes only that the service received a cancellable token. **It does not by itself establish a per-request `ServerCallCancellationState`, a map entry for the active request, or token ownership.** The old authored probe comment claiming it proved state ownership was stronger than the recorded evidence. The frozen source/binaries and that comment are retained as historical evidence, not silently edited.

A separate untimed diagnostic now uses the frozen A/B runtime DLLs, a real intercepted network request, and a synchronous blocked enumerator matching the measured Range's synchronous completion shape. The inspector waits until enumeration is blocked, obtains `activeRequestId` from the interceptor context, and queries the live connection's cancellation map by that exact id. On each arm and on TCP/SharedMemory:

- Timed/cancellable: the map entry exists, its `RequestId` equals `activeRequestId`, and its `InvocationToken` equals both the business method's cancellation argument and the interceptor's token. It differs from the connection token.
- Untimed/noncancellable: no map entry exists while the synchronous enumerator is blocked. The interceptor token is nevertheless cancellable and equals the connection-lifetime token. The business method has no cancellation argument.

An initial diagnostic used an async gate; that itself induced the normal async-continuation tracking state on the untimed request. Another initial version captured the enumerator's linked lifetime token instead of the business argument. Both failed attempts are retained and informed the corrected diagnostic. The no-state observation is specifically for the synchronous service shape; it is not a claim that arbitrary untimed asynchronous streams never need call state.

Diagnostic source: the M1 worktree's `eng/method-facts-preflight/`. Final verified output: `artifacts/method-facts-m1/preflight-A-verified.json` and `preflight-B-verified.json` in `/Users/sunsi/.codex/worktrees/issue-732-method-facts-m1/SharpLink`.

This adds structural evidence for the declared tracked fixture. It does not retroactively instrument the measured calls, change any historical sample, or clear M0's performance No-Go. No new network timing campaign was run.

M0's previously uncommitted source was locally fixed as `37548b7a` on `experiment/issue-732-complete-method-facts`; original frozen campaign archives and binaries remain separately retained.
