import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[3]
e=Path(__file__).resolve().parent
base=Path('/Users/sunsi/.codex/worktrees/issue-732-method-facts-baseline/SharpLink')
records=[]
def run(label,command,cwd,output,expected=0):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
 with open(output,'w') as stream:
  result=subprocess.run(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
 rec={'label':label,'command':command,'cwd':str(cwd),'output':str(output),'startedUtc':start,'durationSeconds':time.monotonic()-clock,'exitCode':result.returncode,'expectedExitCode':expected}
 records.append(rec);(e/'campaign.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(rec),flush=True)
 if result.returncode!=expected:raise RuntimeError(f'{label} unexpected exit {result.returncode}')
for i,arm in enumerate('ABBABAAB'):
 run(f'network-{i:02}-{arm}',['dotnet',str(e/f'arm-{arm}/FactsProbe.dll'),'network'],root,e/f'network-{i:02}-{arm}.json')
scenarios=['StaticDefault','AdmissionImmediate','ServerInterceptor','MetricsClientAndServer','DynamicServiceActual']
for i,arm in enumerate('ABBA'):
 repo=base if arm=='A' else root
 for scenario in scenarios:
  output=e/f'feature-{i:02}-{arm}-{scenario}.json'
  run(f'feature-{i:02}-{arm}-{scenario}',['dotnet',str(repo/'test/SharpLink.Benchmarks/bin/Release/net10.0/SharpLink.Benchmarks.dll'),'--feature-evidence','server',scenario,'1000','1','100000',str(output)],repo,e/f'feature-{i:02}-{arm}-{scenario}.log')
for arm in ['A','B']:
 repo=base if arm=='A' else root
 run(f'allocation-{arm}',['dotnet',str(repo/'test/SharpLink.Benchmarks/bin/Release/net10.0/SharpLink.Benchmarks.dll'),'--allocation-gate','--budgets',str(root/'eng/perf/allocation-budgets.json'),'--output',str(e/f'allocation-{arm}.json')],repo,e/f'allocation-{arm}.log')
repo=root
run('allocation-negative-B',['dotnet',str(repo/'test/SharpLink.Benchmarks/bin/Release/net10.0/SharpLink.Benchmarks.dll'),'--allocation-gate','--budgets',str(root/'eng/perf/allocation-budgets.json'),'--output',str(e/'allocation-negative-B.json'),'--filter','rpc-add-sharedmemory-c1','--inject-bytes-per-operation','128'],repo,e/'allocation-negative-B.log',expected=1)
run('allocation-self-test',['dotnet',str(repo/'test/SharpLink.Benchmarks/bin/Release/net10.0/SharpLink.Benchmarks.dll'),'--allocation-gate-self-test','--output',str(e/'allocation-self-test.json')],repo,e/'allocation-self-test.log')
(e/'campaign-complete.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n')
