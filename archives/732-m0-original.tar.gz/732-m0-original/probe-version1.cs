using System.Diagnostics;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.Json;
using SharpLink.Abstractions;
using SharpLink.Client;
using SharpLink.Runtime;
using SharpLink.Sdk;
using SharpLink.Server;
namespace MethodFactsExperiment;
public static class Program
{
    public static async Task Main(string[] args)
    {
        object result = args[0] == "cold" ? Cold() : await Network.RunAsync();
        Console.WriteLine(JsonSerializer.Serialize(new { mode=args[0],
            runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
            architecture=System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString(),
            processorCount=Environment.ProcessorCount,
            tieredPgo=Environment.GetEnvironmentVariable("DOTNET_TieredPGO") ?? "default",
            identity=SharpLinkGeneratedManifestVersions.AbiIdentity,
            serverMvid=typeof(SharpLinkServerBuilder).Assembly.ManifestModule.ModuleVersionId,
            result }, new JsonSerializerOptions { WriteIndented=true }));
    }
    private static object Cold()
    {
        var locator = typeof(IColdFacts64).Assembly.GetCustomAttribute<SharpLinkGeneratedAssemblyManifestAttribute>()!;
        var manifest = (ISharpLinkGeneratedAssemblyManifest)Activator.CreateInstance(locator.ManifestType)!;
        var provider = new NoCodecs();
        var rows = new List<object>();
        foreach (var type in new[] { typeof(IColdFacts1), typeof(IColdFacts64) })
        {
            var contract = manifest!.Contracts.Single(c => c.ContractType == type);
            var before = GC.GetAllocatedBytesForCurrentThread();
            var first = contract.StubFactory(provider);
            var firstBytes = GC.GetAllocatedBytesForCurrentThread() - before;
            before = GC.GetAllocatedBytesForCurrentThread();
            var second = contract.StubFactory(provider);
            var secondBytes = GC.GetAllocatedBytesForCurrentThread() - before;
            var stubType = first.GetType();
            var fields = stubType.GetFields(BindingFlags.NonPublic | BindingFlags.Static)
                .Where(f => f.FieldType.Name == "RpcMethodFacts").ToArray();
            var methods = stubType.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
                .Cast<MethodBase>().Concat(stubType.GetConstructors(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
            if (stubType.TypeInitializer is { } initializer) methods = methods.Append(initializer);
            var il = methods.Distinct().Select(m => new { name=m.Name, bytes=m.GetMethodBody()?.GetILAsByteArray()?.Length ?? 0 }).ToArray();
            Check.That(fields.Select(f=>f.GetValue(null)).Distinct(ReferenceEqualityComparer.Instance).Count()==fields.Length,"one unique cold facts object per method");
            rows.Add(new { contract=type.Name, methods=contract.Methods.Count, firstBytes, secondBytes,
                coldExtraBytes=firstBytes-secondBytes, factsObjects=fields.Length, ilBytes=il.Sum(m=>m.bytes), il });
            GC.KeepAlive(first); GC.KeepAlive(second);
        }
        return rows;
    }
    private sealed class NoCodecs : IRpcCodecProvider
    { public IRpcCodec<T> GetCodec<T>() => throw new InvalidOperationException("void fixture requires no codecs"); }
}
internal static class Check
{ internal static void That(bool condition,string message) { if(!condition) throw new InvalidOperationException(message); } }
internal sealed class Passthrough : ISharpLinkServerInterceptor
{ public ValueTask InvokeAsync(SharpLinkServerInvocationContext context, SharpLinkServerInvocationDelegate next) => next(context); }
[RpcContract] public interface IColdFacts1 : IService { [NonCancellable] ValueTask Ping0(); }
[RpcContract] public interface IColdFacts64 : IService
{
    [NonCancellable] ValueTask Ping0();
    [NonCancellable] ValueTask Ping1();
    [NonCancellable] ValueTask Ping2();
    [NonCancellable] ValueTask Ping3();
    [NonCancellable] ValueTask Ping4();
    [NonCancellable] ValueTask Ping5();
    [NonCancellable] ValueTask Ping6();
    [NonCancellable] ValueTask Ping7();
    [NonCancellable] ValueTask Ping8();
    [NonCancellable] ValueTask Ping9();
    [NonCancellable] ValueTask Ping10();
    [NonCancellable] ValueTask Ping11();
    [NonCancellable] ValueTask Ping12();
    [NonCancellable] ValueTask Ping13();
    [NonCancellable] ValueTask Ping14();
    [NonCancellable] ValueTask Ping15();
    [NonCancellable] ValueTask Ping16();
    [NonCancellable] ValueTask Ping17();
    [NonCancellable] ValueTask Ping18();
    [NonCancellable] ValueTask Ping19();
    [NonCancellable] ValueTask Ping20();
    [NonCancellable] ValueTask Ping21();
    [NonCancellable] ValueTask Ping22();
    [NonCancellable] ValueTask Ping23();
    [NonCancellable] ValueTask Ping24();
    [NonCancellable] ValueTask Ping25();
    [NonCancellable] ValueTask Ping26();
    [NonCancellable] ValueTask Ping27();
    [NonCancellable] ValueTask Ping28();
    [NonCancellable] ValueTask Ping29();
    [NonCancellable] ValueTask Ping30();
    [NonCancellable] ValueTask Ping31();
    [NonCancellable] ValueTask Ping32();
    [NonCancellable] ValueTask Ping33();
    [NonCancellable] ValueTask Ping34();
    [NonCancellable] ValueTask Ping35();
    [NonCancellable] ValueTask Ping36();
    [NonCancellable] ValueTask Ping37();
    [NonCancellable] ValueTask Ping38();
    [NonCancellable] ValueTask Ping39();
    [NonCancellable] ValueTask Ping40();
    [NonCancellable] ValueTask Ping41();
    [NonCancellable] ValueTask Ping42();
    [NonCancellable] ValueTask Ping43();
    [NonCancellable] ValueTask Ping44();
    [NonCancellable] ValueTask Ping45();
    [NonCancellable] ValueTask Ping46();
    [NonCancellable] ValueTask Ping47();
    [NonCancellable] ValueTask Ping48();
    [NonCancellable] ValueTask Ping49();
    [NonCancellable] ValueTask Ping50();
    [NonCancellable] ValueTask Ping51();
    [NonCancellable] ValueTask Ping52();
    [NonCancellable] ValueTask Ping53();
    [NonCancellable] ValueTask Ping54();
    [NonCancellable] ValueTask Ping55();
    [NonCancellable] ValueTask Ping56();
    [NonCancellable] ValueTask Ping57();
    [NonCancellable] ValueTask Ping58();
    [NonCancellable] ValueTask Ping59();
    [NonCancellable] ValueTask Ping60();
    [NonCancellable] ValueTask Ping61();
    [NonCancellable] ValueTask Ping62();
    [NonCancellable] ValueTask Ping63();
}
[RpcContract]
public interface IFactsRpc : IService
{
    [NonCancellable] IAsyncEnumerable<int> Plain(int count);
    [Timeout(3600)] IAsyncEnumerable<int> Tracked(int count, CancellationToken cancellationToken);
}
[RpcService]
public sealed class FactsService : IFactsRpc
{
    public IAsyncEnumerable<int> Plain(int count) => new Range(count, default);
    public IAsyncEnumerable<int> Tracked(int count, CancellationToken cancellationToken) => new Range(count, cancellationToken);
    private sealed class Range(int count, CancellationToken token) : IAsyncEnumerable<int>, IAsyncEnumerator<int>
    {
        private int _index;
        public int Current => count < 0 ? (token.CanBeCanceled ? 1 : 0) : _index;
        public IAsyncEnumerator<int> GetAsyncEnumerator(CancellationToken cancellationToken = default) => this;
        public ValueTask<bool> MoveNextAsync() => ValueTask.FromResult(++_index <= Math.Max(1, count) && count != 0);
        public ValueTask DisposeAsync() => ValueTask.CompletedTask;
    }
}

internal static class Network
{
    private const int Warmup = 1000;
    private const int Operations = 2000;
    private const int Samples = 5;
    internal static async Task<object> RunAsync()
    {
        var results = new List<object>();
        foreach (var transport in new[] { "tcp", "sharedmemory" })
        foreach (var mode in new[] { "plain", "interceptor", "admission" })
        {
            var name = "facts-" + Guid.NewGuid().ToString("N");
            var builder = SharpLinkServerBuilder.Create();
            if (mode == "interceptor") builder.AddInterceptor(new Passthrough());
            if (mode == "admission") builder.UseAdmissionControl(options => options.Global.UseConcurrency(32));
            if (transport == "tcp") builder.UseTcp(0, IPAddress.Loopback); else builder.UseSharedMemory(name);
            var port = transport == "tcp" ? ((IPEndPoint)builder.Transport!.LocalEndPoint!).Port : 0;
            await using var server = builder.Build(); await server.StartAsync();
            var cb = SharpClientBuilder.Create().DisableRequestTimeout();
            if (transport == "tcp") cb.UseTcp("127.0.0.1", port); else cb.UseSharedMemory(name);
            await using var client = cb.Build();
            using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(2));
            await client.ConnectAsync(timeout.Token);
            var rpc = client.Get<IFactsRpc>();
            // Diagnostic outside all measurement windows: prove the tracked shape owns a cancellable server state.
            await foreach (var value in rpc.Tracked(-1, timeout.Token)) Check.That(value == 1, "tracked stream cancellation witness");
            foreach (var scenario in new (bool Tracked, int Items, int C)[] { (false,0,1), (false,1,1), (true,0,1), (true,1,1), (true,1,8) })
            {
                await RunCalls(rpc, scenario.Tracked, scenario.Items, scenario.C, Warmup, null, timeout.Token);
                for (var sample = 0; sample < Samples; sample++)
                {
                    var ticks = new long[Operations];
                    var cpu = Process.GetCurrentProcess().TotalProcessorTime;
                    var allocated = GC.GetTotalAllocatedBytes(true);
                    var start = Stopwatch.GetTimestamp();
                    await RunCalls(rpc, scenario.Tracked, scenario.Items, scenario.C, Operations, ticks, timeout.Token);
                    var elapsed = Stopwatch.GetTimestamp() - start;
                    allocated = GC.GetTotalAllocatedBytes(true) - allocated;
                    cpu = Process.GetCurrentProcess().TotalProcessorTime - cpu;
                    var sorted = (long[])ticks.Clone(); Array.Sort(sorted);
                    results.Add(new { transport, mode, scenario.Tracked, scenario.Items, concurrency=scenario.C, sample,
                        operations=Operations, elapsedTicks=elapsed, frequency=Stopwatch.Frequency,
                        bytes=allocated, cpuMilliseconds=cpu.TotalMilliseconds, ticks,
                        p50=sorted[Operations/2], p99=sorted[(int)(Operations*.99)], p999=sorted[(int)(Operations*.999)] });
                }
            }
            await client.StopAsync(); await server.StopAsync(TimeSpan.FromSeconds(10));
            Check.That(server.LifecycleState == SharpLinkServerLifecycleState.Stopped, "server stopped after all complete stream results");
        }
        return results;
    }
    private static async Task RunCalls(IFactsRpc rpc, bool tracked, int items, int concurrency, int operations,
        long[]? ticks, CancellationToken token)
    {
        var tasks = new Task[concurrency];
        for (var worker = 0; worker < concurrency; worker++) tasks[worker] = Worker(worker);
        await Task.WhenAll(tasks);
        async Task Worker(int worker)
        {
            for (var i = worker; i < operations; i += concurrency)
            {
                var start = Stopwatch.GetTimestamp(); var count = 0; var sum = 0;
                await foreach (var value in tracked ? rpc.Tracked(items, token) : rpc.Plain(items)) { count++; sum += value; }
                if (count != items || sum != items*(items+1)/2) throw new InvalidOperationException("network item/completion checksum");
                if (ticks is not null) ticks[i] = Stopwatch.GetTimestamp() - start;
            }
        }
    }
}
