# Fixed complete-method-facts network campaign

All 8 prescribed processes, 34 cells, 5 samples/cell, 2,720,000 measured complete calls retained. A/B medians and paired geometric ratios are distinct summaries. No outlier removal.

| Transport | Mode | Tracked/items/c | A ns/op | B ns/op | paired B/A | A B/op | B B/op | CPU B/A | P99 B/A |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| tcp | plain | False/0/1 | 66511.32 | 55158.12 | 0.8386 | 865.34 | 864.71 | 0.8794 | 0.8416 |
| tcp | plain | False/1/1 | 85748.36 | 68103.28 | 1.1819 | 872.91 | 868.78 | 0.7999 | 1.3589 |
| tcp | plain | True/0/1 | 71733.97 | 62518.46 | 1.1766 | 2236.59 | 2238.53 | 0.9263 | 1.5440 |
| tcp | plain | True/1/1 | 64093.88 | 64987.25 | 0.8975 | 2240.96 | 2241.42 | 1.3287 | 0.5890 |
| tcp | plain | True/1/8 | 8453.04 | 9681.80 | 1.0502 | 2247.56 | 2248.07 | 1.0405 | 1.0752 |
| tcp | interceptor | False/0/1 | 52929.76 | 50582.15 | 1.0099 | 1136.35 | 1136.42 | 1.0248 | 1.0175 |
| tcp | interceptor | False/1/1 | 50536.26 | 56263.71 | 1.0196 | 1138.64 | 1138.66 | 1.1282 | 0.7521 |
| tcp | interceptor | True/0/1 | 49812.53 | 56213.47 | 1.1424 | 2418.78 | 2420.12 | 1.0157 | 1.7950 |
| tcp | interceptor | True/1/1 | 54408.61 | 60191.07 | 1.1454 | 2424.57 | 2424.98 | 1.0666 | 1.6677 |
| tcp | interceptor | True/1/8 | 8075.78 | 7672.88 | 0.9957 | 2430.85 | 2430.45 | 1.0294 | 0.9963 |
| tcp | admission | False/0/1 | 47415.14 | 55347.55 | 1.1055 | 1184.29 | 1184.29 | 1.0023 | 1.7660 |
| tcp | admission | False/1/1 | 51640.51 | 53178.39 | 1.0496 | 1187.14 | 1187.18 | 0.9875 | 1.5636 |
| tcp | admission | True/0/1 | 48431.60 | 44398.43 | 0.9436 | 2475.04 | 2472.40 | 0.9832 | 0.9773 |
| tcp | admission | True/1/1 | 53237.15 | 48070.08 | 0.9361 | 2480.14 | 2480.21 | 0.9360 | 0.9740 |
| tcp | admission | True/1/8 | 7700.00 | 7852.74 | 1.0073 | 2487.03 | 2487.54 | 0.9612 | 1.0350 |
| tcp | queued | False/0/8 | 8600.60 | 8735.04 | 1.0286 | 3429.22 | 3406.98 | 0.9418 | 1.0914 |
| tcp | queued | False/1/8 | 9579.47 | 9573.42 | 1.0283 | 3427.34 | 3411.80 | 0.9806 | 1.0877 |
| sharedmemory | plain | False/0/1 | 38461.20 | 38233.71 | 0.9337 | 1803.96 | 1805.97 | 0.7646 | 1.0227 |
| sharedmemory | plain | False/1/1 | 35547.01 | 34851.16 | 0.8726 | 1798.74 | 1795.90 | 0.7412 | 0.8825 |
| sharedmemory | plain | True/0/1 | 37385.47 | 35755.56 | 0.6510 | 3175.52 | 3172.19 | 1.1792 | 0.3608 |
| sharedmemory | plain | True/1/1 | 36190.11 | 36345.00 | 0.8549 | 3173.50 | 3168.92 | 1.1242 | 0.5982 |
| sharedmemory | plain | True/1/8 | 4273.67 | 3967.69 | 0.8629 | 2281.31 | 2272.21 | 1.0179 | 0.9868 |
| sharedmemory | interceptor | False/0/1 | 36064.94 | 36957.53 | 1.0047 | 2081.18 | 2076.42 | 1.0765 | 0.9966 |
| sharedmemory | interceptor | False/1/1 | 35978.91 | 35203.21 | 0.9096 | 2073.13 | 2072.38 | 0.9256 | 0.8944 |
| sharedmemory | interceptor | True/0/1 | 36357.99 | 37463.03 | 1.0306 | 3354.86 | 3357.71 | 0.9856 | 1.1052 |
| sharedmemory | interceptor | True/1/1 | 36096.17 | 36039.16 | 0.8467 | 3354.41 | 3353.59 | 0.6759 | 0.8763 |
| sharedmemory | interceptor | True/1/8 | 4383.50 | 3966.66 | 0.8964 | 2471.71 | 2463.07 | 0.7545 | 0.8763 |
| sharedmemory | admission | False/0/1 | 37669.94 | 35237.04 | 0.6676 | 2125.21 | 2117.64 | 1.0320 | 0.3400 |
| sharedmemory | admission | False/1/1 | 37104.56 | 36035.40 | 0.8274 | 2129.78 | 2118.09 | 0.9898 | 0.7399 |
| sharedmemory | admission | True/0/1 | 38892.89 | 39192.93 | 1.2462 | 3420.82 | 3420.34 | 0.8974 | 1.7370 |
| sharedmemory | admission | True/1/1 | 36766.82 | 35887.66 | 1.5156 | 3417.34 | 3415.57 | 0.9111 | 2.4625 |
| sharedmemory | admission | True/1/8 | 4187.41 | 4615.82 | 1.0532 | 2522.72 | 2529.33 | 1.0286 | 1.0288 |
| sharedmemory | queued | False/0/8 | 8200.57 | 8629.93 | 1.1037 | 4006.18 | 3981.25 | 1.1270 | 1.4114 |
| sharedmemory | queued | False/1/8 | 8366.77 | 8454.91 | 0.9144 | 3938.95 | 3954.28 | 0.8821 | 0.8810 |


## Tracking-label evidence correction (2026-10-28)

`Tracked` labels the declared fixture shape; the original `CanBeCanceled` witness alone did not prove per-call state ownership. See `evidence/TRACKING-ERRATUM.md` (from the campaign root) for the separate request-id/token-association preflight and its synchronous no-state control. Original samples and the No-Go decision are unchanged.
