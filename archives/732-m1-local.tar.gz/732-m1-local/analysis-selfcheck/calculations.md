# M0→M1 fixed causal campaign calculations

Primary T: **favorable exploratory signal**. U: **favorable exploratory signal**. All 640,000 completed calls retained.

## Cross-arm pair ratios (always B/A)

| Cell | Four mean ratios | Mean GM | Four P99 ratios | P99 GM |
|---|---|---:|---|---:|
| I/T | 0.900000, 0.900000, 0.900000, 0.900000 | 0.900000 | 1.000000, 1.000000, 1.000000, 1.000000 | 1.000000 |
| P/T | 1.000000, 1.000000, 1.000000, 1.000000 | 1.000000 | 1.000000, 1.000000, 1.000000, 1.000000 | 1.000000 |
| I/U | 0.900000, 0.900000, 0.900000, 0.900000 | 0.900000 | 1.000000, 1.000000, 1.000000, 1.000000 | 1.000000 |
| P/U | 1.000000, 1.000000, 1.000000, 1.000000 | 1.000000 | 1.000000, 1.000000, 1.000000, 1.000000 | 1.000000 |

## Cross-arm L and D

| Pair (zero-based) | Order | I/T log | P/T log | I/U log | P/U log | T interaction | U interaction |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | AB | -0.105360516 | 0.000000000 | -0.105360516 | 0.000000000 | -0.105360516 | -0.105360516 |
| 3 | BA | -0.105360516 | 0.000000000 | -0.105360516 | 0.000000000 | -0.105360516 | -0.105360516 |
| 4 | BA | -0.105360516 | 0.000000000 | -0.105360516 | 0.000000000 | -0.105360516 | -0.105360516 |
| 6 | AB | -0.105360516 | 0.000000000 | -0.105360516 | 0.000000000 | -0.105360516 | -0.105360516 |

## Same-arm S and H (chronological second/first)

| Pair (zero-based) | Order | I/T log | P/T log | I/U log | P/U log | T interaction | U interaction |
|---:|---|---:|---:|---:|---:|---:|---:|
| 0 | AA | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 |
| 2 | BB | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 |
| 5 | BB | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 |
| 7 | AA | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 | 0.000000000 |

noise[T] = 0.000000000; noise[U] = 0.000000000.
Interaction geometric ratios: T=0.900000, U=0.900000.

## Same-arm ratios

| Pair | Order | Cell | Mean second/first | P99 second/first |
|---:|---|---|---:|---:|
| 0 | AA | I/T | 1.000000 | 1.000000 |
| 0 | AA | P/T | 1.000000 | 1.000000 |
| 0 | AA | I/U | 1.000000 | 1.000000 |
| 0 | AA | P/U | 1.000000 | 1.000000 |
| 2 | BB | I/T | 1.000000 | 1.000000 |
| 2 | BB | P/T | 1.000000 | 1.000000 |
| 2 | BB | I/U | 1.000000 | 1.000000 |
| 2 | BB | P/U | 1.000000 | 1.000000 |
| 5 | BB | I/T | 1.000000 | 1.000000 |
| 5 | BB | P/T | 1.000000 | 1.000000 |
| 5 | BB | I/U | 1.000000 | 1.000000 |
| 5 | BB | P/U | 1.000000 | 1.000000 |
| 7 | AA | I/T | 1.000000 | 1.000000 |
| 7 | AA | P/T | 1.000000 | 1.000000 |
| 7 | AA | I/U | 1.000000 | 1.000000 |
| 7 | AA | P/U | 1.000000 | 1.000000 |

Complete per-process mean/P99/CPU/allocation/GC values are in `process-aggregates.csv`; full-precision calculations are in `analysis.json`. These descriptive decisions neither clear M0's historical No-Go nor establish release equivalence.
